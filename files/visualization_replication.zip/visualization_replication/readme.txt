Replication files for "Visualizing the Contraction Mapping Theorem"
by James E. Rauch and Alexis Akira Toda

There are two folders, one titled "stochastic growth" and the other titled "optimal savings", which solve the stochastic growth model in Section 3 and the optimal savings problem in Section 4, respectively.

For the algorithm, please refer to the descriptions in the main text as well as references cited therein.

Numerical implementations use MATLAB. Running the files "main_sg.m" (for stochastic growth model) and "main_os.m" (for optimal savings problem) should replicate the results in the paper.

See also the textbook treatment in "Essential Mathematics for Economics" by Alexis Akira Toda (https://doi.org/10.1201/9781032698953) and the replication files available at https://github.com/alexisakira/EME.
