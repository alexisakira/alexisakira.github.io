function [csi] = coloc(mu,~)
% Calculate the Chebyshev colocation points using the Gauss-Lobotto nodes
% These are the extrema of the polynomials: mu is a positive integer which
% represents the degree of the approximnation.
% csi are the colocation points
% (c) Roger Farmer October 29th 2014
% RF Updated December 29th 2014: added a second argument
% If function is one-dimensional add any integer as a second argument

%%
big = 10^5;
if mu ==0
    csi = 0;
    return
else
    if nargin > 1
        n=mu;
    else
        n = 2^mu+1;
    end
    s=1:n;
    csi = (-cos(pi*(s-1)./(n-1)))';
    csi = sign(csi).*floor(abs(csi*big))/big;
end
