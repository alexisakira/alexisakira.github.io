function z = Fsim2(b,x,y,mux,muy)

nx = numel(x);
ny = numel(y);

z = zeros(nx,ny);

for ii = 1:nx
    for jj = 1:ny
        z(ii,jj) = sum(sum(bsxfun(@times,bsxfun(@times,b,cheb(x(ii),mux)),cheb(y(jj),muy)')));
    end
end

end