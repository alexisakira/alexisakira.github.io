function [b, p] = Fappr(FUN,d,mu)
% Generate an approximation to the function FUN where
% FUN maps [-1,1]^d  and mu is the degree of approximation
% b completely characterizes the approximation to b
% p is a matrix that contains indices of the polynomial coefficents at each
% grid point
% (c) Roger Farmer October 29th 2014

%%

[g,p] = setgrid(d,mu);
B = ScriptB(d,mu);
b = B\(FUN(g)');



