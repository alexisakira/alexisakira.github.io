function xhat = Tx(x,xL,xU,S)
% This function maps [xL,xIU] to [-1,1]
% S is a shape paramater used in the infinite case
% (c) Roger Farmer October 29th 2014

%%
if nargin < 4;
    S=1;
end
if xL>xU
    t = xU;
    xU = xL;
    xL = t;
end

% Check that bounds are feasible
% if sum(x<xL | x>xU)>0
%     xhat = [];
%     disp('Error: Variable Out of Bounds');
%         return
% end

x(x<xL) = xL;
x(x>xU) = xU;



if isfinite(xL) && isfinite(xU)
    xhat = (2*x - (xU+xL))/(xU-xL);
elseif ~isfinite(xL) && ~isfinite(xU);
    xhat = -(1 - exp(S*x))/(1+exp(S*x));
elseif ~isfinite(xL) && isfinite(xU)
    disp('Cannot handle this case yet')
    x = [];
    return;
elseif isfinite(xL) && ~isfinite(xU)  
    disp('Cannot handle this case yet')
    x = [];
    return;
end
xhat(xhat<-1) = -1;
xhat(xhat>1) = 1;

end
