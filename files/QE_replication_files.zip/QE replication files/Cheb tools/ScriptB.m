function B = ScriptB(d,mu)
% Construct the matrix ScriptB 
% Reference Judd Maliar Maliar Valero Page 16
% The approximation coefficients to a function F satisfy the linear
% equations b = B^-1*F(g) where g are the grid points
% (c) Roger Farmer October 29th 2014

%%
[g, pc] = setgrid(d,mu);
n = size(pc,2);
B = ones(n,n);
N = max(max(pc));
for i = 1: n
    x = g(:,i);
    for k = 1:n
        for j = 1:d
            y = cheb(x(j),N);
            B(i,k) = B(i,k)*y(pc(j,k));
        end
    end
end


