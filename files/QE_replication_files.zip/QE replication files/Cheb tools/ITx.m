function x = ITx(xhat,xL,xU,S)
% This function maps [-1,1] to [xL,xIU]
% S is a shape paramater used in the infinite case
% (c) Roger Farmer October 29th 2014

%%
% If necessary switch bounds so that xU is upper bound
if nargin < 4;
    S=1;
end

if xL>xU
    t = xU;
    xU = xL;
    xL = t;
end


xhat(xhat<-1)=-1;
xhat(xhat>1) =1;

% % Check that bounds are feasible
% if sum(xhat < -1 | xhat >1)>0
%      x = [];
%     disp('Error: Variable Out of Bounds');
%         return
% end

if isfinite(xL) && isfinite(xU)
    x = (1/2)*(xhat*(xU-xL) + xU + xL);

elseif ~isfinite(xL) && ~isfinite(xU);
    x = log(( 1 +xhat)./(1-xhat))/S;


elseif ~isfinite(xL) && isfinite(xU)
    disp('Cannot handle this case yet')
    x = [];
    return;
elseif isfinite(xL) && ~isfinite(xU)  
    disp('Cannot handle this case yet')
    x = [];
    return;
end

end