function p  = Echeb(m)
% This program calculates  stuff
% (c) Roger Farmer October 29th 2014

%%
r = length(m);
index = zeros(r,r);
index(1,1) = 1;
index(2,2) = 1;

p = zeros(r,1);

for t = 3:r
    index(t,:) = 2.*[0 index(t-1,1:end-1)] - index(t-2,:);
end


    p = ones(r,r)*m;




