function [p ,c] = cheb(x,r,i)
% This program calculates the Chebyshev polynomials of degree 1 through r, 
% evaluated at x: if i is missing, the program returns the first r polynomials
% otherwise, for i <= r, the program returns the i'th polynomial. x must be
% between -1 and 1. i and r are positive integers with i <=r
% c is a matrix where column j is the chebychev coefficient on x^j on term i
% (c) Roger Farmer October 29th 2014

%%

if any(any(x<-1)) || any(any(x>1))
    disp('Invalid input: x must be between -1 and 1');
    p = [];
    return
elseif nargin>2
    if i > r;
    disp('Invalid input: i must be less than or equal to r');
    p = [];
    return;
    end
end


p = zeros(r,size(x,2));


p(1,:) = 1;

if r >1
p(2,:) = x;
end


for t = 3:r
    p(t,:) = 2.*x.*p(t-1,:)-p(t-2,:);
end,

if nargin>2;
    p = p(i,:);
end

c = zeros(r,r);
c(1,1) = 1;
c(2,2) = 1;

for t = 3:r
    c(t,:) = 2*[0 c(t-1,1:r-1)] - c(t-2,:);
end

