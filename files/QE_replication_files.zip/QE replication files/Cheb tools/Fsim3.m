function w = Fsim3(b,x,y,z,mux,muy,muz)

nx = numel(x);
ny = numel(y);
nz = numel(z);
w = zeros(nx,ny,nz);

for ii = 1:nx
    cheb1 = repmat(cheb(x(ii),mux),1,muy,muz);
    for jj = 1:ny
        cheb2 = repmat(cheb(y(jj),muy)',mux,1,muz);
        for kk = 1:nz
            cheb3 = repmat(reshape(cheb(z(kk),muz),1,1,muz),mux,muy,1);
            temp = b.*cheb1.*cheb2.*cheb3;
            w(ii,jj,kk) = sum(temp(:));
        end
    end
end

end