function z = Fsim(b,x,mu)
% Compute the value of a Chebyshev polynomial evaluated at x where
% rows(x)=d is the dimension of the domain and cols(x)=n is the number of
% points at which the polynomial is evaluated.  The vector b an
% approximation to a function F: [-1,1]^d -> R. The choice of grid 
% points and polynomials is determined by Maliar and Maliar's implementation
% of the Smolyak sparse grid method. mu is the degree of approximation

% (c) Roger Farmer October 29th 2014
%%
d = size(x,1);
n = size(x,2);
[~, pc] = setgrid(d,mu);
N = max(max(pc));
K = size(pc,2);
z = ones(1,n);
X = ones(K,n);

for i = 1:n
    for k = 1:K   
        X(k,i)=1;
        for j = 1:d
            y = cheb(x(j,i),N);
            X(k,i) = X(k,i)*y(pc(j,k));
        end
        z(1,i)=b'*X(:,i);
    end
end