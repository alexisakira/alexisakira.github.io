function z = EFsim(b,A,B)
% Compute the expected value of a Chebyshev polynomial E[P(x)] 
% x are assumed to be random variables with a beta distribution 
% with parameters A and B and support [-1,1]
% (c) Roger Farmer October 29th 2014
%%

d = 1;
N = numel(b);

[~ ,c] = cheb(0,N);

m = makemomentsBeta(N-1,A,B);

z = b'*(c*m);
