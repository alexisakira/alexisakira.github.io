function X = inds(d,mu)
% Computes all vectors of integers of length d for which the sum of the 
% elements is less than or equal to d+mu and greater than or equal to d.
% (c) Roger Farmer October 29th 2014

% q = max(d,1+mu); [removed 10-29]


%%
x = ones(1,d);
X = x;

while x(1) < mu + 1 || sum(x) < mu + d
    
    while sum(x) < mu + d
        k = d;
        x(k) = x(k) + 1;
        X = [X;x]; %#ok<AGROW>
    end

    k = k-1;

    x(k) = x(k) + 1;
    x(k+1:end) = 1;
    X = [X;x]; %#ok<AGROW>
end
