function [points, polychoose] = setgrid(d,mu)
% points is a set of grid points for a sparse Smolyak grid with dimension d
% and approximation level mu
% polychoose is a set of indices of the chebychev polynomials that occur at
% each grid point
% (c) Roger Farmer October 29th 2014

%%
if d==1
    points = coloc(mu,1)';
    polychoose = 1:length(points);
    return
end


s = cell(mu+1,1);
a = cell(mu+1,1);
polyind = cell(mu+1,1);

s{1} = 0;
a{1} = s{1};
polyind{1} = 1;
for i = 2:mu+1
    s{i} = coloc(i-1);
    a{i} = setdiff(s{i},s{i-1});
    polyind{i} = (polyind{i-1}(end)+1:polyind{i-1}(end)+size(a{i},1))';
end

p1 = inds(d,mu);
points = [];
polychoose = [];
for i = 1:size(p1,1);
    temp1 = a{p1(i,1)}';
    temp2 = polyind{p1(i,1)}';
    for j = 2:d
    temp1 = combvec(temp1,a{p1(i,j)}');
    temp2 = combvec(temp2,polyind{p1(i,j)}');
    end
    points = [points temp1]; %#ok<AGROW>
    polychoose = [polychoose temp2]; %#ok<AGROW>
end
    
 

    

