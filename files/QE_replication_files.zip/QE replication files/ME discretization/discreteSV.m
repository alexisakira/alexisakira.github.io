function [P,xyGrids] = discreteSV(lambda,rho,sigmaU,sigmaE,Ny,Nx,method)

%% Compute some uncondtional moments

sigmaX = (sigmaE^2)/(1-rho^2); % unconditional variance of variance process
xBar = 2*log(sigmaU)-sigmaX/2; % unconditional mean of variance process, targeted to match a mean standard deviation of sigmaU
sigmaY = sqrt(exp(xBar+sigmaX/2)/(1-lambda^2)); % uncondtional standard deviation of technology shock

%% Construct technology process approximation

[Px,xGrid] = discreteVAR(xBar*(1-rho),rho,sigmaE^2,Nx,2,method); % compute FTT discretization of variance process

sigmaSpacing = sqrt((Ny-1)/2);
yGrid = linspace(-sigmaSpacing*sigmaY,sigmaSpacing*sigmaY,Ny);

Nm = Nx*Ny; % total number of state variable pairs
xyGrids = flipud(combvec(xGrid,yGrid))';
P = zeros(Nm);
lambdaGuess = zeros(2,1);
scalingFactor = yGrid(end);
kappa = 1e-5;
for ii = 1:Nm
    
    q = normpdf(yGrid,lambda*xyGrids(ii,1),sqrt(exp((1-rho)*xBar+rho*xyGrids(ii,2)+(sigmaE^2)/2)));
    if sum(q<kappa) > 0
        q(q<kappa) = kappa;
    end
    [temp,lambdaGuess] = discreteApproximation(yGrid,@(X) [(X-lambda*xyGrids(ii,1))./scalingFactor; ((X-lambda*xyGrids(ii,1))./scalingFactor).^2],[0; (exp((1-rho)*xBar+rho*xyGrids(ii,2)+(sigmaE^2)/2))./(scalingFactor^2)],q,lambdaGuess);
    % If trying to match two conditional moments fails, just match the
    % conditional mean
    if any(isnan(temp)) || max(temp) > 1-kappa
        warning('Failed to match conditional mean and variance. Just matching conditional mean instead.')
        temp = discreteApproximation(yGrid,@(X) (X-lambda*xyGrids(ii,1))./scalingFactor,0,q,0);
    end
    P(ii,:) = kron(temp,ones(1,Nx));
    P(ii,:) = P(ii,:).*repmat(Px(mod(ii-1,Nx)+1,:),1,Ny);
 
end

end