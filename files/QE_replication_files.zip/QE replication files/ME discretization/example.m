%% Gaussian AR(1)

% Parameter initialization

rho = 0.99; % persistence
N = 9;  % # of grid points
nMoments = 2; % # of moments to match
sigma2 = 1; % conditional variance

tic
[P1,D1] = discreteVAR(0,rho,sigma2,N,nMoments,'even');
% 'method' can be 'even', 'quantile', or 'quadrature'.  'quantile' is not
% recommended.
toc

%% Gaussian 2-D VAR(1) - example in Appendix B.1

% Set parameters

A = [0.9809 0.0028; 0.0410 0.9648]; % lag matrix
Sigma = [0.0087^2 0; 0 0.0262^2]; % conditional covariance matrix
N = 9; % # of grid points
nMoments = 2; % # of moments to match

% Discretize VAR

tic
[P2,D2] = discreteVAR(zeros(2,1),A,Sigma,N,nMoments,'even');
toc

%% Stochastic volatility - example in Appendix B.2

lambda = 0.95;
rho = 0.9;
sigmaU = 0.007;
sigmaE = 0.06;
Ny = 9;
Nx = 9;
volLoading = 1;

tic
[P3,D3] = discreteSV(lambda,rho,sigmaU,sigmaE,Ny,Nx,volLoading,2,2);
toc

%% Gaussian mixture - example in Section 4.3

load dividendGrowth % load dividend growth data
T = numel(dGrowth);
dX = [ones(T-1,1) dGrowth(1:end-1)];
dY = dGrowth(2:end);

% estimate OLS parameters
betaHat = dX\dY;
rhoHat = betaHat(2);
muHat = betaHat(1)/(1-betaHat(2));
regResid = dY - dX*betaHat; % residuals

% Fit Gaussian mixtures
nComp = 3; % number of components
warning('off');
gmObj = fitgmdist(regResid,nComp);
warning('on');

N = 15; % # of grid points
nMoments = 2; % # of moments to match

tic
[P4,D4] = discreteARGM(muHat,rhoHat,gmObj,N,nMoments,'even');
% 'method' can be 'even', 'gauss-hermite', 'gauss-legendre', or
% 'clenshaw-curtis'.
toc
