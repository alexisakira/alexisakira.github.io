function [P,X] = discreteARGM(mu,rho,gmObj,Nm,nMoments,method,nSigmas)

% discretize AR(1) process with shocks coming from a Gaussian mixture
% gmObj is the Gaussiam mixture object obtained from using fitgmdist

muC = gmObj.mu; % mean of each component
varC = squeeze(gmObj.Sigma); % variance of each component
pC = gmObj.ComponentProportion; % proportion of each component

T1 = pC*muC; % mean
T2 = pC*(muC.^2+varC); % uncentered second moment
T3 = pC*(muC.^3+3*muC.*varC); % uncentered third moment
T4 = pC*(muC.^4+6*(muC.^2).*varC+3*varC.^2); % uncentered fourth moment

TBar = [T1 T2 T3 T4]';

gmPDF = gmdistribution(gmObj.mu,gmObj.Sigma,gmObj.ComponentProportion);


% Default number of moments is 2
if nargin == 4
    nMoments = 2;
end

if nargin < 7
    if abs(rho) <= 1-2/(Nm-1)
    nSigmas = sqrt(2*(Nm-1));
    else nSigmas = sqrt(Nm-1);
    end
end

% Check that Nm is a valid number of grid points
if ~isnumeric(Nm) || Nm < 3 || rem(Nm,1) ~= 0
    error('Nm must be a positive integer greater than 3')
end

% Check that nMoments is a valid number
if ~isnumeric(nMoments) || nMoments < 1 || nMoments > 4 || ~((rem(nMoments,1) == 0) || (nMoments == 1))
    error('nMoments must be either 1, 2, 3, 4')
end

sigma = sqrt(T2-T1^2); % conditional standard deviation
sigmaX = sigma/sqrt(1-rho^2); % unconditional standard deviation

switch method
    case 'even'
        X = linspace(mu-nSigmas*sigmaX,mu+nSigmas*sigmaX,Nm);
        W = ones(1,Nm);
    case 'gauss-legendre'
        [X,W] = legpts(Nm,[mu-nSigmas*sigmaX,mu+nSigmas*sigmaX]);
        X = X';
    case 'clenshaw-curtis'
        [X,W] = fclencurt(Nm,mu-nSigmas*sigmaX,mu+nSigmas*sigmaX);
        X = fliplr(X');
        W = fliplr(W');
    case 'gauss-hermite'
        [X,W] = GaussHermite(Nm);
        X = mu+sqrt(2)*sigma*X';
        W = W'./sqrt(pi);
end

P = NaN(Nm);
scalingFactor = max(abs(X));
kappa = 1e-8;

for ii = 1:Nm
    
    condMean = mu*(1-rho)+rho*X(ii);
    xPDF = (X-condMean)';
    switch method
        case 'gauss-hermite'
            q = W.*(pdf(gmPDF,xPDF)./normpdf(xPDF,0,sigma))';
        otherwise
            q = W.*(pdf(gmPDF,xPDF))';
    end
    
    if any(q < kappa)
        q(q < kappa) = kappa;
    end

if nMoments == 1 % match only 1 moment
            P(ii,:) = discreteApproximation(X,@(x)(x-condMean)/scalingFactor,TBar(1)./scalingFactor,q,0);
else % match 2 moments first
    [p,lambda,momentError] = discreteApproximation(X,@(x) [(x-condMean)./scalingFactor;...
        ((x-condMean)./scalingFactor).^2],...
        TBar(1:2)./(scalingFactor.^(1:2)'),q,zeros(2,1));
    if norm(momentError) > 1e-5 % if 2 moments fail, then just match 1 moment
                warning('Failed to match first 2 moments. Just matching 1.')
                P(ii,:) = discreteApproximation(X,@(x)(x-condMean)/scalingFactor,0,q,0);
    elseif nMoments == 2
        P(ii,:) = p;
    elseif nMoments == 3
    [pnew,~,momentError] = discreteApproximation(X,@(x) [(x-condMean)./scalingFactor;...
        ((x-condMean)./scalingFactor).^2;((x-condMean)./scalingFactor).^3],...
        TBar(1:3)./(scalingFactor.^(1:3)'),q,[lambda;0]);
    if norm(momentError) > 1e-5
        warning('Failed to match first 3 moments.  Just matching 2.')
        P(ii,:) = p;
    else P(ii,:) = pnew;
    end
    else % 4 moments
    [pnew,~,momentError] = discreteApproximation(X,@(x) [(x-condMean)./scalingFactor;...
        ((x-condMean)./scalingFactor).^2; ((x-condMean)./scalingFactor).^3;...
        ((x-condMean)./scalingFactor).^4],TBar./(scalingFactor.^(1:4)'),q,[lambda;0;0]);
    if norm(momentError) > 1e-5
        %warning('Failed to match first 4 moments.  Just matching 3.')
        [pnew,~,momentError] = discreteApproximation(X,@(x) [(x-condMean)./scalingFactor;...
        ((x-condMean)./scalingFactor).^2;((x-condMean)./scalingFactor).^3],...
        TBar(1:3)./(scalingFactor.^(1:3)'),q,[lambda;0]);
    if norm(momentError) > 1e-5
        warning('Failed to match first 3 moments.  Just matching 2.')
        P(ii,:) = p;
    else P(ii,:) = pnew;
        warning('Failed to match first 4 moments.  Just matching 3.')
    end
    else P(ii,:) = pnew;
    end
    end
end

end