The file "discreteVAR.m" is the main file to discretize VAR processes.
"discreteSV.m" discretizes the stochastic volatility model.
"discreteARGM.m" discretizes the AR(1) process with Gaussian mixture shocks.
The rest are subroutines.
See "example.m" for examples.