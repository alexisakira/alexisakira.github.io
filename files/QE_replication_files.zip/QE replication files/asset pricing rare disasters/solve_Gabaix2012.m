% This script solves Gabaix (2012) up to fifth order, and compares the
% result with the closed-form solution.
% To run this script you first need to run differentiate_Gabaix2012.m.

addpath 'files'
clear,clc

rho=.0657;
gamma=4;
gC=.025;
gD=gC;
sigmaD=.11;
p=.0363;
Bbar=.66;
sigmaF=.1;
Fstar=Bbar;
phiH=.13;

mud=p;

delta=rho+gamma*gC;

% Parameter values
params=[gC Bbar mud rho gamma gC gD p phiH Fstar];

sig_D=.11; sig_H=.13;  
eta=[log(Bbar),0,0;1,0,0;0,sig_D,0;0,0,sig_H];

% Calculate cross moments. 

M2=zeros(3,3); 
M2(1,1)=(1-p)*(-mud)^2+p*(1-mud)^2;
M2(2,2)=1;
M2(3,3)=1;

M3=zeros(3,3,3); 
M3(1,1,1)=(1-p)*(-mud)^3+p*(1-mud)^3;

M4=zeros(3,3,3,3); 
M4(1,1,1,1)=(1-p)*(-mud)^4+p*(1-mud)^4;
M4(2,2,2,2)=3;
M4(3,3,3,3)=3;

n_e=3;
for i=1:n_e-1
    for j=i+1:n_e
        tempP=perms([i,i,j,j]);
        M4(sub2ind([n_e,n_e,n_e,n_e],tempP(:,1),tempP(:,2),tempP(:,3),tempP(:,4)))=M2(i,i)*M2(j,j);
    end
end

M5=zeros(3,3,3,3,3); 
M5(1,1,1,1,1)=(1-p)*(-mud)^5+p*(1-mud)^5;

i=1;
for j=i+1:n_e
    tempP=perms([i,i,i,j,j]);
    M5(sub2ind([n_e,n_e,n_e,n_e,n_e],tempP(:,1),tempP(:,2),tempP(:,3),tempP(:,4),tempP(:,5)))=M3(i,i,i)*M2(j,j);
end

% 2. Build the total cross moments in a structure.
M.M2=M2;
M.M3=M3;
M.M4=M4;
M.M5=M5;

% Steady state
Hhat_ss=0;
w_ss=mud;
v_ss=gD;
F_ss=Bbar;
Hstar_ss=exp(-gamma*w_ss*log(Bbar)+w_ss*log(F_ss))-1;


DlogC_ss=gC+mud*log(Bbar);
DlogD_ss=v_ss+w_ss*log(F_ss);

pe_ss=1/(1-(F_ss/Bbar^gamma)^mud*exp(-rho-gamma*gC+gD));

nxss=[DlogC_ss;w_ss;v_ss;Hhat_ss]; 
nyss=[pe_ss;F_ss;Hstar_ss];

% Load files created automatically by prepare_dsge
load('model');

% check steady state

double(subs(f,[yp(:);y(:);xp(:);x(:);symparams(:)],[nyss(:);nyss(:);nxss(:);nxss(:);params(:)]))

% Choose solution algorithm: Hessenberg-Schur method (dlyap), or standard
% vectorization (vectorize)
% algo='dlyap'; 
algo='vectorize';

derivs=solve_dsge(model,params,M,eta,nxss,nyss,approx,algo);

%%% Compare closed-form solution with perturbation solutions
n_y=model.n_y;
n_x=model.n_x;
for i=1:length(symparams)
    eval([char(symparams(i)) '=params(' num2str(i) ');'])
end

% calculate closed-form solution for these values:
true_Hstar=p*( exp(-gamma*log(Bbar)+log(Fstar)) -1 );

% take few values of Hhat:

trim = 0.001;
rhoBar = 0.995;
HMin = max(p*(Bbar^(-gamma)*0-1) - true_Hstar,(1+true_Hstar)*(exp(-phiH)-1)); % min resilience deviation
HMax = p*(Bbar^(-gamma)*1-1) - true_Hstar; % max resilience deviation
HLower = max((1+true_Hstar)*(exp(-phiH)/rhoBar-1),HMin+trim*abs(HMin));
HUpper = HMax-trim*abs(HMax);
numEval = 1000;

Hhat_vec=linspace(HLower,HUpper,numEval);

hstar=log(1+true_Hstar);
deltai=delta-gD-hstar;

true_pe_vec=1/(1-exp(-deltai))*(1+exp(-deltai-hstar)/(1-exp(-deltai-phiH))*Hhat_vec);

% claculate perturbation solutions:

gx=reshape(derivs.gx,n_y,n_x);
gxx=reshape(derivs.gxx,n_y,n_x^2);
gxxx=reshape(derivs.gxxx,n_y,n_x^3);
gxxxx=reshape(derivs.gxxxx,n_y,n_x^4);
gxxxxx=reshape(derivs.gxxxxx,n_y,n_x^5);

nxss=[DlogC_ss;w_ss;v_ss;Hhat_ss]; 

for i=1:length(Hhat_vec)
    
    i

    xhat=([gC;0;gD;Hhat_vec(i);1]-[nxss;0]);
    xhat2=kron(xhat,xhat);
    xhat3=kron(xhat2,xhat);
    xhat4=kron(xhat3,xhat);
    xhat5=kron(xhat4,xhat);

    y1st=nyss+gx*xhat;
    y2nd=y1st+gxx*xhat2/factorial(2);
    y3rd=y2nd+gxxx*xhat3/factorial(3);
    y4th=y3rd+gxxxx*xhat4/factorial(4);
    y5th=y4th+gxxxxx*xhat5/factorial(5);

    pe1(i)=y1st(1);
    pe2(i)=y2nd(1);
    pe3(i)=y3rd(1);
    pe4(i)=y4th(1);
    pe5(i)=y5th(1);
end

%%% compare perturbation solutions with closed form solution

[Hhat_vec(:) pe1(:) pe2(:) pe3(:) pe4(:) pe5(:) true_pe_vec(:)]

policyPerturbation = [pe1(:) pe2(:) pe3(:) pe4(:) pe5(:)];
policyExact = true_pe_vec(:);
HHatEval = Hhat_vec';

save('policyEval.mat','policyPerturbation','policyExact','HHatEval','-append')