% plot log10 relative errors for the discretization solution of rare
% disaster model

close all
set(0,'DefaultAxesFontSize',12);
set(0,'DefaultTextFontSize',12);
set(0,'DefaultLineLineWidth',2);

colors = get(gca,'ColorOrder');
c1 = colors(1,:);
c2 = colors(2,:);
c3 = colors(3,:);
c4 = colors(4,:);
c5 = colors(5,:);

%% Calibration

rho = 0.0657; % rate of time preference
gam = 4; % risk aversion
g = 0.025; % growth rate of consumption and dividends
sigD = 0.11; % volatility of dividend growth
p = 0.0363; % probability of a disaster
BBar = 0.66; % recovery rate
FiStar = BBar; % typical value of stock's recovery rate
sigF = 0.08; % volatility of stock's recovery rate
phiH = 0.13; % mean reversion of stock's recovery rate

%% Implied parameters

delta = rho+gam*g;
HiStar = p*(BBar^(1-gam)-1);
hiStar = log(1+HiStar);

FMin = 0; % min recovery rate
FMax = 1; % max recovery rate
HHatMin = max(p*(BBar^(-gam)*FMin-1) - HiStar,(1+HiStar)*(exp(-phiH)-1)); % min resilience deviation
HHatMax = p*(BBar^(-gam)*FMax-1) - HiStar; % max resilience deviation

K = 0.2*phiH*abs(HHatMin)*HHatMax; % conditional variance parameter

% Compute exact PD ratio using Eq (13) in Gabaix paper
deltai = delta - g - hiStar;
exactPD = @(HHat)((1/(1-exp(-deltai)))*(1+(exp(-deltai-hiStar)/(1-exp(-deltai-phiH)))*HHat));

%% Discretize process

condMean = @(HHat) ((1+HiStar)./(1+HiStar+HHat))*exp(-phiH).*HHat;
condVar = @(HHat) 2*K*(1-HHat./HHatMin).^2.*(1-HHat./HHatMax).^2;
momentFunction = @(HHat) [condMean(HHat); condVar(HHat)];
numMoments = 2;
numPoints = [5 11 21 41 81];

%% Define numbers for accuracy evaluation
nP = numel(numPoints);
numEval = 1000;
policyErrors = zeros(numEval,nP);
trim = 0.001; % fraction trimmed from each end
rhoBar = 0.99; % maximum persistence allowed
d = HHatMax - HHatMin;
HLower = max((1+HiStar)*(exp(-phiH)/rhoBar-1),HHatMin+trim*d);
HUpper = HHatMax-trim*d;
HHatEval = linspace(HLower,HUpper,numEval)';

% change method to 'even', 'clenshaw-curtis', 'gauss-legendre'
for n=1:nP
    tic
    [P,HGrid] = discreteResilienceBeta(@(HHat) momentFunction(HHat),HHatMin,HHatMax,HiStar,phiH,numPoints(n),numMoments,'clenshaw-curtis');
    PDratio = PDdiscreteGabaix(rho,gam,g,g,P,HGrid+HiStar); % Compute PD ratio of discretized process
    toc
    PDGrid = griddedInterpolant(HGrid,PDratio,'linear','linear');
    policyErrors(:,n) = log10(abs((exactPD(HHatEval)-PDGrid(HHatEval))./exactPD(HHatEval)));
end

%% Compute log_10 errors

figure(1)
%plot(HHatEval,policyErrors)
line_fewer_markers(HHatEval,policyErrors(:,1),9,'-x','Mks',8,'Color',c1); hold on
line_fewer_markers(HHatEval,policyErrors(:,2),9,'-o','Mks',8,'Color',c2);
line_fewer_markers(HHatEval,policyErrors(:,3),9,'-s','Mks',8,'Color',c3);
line_fewer_markers(HHatEval,policyErrors(:,4),9,'-d','Mks',8,'Color',c4);
line_fewer_markers(HHatEval,policyErrors(:,5),9,'-*','Mks',8,'Color',c5); hold off
xlim([HHatEval(1) HHatEval(end)])
xlabel('Variable part of resilience')
ylabel('log_{10} relative errors')
columnlegend(2,{'N=5','N=11','N=21','N=41','N=81'});


%% plot perturbation errors

load policyEval

policyPerturbationErrors = log10(abs(bsxfun(@rdivide,bsxfun(@minus,policyExact,policyPerturbation),policyExact)));
perturbationOrders = 1:5;

figure(2)
%plot(HHatEval,policyPerturbationErrors)
line_fewer_markers(HHatEval,policyPerturbationErrors(:,1),9,'-x','Mks',8,'Color',c1); hold on
line_fewer_markers(HHatEval,policyPerturbationErrors(:,2),9,'-o','Mks',8,'Color',c2);
line_fewer_markers(HHatEval,policyPerturbationErrors(:,3),9,'-s','Mks',8,'Color',c3);
line_fewer_markers(HHatEval,policyPerturbationErrors(:,4),9,'-d','Mks',8,'Color',c4);
line_fewer_markers(HHatEval,policyPerturbationErrors(:,5),9,'-*','Mks',8,'Color',c5); hold off
xlim([HHatEval(1) HHatEval(end)])
xlabel('Variable part of resilience')
ylabel('log_{10} relative errors')
columnlegend(1,{'1st order','2nd order','3rd order','4th order','5th order'});

disp('Mean Policy Function Errors')
disp('Perturbation Approximations, orders 1 through 5')
[perturbationOrders; mean(policyPerturbationErrors)]
disp('Discrete Approximations with linear interpolation')
[numPoints; mean(policyErrors)]

disp('Max Policy Function Errors')

disp('Perturbation Approximations, orders 1 through 5')
[perturbationOrders; max(policyPerturbationErrors)]
disp('Discrete Approximations with linear interpolation')
[numPoints; max(policyErrors)]

load policyEval2.mat
meanErrors = zeros(5,4);
meanErrors(:,1) = mean(policyErrorsEven);
meanErrors(:,2) = mean(policyErrorsGL);
meanErrors(:,3) = mean(policyErrorsCC);
meanErrors(:,4) = mean(policyPerturbationErrors);

maxErrors = zeros(5,4);
maxErrors(:,1) = max(policyErrorsEven);
maxErrors(:,2) = max(policyErrorsGL);
maxErrors(:,3) = max(policyErrorsCC);
maxErrors(:,4) = max(policyPerturbationErrors);
