load('policyEval.mat')

policyPerturbationErrors = log10(abs(bsxfun(@rdivide,bsxfun(@minus,policyExact,policyPerturbation),policyExact)));
perturbationOrders = 1:5;

policyDiscrete = [policyDiscrete21 policyDiscrete31 policyDiscrete41...
    policyDiscrete51 policyDiscrete101 policyDiscrete201];
policyDiscreteErrors = log10(abs(bsxfun(@rdivide,bsxfun(@minus,policyExact,policyDiscrete),policyExact)));
numPoints = [21 31 41 51 101 201];

% Mean and max errors

disp('Mean Policy Function Errors')

disp('Perturbation Approximations, orders 1 through 5')
[perturbationOrders; mean(policyPerturbationErrors)]

disp('Discrete Approximations with linear interpolation')
[numPoints; mean(policyDiscreteErrors)]

disp('Max Policy Function Errors')

disp('Perturbation Approximations, orders 1 through 5')
[perturbationOrders; max(policyPerturbationErrors)]

disp('Discrete Approximations with linear interpolation')
[numPoints; max(policyDiscreteErrors)]

% Plot errors

figure
plot(HHatEval,policyPerturbationErrors)
xlim([HHatEval(1) HHatEval(end)])
legend({'1st order perturbation','2nd order perturbation','3rd order perturbation',...
    '4th order perturbation','5th order perturbation'});

figure
plot(HHatEval,policyDiscreteErrors)
xlim([HHatEval(1) HHatEval(end)])
legend({'ME-Even 21','ME-Even 31',...
    'ME-Even 41','ME-Even 51','ME-Even 101','ME-Even 201'});