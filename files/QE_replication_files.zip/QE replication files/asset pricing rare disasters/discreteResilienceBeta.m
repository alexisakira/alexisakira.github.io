function [P,HGrid] = discreteResilienceBeta(momentFunction,HMin,HMax,HStar,phiH,m,numMoments,method)

% Default number of moments is 2
if nargin == 6
    numMoments = 2;
end

% Default method is 'even'
if nargin <= 7
    method = 'even';
end

if ~strcmp(method,'even') && ~strcmp(method,'clenshaw-curtis') && ~strcmp(method,'gauss-legendre')
    error('method must be one of even, clenshaw-curtis, or gauss-legendre')
end

% Trim boundaries of grid to avoid zero variance at the boundary
trim = 0.001; % fraction trimmed from each end
rhoBar = 0.999; % maximum persistence allowed (need this to avoid absorbing state at boundary)
d = HMax - HMin;
HLower = max((1+HStar)*(exp(-phiH)/rhoBar-1),HMin+trim*d);
HUpper = HMax-trim*d;

% Create grid
switch method
    case 'even'
        HGrid = linspace(HLower,HUpper,m)';
        W = (1/(HMax-HMin))*ones(1,m);
    case 'clenshaw-curtis'
        [X,W] = fclencurt(m,HLower,HUpper);
        HGrid = flipud(X);
        W = flipud(W)';
    case 'gauss-legendre'
        [HGrid,W] = legpts(m,[HLower,HUpper]);
end
normalization = max(abs(HGrid)); % normalization constant

% Error checking, need at least 2 conditional moments
sizeMomentFun = numel(momentFunction(HMin));
if sizeMomentFun ~= 2
    error('You must specify the conditional mean and variance')
end

% Evaluate conditional moment functions at grid points
HGridMoments = momentFunction(HGrid');

% Find beta distribution parameters to match the mean and variance

xBar = (HGridMoments(1,:)-HMin)./(HMax-HMin);
vBar = HGridMoments(2,:)./((HMax-HMin)^2);
betaDistParams = [xBar.*(xBar.*(1-xBar)./vBar-1);...
    (1-xBar).*(xBar.*(1-xBar)./vBar-1)];

% Find higher moments of implied beta distributions

centralMoments = [zeros(1,m); HGridMoments(2,:); NaN(numMoments-2,m)];

for ii = 1:numMoments-2
    
    switch ii
        case 1
            skewBeta = 2*(betaDistParams(2,:)-betaDistParams(1,:)).*sqrt(sum(betaDistParams)+1)...
                ./((sum(betaDistParams)+2).*sqrt(prod(betaDistParams)));
            centralMoments(3,:) = skewBeta.*(centralMoments(2,:).^(3/2));
            
        case 2
            kurtBeta = 6*((betaDistParams(2,:)-betaDistParams(1,:)).^2.*...
                (sum(betaDistParams)+1)-prod(betaDistParams).*(sum(betaDistParams)+2))...
                ./(prod(betaDistParams).*(sum(betaDistParams)+2).*(sum(betaDistParams)+3))+3;
            centralMoments(4,:) = kurtBeta.*(centralMoments(2,:).^2);
            
        otherwise
            error('Cannot handle more than 4 moments yet')
    end
    
end

kappa = 1e-10;

% Compute discrete approximation

P = NaN(m);

for ii = 1:m
    
    T = @(x) bsxfun(@power,(x-HGridMoments(1,ii))./normalization,(1:numMoments)');
    TBar = centralMoments(1:numMoments,ii)./bsxfun(@power,normalization,(1:numMoments)');
    q = W.*betapdf((HGrid-HMin)./(HMax-HMin),betaDistParams(1,ii),betaDistParams(2,ii))';
    q(q<kappa) = kappa;
    
    for jj = numMoments:-1:1
        
        [temp,~,momentError] = discreteApproximation(HGrid',T,TBar,q,zeros(numMoments,1));
        
        if norm(momentError) <= 1e-5
            break
        end
        
    end 

    if min(1-temp) < 1e-6
        P(ii,:) = q./sum(q);
        warning('Failed to match any moments')
    else
        P(ii,:) = temp;
    end
    
end