% Simulate from Gabaix model

%% Calibration

rho = 0.0657; % rate of time preference
gam = 4; % risk aversion
g = 0.025; % growth rate of consumption and dividends
sigD = 0.11; % volatility of dividend growth
p = 0.0363; % probability of a disaster
BBar = 0.66; % recovery rate
FiStar = BBar; % typical value of stock's recovery rate
sigF = 0.08; % volatility of stock's recovery rate
phiH = 0.13; % mean reversion of stock's recovery rate

%% Implied parameters

delta = rho+gam*g;
HiStar = p*(BBar^(1-gam)-1);
hiStar = log(1+HiStar);

FMin = 0; % min recovery rate
FMax = 1; % max recovery rate
HHatMin = max(p*(BBar^(-gam)*FMin-1) - HiStar,(1+HiStar)*(exp(-phiH)-1)); % min resilience deviation
HHatMax = p*(BBar^(-gam)*FMax-1) - HiStar; % max resilience deviation

K = 0.2*phiH*abs(HHatMin)*HHatMax; % conditional variance parameter

%% Discretize process

deltat = 1/12; % time interval
condMean = @(HHat) ((1+HiStar)./(1+HiStar+HHat))*exp(-phiH).*HHat;
condVar = @(HHat) 2*K*(1-HHat./HHatMin).^2.*(1-HHat./HHatMax).^2;
momentFunction = @(HHat) [condMean(HHat); condVar(HHat)];
m = 201; % number of points
numMoments = 2;

[P,HGrid] = discreteResilienceBeta(@(HHat) momentFunction(HHat),HHatMin,HHatMax,HiStar,phiH,m,numMoments,'even');

% Compute ergodic distribution and standard deviation
[V,~] = eigs(P',1);
ergodicProb = V/sum(V);
condVarGrid = condVar(HGrid);
sdUnc = sqrt(sum(ergodicProb.*condVarGrid));

figure(1)
h = (HHatMax-HHatMin)/(m-1); % length of one grid
plot(HGrid,ergodicProb/h)
xlim([HHatMin HHatMax])
xlabel('Variable part of resilience')
ylabel('Probability density function')

% Compute PD ratio of discretized process

PDratio = PDdiscreteGabaix(rho,gam,g,g,P,HGrid+HiStar);

% Compute exact PD ratio using Eq (13) in Gabaix paper
deltai = delta - g - hiStar;
exactPD = @(HHat)((1/(1-exp(-deltai)))*(1+(exp(-deltai-hiStar)/(1-exp(-deltai-phiH)))*HHat));

figure
plot(HGrid,[exactPD(HGrid),PDratio])
xlim([HGrid(1) HGrid(end)])

%% Compute log_10 errors

numEval = 1000;
PDGrid = griddedInterpolant(HGrid,PDratio,'linear','linear');

trim = 0.001;
HLower = max((1+HiStar)*(exp(-phiH)/rhoBar-1),HHatMin+trim*abs(HHatMin));
HUpper = HHatMax-trim*abs(HHatMax);
HHatEval = linspace(HLower,HUpper,numEval)';

policyErrors = log10(abs((exactPD(HHatEval)-PDGrid(HHatEval))./exactPD(HHatEval)));

mean(policyErrors)
max(policyErrors)

figure
plot(HHatEval,policyErrors)
xlim([HHatEval(1) HHatEval(end)])

%policyDiscrete11 = PDGrid(HHatEval);
%save('policyEval.mat','policyDiscrete11','-append')

%% Simulate some data

% TSim = 1000;
% %stateSim = [randsample(m,1,'true',ergodicProb); NaN(TSim,1)];
% stateSim = [(m+1)/2; NaN(TSim,1)];
% 
% for t = 1:TSim
%     
%     stateSim(t+1) = randsample(m,1,'true',P(stateSim(t),:));
%     
% end
% 
% HHatSim = HGrid(stateSim(2:end));
% 
% figure
% plot(HHatSim)
% xlim([1,TSim])