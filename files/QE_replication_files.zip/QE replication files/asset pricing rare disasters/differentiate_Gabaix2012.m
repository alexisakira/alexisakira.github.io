clear,clc

syms DlogC DlogCp w wp DlogM DlogMp DlogD DlogDp v vp F Fp Fpp Hhat Hhatp pe pep S Sp Hstar Hstarp real
syms gC Bbar mud rho gamma gC gD p phiH Fstar real

f1=-DlogCp+gC+mud*log(Bbar); 
DlogDp=vp+wp*log(Fp);

f2=-vp+gD;
f3=-wp+mud; 
f4=-Hstar-Hhat+exp(-gamma*wp*log(Bbar)+wp*log(Fp))-1;
f5=-Hhatp+(1+Hstar)/(1+Hstar+Hhat)*exp(-phiH)*Hhat;
f6=-Hstar+exp(-gamma*wp*log(Bbar)+wp*log(Fstar))-1;
f7=-1+exp(-rho-gamma*DlogCp+DlogDp)*pep/(pe-1);

Phi=[];
f=[f1;f2;f3;f4;f5;f6;f7];

x=[DlogC,w,v,Hhat]; 
y=[pe,Fp,Hstar];

xp=[DlogCp,wp,vp,Hhatp]; 
yp=[pep,Fpp,Hstarp];


approx=5;
symparams=[gC Bbar mud rho gamma gC gD p phiH Fstar];

model=differentiate_dsge(f,yp,y,xp,x,symparams,approx,Phi);
save('model')
