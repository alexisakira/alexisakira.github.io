% Compute financial moments

%% Calibration

rho = 0.0657; % rate of time preference
gam = 4; % risk aversion
g = 0.025; % growth rate of consumption and dividends
sigD = 0.11; % volatility of dividend growth
p = 0.0363; % probability of a disaster
BBar = 0.66; % recovery rate
FiStar = BBar; % typical value of stock's recovery rate
sigF = 0.08; % volatility of stock's recovery rate
phiH = 0.13; % mean reversion of stock's recovery rate

%% Implied parameters

delta = rho+gam*g;
HiStar = p*(BBar^(1-gam)-1);
hiStar = log(1+HiStar);
deltai = delta - g - hiStar;

FMin = 0; % min recovery rate
FMax = 1; % max recovery rate
HHatMin = max(p*(BBar^(-gam)*FMin-1) - HiStar,(1+HiStar)*(exp(-phiH)-1)); % min resilience deviation
HHatMax = p*(BBar^(-gam)*FMax-1) - HiStar; % max resilience deviation

K = 0.2*phiH*abs(HHatMin)*HHatMax; % conditional variance parameter

%% Discretize process

% Conditional moment functions

deltat = 1/12; % time interval
condMean = @(HHat) ((1+HiStar)./(1+HiStar+HHat))*exp(-phiH).*HHat;
condVar = @(HHat) 2*K*(1-HHat./HHatMin).^2.*(1-HHat./HHatMax).^2;
momentFunction = @(HHat) [condMean(HHat); condVar(HHat)];
numMoments = 2;

% Dicrete approximations
ms = [5 11 21 41 81];
numM = numel(ms);
policyEven = cell(numM,1);
policyGL = cell(numM,1);
policyCC = cell(numM,1);

for ii = 1:numM
    
    ii
    
    m = ms(ii);
    
    % Even-spaced
    [P,HGrid] = discreteResilienceBeta(@(HHat) momentFunction(HHat),HHatMin,HHatMax,HiStar,phiH,m,numMoments,'even');
    PDratio = PDdiscreteGabaix(rho,gam,g,g,P,HGrid+HiStar);
    policyEven{ii} = griddedInterpolant(HGrid,PDratio,'linear','linear');
    
    % Gauss-Legendre
    [P,HGrid] = discreteResilienceBeta(@(HHat) momentFunction(HHat),HHatMin,HHatMax,HiStar,phiH,m,numMoments,'gauss-legendre');
    PDratio = PDdiscreteGabaix(rho,gam,g,g,P,HGrid+HiStar);
    policyGL{ii} = griddedInterpolant(HGrid,PDratio,'linear','linear');
    
    % Clenshaw-Curtis
    [P,HGrid] = discreteResilienceBeta(@(HHat) momentFunction(HHat),HHatMin,HHatMax,HiStar,phiH,m,numMoments,'clenshaw-curtis');
    PDratio = PDdiscreteGabaix(rho,gam,g,g,P,HGrid+HiStar);
    policyCC{ii} = griddedInterpolant(HGrid,PDratio,'linear','linear');
    
end

pdExact = @(HHat)((1/(1-exp(-deltai)))*(1+(exp(-deltai-hiStar)/(1-exp(-deltai-phiH)))*HHat));

%% Simulate data

TSim = 100000;
HHatSim = [0; NaN(TSim,1)];
dGrowthSim = [g; NaN(TSim,1)];
FSim = [0; NaN(TSim,1)];
disasterSim = zeros(TSim+1,1);

load('perturbationFunctions.mat')

for t = 1:TSim
    
    condMoments = momentFunction(HHatSim(t));
    xBar = (condMoments(1)-HHatMin)./(HHatMax-HHatMin);
    vBar = condMoments(2)./((HHatMax-HHatMin)^2);
    betaDistParams = [xBar.*(xBar.*(1-xBar)./vBar-1);...
        (1-xBar).*(xBar.*(1-xBar)./vBar-1)];
    
    HHatSim(t+1) = HHatMin + (HHatMax-HHatMin)*betarnd(betaDistParams(1),betaDistParams(2));
    
    if rand <= p
        disasterSim(t+1) = 1;
    end
    
    FSim(t+1) = FiStar + HHatSim(t+1)./(p*BBar^(-gam));
    dGrowthSim(t+1) = g + sigD*randn;
    
    if disasterSim(t+1)
        dGrowthSim(t+1) = dGrowthSim(t+1) + log(FSim(t+1));
    end
    
end

pdEvenSim = NaN(TSim+1,numM);
pdGLSim = NaN(TSim+1,numM);
pdCCSim = NaN(TSim+1,numM);

for ii = 1:numM
    
    pdEvenSim(:,ii) = policyEven{ii}(HHatSim);
    pdGLSim(:,ii) = policyGL{ii}(HHatSim);
    pdCCSim(:,ii) = policyCC{ii}(HHatSim);
    
end

retEvenSim = bsxfun(@plus,100*log(pdEvenSim(2:end,:)./(pdEvenSim(1:end-1,:)-1)),dGrowthSim(2:end));
retGLSim = bsxfun(@plus,100*log(pdGLSim(2:end,:)./(pdGLSim(1:end-1,:)-1)),dGrowthSim(2:end));
retCCSim = bsxfun(@plus,100*log(pdCCSim(2:end,:)./(pdCCSim(1:end-1,:)-1)),dGrowthSim(2:end));

pdPerturbationSim = NaN(TSim+1,5);

for ii = 1:5
    
    pdPerturbationSim(:,ii) = policyPerturbation{ii}(HHatSim);
    
end

retPerturbationSim = bsxfun(@plus,100*log(pdPerturbationSim(2:end,:)./(pdPerturbationSim(1:end-1,:)-1)),dGrowthSim(2:end));

pdExactSim = pdExact(HHatSim);

retExactSim = bsxfun(@plus,100*log(pdExactSim(2:end)./(pdExactSim(1:end-1)-1)),dGrowthSim(2:end));

%% Compute financial moments

disp('Mean of PD ratio')
disp('True')
mean(pdExactSim(2:end))
disp({'ME-Even 5','ME-Even 11','ME-Even 21','ME-Even 41','ME-Even 81'})
mean(pdEvenSim(2:end,:))
disp({'ME-GL 5','ME-GL 11','ME-GL 21','ME-GL 41','ME-GL 81'})
mean(pdGLSim(2:end,:))
disp({'ME-CC 5','ME-CC 11','ME-CC 21','ME-CC 41','ME-CC 81'})
mean(pdCCSim(2:end,:))
disp({'Degree 1','Degree 2','Degree 3','Degree 4','Degree 5'})
mean(pdPerturbationSim(2:end,:))

meanpdSim = [mean(pdEvenSim(2:end,:))' mean(pdGLSim(2:end,:))' mean(pdCCSim(2:end,:))' mean(pdPerturbationSim(2:end,:))'];

disp('Std of ln PD ratio')
disp('True')
std(log(pdExactSim(2:end)))
disp({'ME-Even 5','ME-Even 11','ME-Even 21','ME-Even 41','ME-Even 81'})
std(log(pdEvenSim(2:end,:)))
disp({'ME-GL 5','ME-GL 11','ME-GL 21','ME-GL 41','ME-GL 81'})
std(log(pdGLSim(2:end,:)))
disp({'ME-CC 5','ME-CC 11','ME-CC 21','ME-CC 41','ME-CC 81'})
std(log(pdCCSim(2:end,:)))
disp({'Degree 1','Degree 2','Degree 3','Degree 4','Degree 5'})
std(log(pdPerturbationSim(2:end,:)))

stdpdSim = [std(log(pdEvenSim(2:end,:)))' std(log(pdGLSim(2:end,:)))' std(log(pdCCSim(2:end,:)))' std(log(pdPerturbationSim(2:end,:)))'];

disp('Mean of returns')
disp('True')
mean(retExactSim)
disp({'ME-Even 5','ME-Even 11','ME-Even 21','ME-Even 41','ME-Even 81'})
mean(retEvenSim)
disp({'ME-GL 5','ME-GL 11','ME-GL 21','ME-GL 41','ME-GL 81'})
mean(retGLSim)
disp({'ME-CC 5','ME-CC 11','ME-CC 21','ME-CC 41','ME-CC 81'})
mean(retCCSim)
disp({'Degree 1','Degree 2','Degree 3','Degree 4','Degree 5'})
mean(retPerturbationSim)

meanretSim = [mean(retEvenSim)' mean(retGLSim)' mean(retCCSim)' mean(retPerturbationSim)'];

disp('Std of returns')
disp('True')
std(retExactSim)
disp({'ME-Even 5','ME-Even 11','ME-Even 21','ME-Even 41','ME-Even 81'})
std(retEvenSim)
disp({'ME-GL 5','ME-GL 11','ME-GL 21','ME-GL 41','ME-GL 81'})
std(retGLSim)
disp({'ME-CC 5','ME-CC 11','ME-CC 21','ME-CC 41','ME-CC 81'})
std(retCCSim)
disp({'Degree 1','Degree 2','Degree 3','Degree 4','Degree 5'})
std(retPerturbationSim)

stdretSim = [std(retEvenSim)' std(retGLSim)' std(retCCSim)' std(retPerturbationSim)'];