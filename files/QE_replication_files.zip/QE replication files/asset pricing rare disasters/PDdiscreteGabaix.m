function Out = PDdiscreteGabaix(rho,gamma,gC,gD,P,X)
% compute PD ratio (cum dividend) from the discretized version of Gabaix
% model
% rho: discount rate
% gamma: relative risk aversion
% gC: consumption growth
% gD: dividend growth
% p: probability of rare disaster
% P: transition probability matrix for resilience
% X: state space of resilience

delta = rho + gamma*gC;
S = length(X); % number of states
Out = (eye(S)-exp(-delta+gD)*diag(1+X)*P)\ones(S,1);

end

