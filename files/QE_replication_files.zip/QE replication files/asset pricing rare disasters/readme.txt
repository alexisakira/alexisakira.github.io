discreteErrorFigures.m computes the relative errors of the rare disasters model and outputs the figures.
financialMoments.m computes the financial moments.
The folder "Perturbation Files" are from Levintal (2014).