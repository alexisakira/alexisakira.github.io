function model=differentiate_dsge(f,yp,y,xp,x,symparams,approx,Phi,varargin)
%differentiate_dsge(f,yp,y,xp,x,symparams,approx,Phi,ufun,u)
%This function differentiates the dsge model and prepares all the files 
%necessary to run solve_dsge.m.
%Input variables:
%f,yp,y,xp,x: the model conditions and variable as in Schmitt-Grohe and Uribe (2004)
%symparams: a symbolic array that lists all parameters.
%approx: order of perturbation
%Phi: expected value of exgoenous variables (leave empty if not
%used)
%ufun,u: auxiliary variables to speed up symbolic differentiation (leave empty or drop if not used). 
%
%This code can be used freely for non commercial purposes, provided that it 
%is not altered. Please cite: Levintal, Oren, "Fifth Order Perturbation Solution to DSGE Models".
%(c) Oren Levintal, September 1, 2014.

currentFolder = pwd;
mkdir('files');
cd('files')

syms sigma_perturbation sigmap_perturbation real
Phi=sym(Phi);

x=[x(:);sigma_perturbation]; 
xp=[xp(:);sigmap_perturbation];

v=[yp(:); y(:); xp(:); x(:)];

if isempty(varargin)
    ufun=[];
    u=[];
else
    ufun=varargin{1};
    u=varargin{2};
end

if isempty(ufun) || isempty(u)
    ufun=v;
    u=v;
    chainrules=0;
else
    chainrules=1;
end

n_f=length(f); 
n_x=length(x); 
n_y=length(y); 
n_x2=size(Phi,1); 
n_x1=n_f-n_y;
n_v=length(v);
n_u=length(u);

model.f=f;
model.yp=yp;
model.y=y;
model.xp=xp;
model.x=x;
model.v=v;
model.u=u;
model.ufun=ufun;
model.n_f=n_f;
model.n_x=n_x;
model.n_y=n_y;
model.n_x2=n_x2;
model.n_x1=n_x1;
model.n_v=n_v;
model.n_u=n_u;

save('model')

create_compression_matrices_nonzero;
differentiate_f_chain_rule;
differentiate_phi_nonzero;
load('model')
create_OMEGA_x;
create_eval_u;

load('f_ind')
model.f_ind=f_ind;
load('UW')
model.UW=UW;
load('OMEGA_v')
model.OMEGA_v=OMEGA_v;
model.OMEGA_x=OMEGA_x;

delete('model.mat')
delete('f_ind.mat')
delete('UW.mat')
delete('OMEGA_v.mat')

cd(currentFolder)

