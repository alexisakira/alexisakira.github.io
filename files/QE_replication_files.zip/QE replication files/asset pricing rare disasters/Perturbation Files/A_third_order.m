
fvvvEvx3;
A=result;

fvvEvx_vxx;

A=A+(result+fyp*innerkron(n_y,n_x,gxx,hx,hxx))*OMEGA_x.OMEGA1;


