function [df1,W1M1T,df2,W2M2T,df3,W3M3T,df4,W4M4T,df5,W5M5T]=get_derivs(f,v,approx)

% This function differentiates f with respect to v. Sparsity and symmetry of the
% derivatives of f are exploited to speed up differentiation and to save memory. 
% For details see the appendix of Levintal, Oren, "Fifth Order Perturbation Solution to DSGE
% Models".
% (c) Oren Levintal, December 20, 2013.

df1=[];df2=[];df3=[];df4=[];df5=[];
W1M1T=[];W2M2T=[];W3M3T=[];W4M4T=[];W5M5T=[];
n_v=length(v);
% 1. fv
if n_v==1
    df1=jacobian(f,v);
    W1M1T=speye(length(df1));
    if approx>=2
        df2=jacobian(df1,v);
        W2M2T=speye(length(df2));
    end
    if approx>=3
        df3=jacobian(df2,v);
        W3M3T=speye(length(df3));
    end
    if approx>=4
        df4=jacobian(df3,v);
        W4M4T=speye(length(df4));
    end
    if approx>=5
        df5=jacobian(df4,v);
        W5M5T=speye(length(df5));
    end
else
    df1=jacobian(f, v); % derivative of f wrt v
    df1=df1(:);
%     countdf=sparse(numel(df1),1);
    countdf=1-logical(df1==0);% this variable counts nonzero derivatives.N1=sparse(find(countdf),1:sum(countdf),ones(1,sum(countdf)),n_v,sum(countdf));
%     countdf(find(tempnnzdf1))=1; 
    N1=sparse(find(countdf),1:sum(countdf),ones(1,sum(countdf)),n_v,sum(countdf));
    W1M1T=N1; % This is the transpose of W1*M1. Note that M1=N1'.
    df1=df1(countdf==1); % This is fv*N1 transposed (=column vector of the nonzero first derivatives of f)
    % 2. fvv
    if approx>=2
        df2=jacobian(df1, v); % the second derivative of f wrt v: J(fvN1U1)
        tempnnzdf2=1-logical(df2==0);
        [i1,j1]=find(tempnnzdf2);
        countdf_short=sparse(i1,j1,ones(length(i1),1),size(df2,1),size(df2,2));
%         [i1,j1]=find(countdf_short);
        countdf=W1M1T*countdf_short; % df2 is the jacobian of the compressed df1. To get the full Jacobian we premultiply by (W1*M1)'. Since countdf_short is a replicate of the (compressed) jacobian, countdf is a replicate of the full jacobian.
        countdf=countdf(:);
        countdf_short=countdf_short(:);
        df2=df2(countdf_short==1); % take only nonzero derivativs: vec(fvv*N2)
        k=2;
        if sum(countdf)>0
            [U2,W2]=create_UW(n_v,k,countdf);
            [i1,j1]=find(U2);
            df2=df2(i1); % this is nonzero unique second derivatives: vec(fvv*N2*U2);
            N2=sparse(find(countdf),1:sum(countdf),ones(1,sum(countdf)),n_v^2,sum(countdf));
            [colM2,rowM2]=find(N2);
            [rowW2,colW2]=find(W2);
            W2M2T=sparse(size(N2,1),size(W2,1));
            tempeye=speye(size(W2,1));
            W2M2T(colM2,:)=tempeye(rowW2,:);
        else
            df2=sym(0);
            W2M2T=sparse(n_v^2,1);
            W2=1;
        end
    end

    % 3. fvvv

    if approx>=3
        df3=jacobian(df2, v); % differentiate
        tempnnzdf3=1-logical(df3==0);
        [i1,j1]=find(tempnnzdf3);
        countdf_short=sparse(i1,j1,ones(length(i1),1),size(df3,1),size(df3,2));
        countdf=W2M2T*countdf_short; 
        countdf=countdf(:);
        k=3;
        if sum(countdf)>0
            [U3,W3]=create_UW(n_v,k,countdf);
            N3=sparse(find(countdf),1:sum(countdf),ones(1,sum(countdf)),n_v^3,sum(countdf));
            tempmat=[U3'*(N3'*kron(speye(n_v),W2M2T))];
            [i1,j1]=find(tempmat');
            df3=df3(i1); % this is nonzero unique third derivatives: vec(fvvv*N3*U3);
            [colM3,rowM3]=find(N3);
            [rowW3,colW3]=find(W3);
            W3M3T=sparse(size(N3,1),size(W3,1));
            tempeye=speye(size(W3,1));
            W3M3T(colM3,:)=tempeye(rowW3,:);
        else
            df3=sym(0);
            W3M3T=sparse(n_v^3,1);
        end
    end

    % 4. fvvvv

    if approx>=4
        df4=jacobian(df3, v); % differentiate
        tempnnzdf4=1-logical(df4==0);
        [i1,j1]=find(tempnnzdf4);
        countdf_short=sparse(i1,j1,ones(length(i1),1),size(df4,1),size(df4,2));
        countdf=W3M3T*countdf_short; 
        countdf=countdf(:);
        k=4;
        if sum(countdf)>0
            [U4,W4]=create_UW(n_v,k,countdf);
            N4=sparse(find(countdf),1:sum(countdf),ones(1,sum(countdf)),n_v^4,sum(countdf));
            tempmat=[U4'*(N4'*kron(speye(n_v),W3M3T))];
            [i1,j1]=find(tempmat');
            df4=df4(i1); % this is nonzero unique third derivatives: vec(fvvvv*N4*U4);
            [colM4,rowM4]=find(N4);
            [rowW4,colW4]=find(W4);
            W4M4T=sparse(size(N4,1),size(W4,1));
            tempeye=speye(size(W4,1));
            W4M4T(colM4,:)=tempeye(rowW4,:);
        else
            df4=sym(0);
            W4M4T=sparse(n_v^4,1);
        end
    end

    % 5. fvvvvv

    if approx>=5
        df5=jacobian(df4, v); % differentiate
        tempnnzdf5=1-logical(df5==0);
        [i1,j1]=find(tempnnzdf5);
        countdf_short=sparse(i1,j1,ones(length(i1),1),size(df5,1),size(df5,2));
        countdf=W4M4T*countdf_short; 
        countdf=countdf(:);
        k=5;
        if sum(countdf)>0
            [U5,W5]=create_UW(n_v,k,countdf);
            N5=sparse(find(countdf),1:sum(countdf),ones(1,sum(countdf)),n_v^5,sum(countdf));
            tempmat=[U5'*(N5'*kron(speye(n_v),W4M4T))];
            [i1,j1]=find(tempmat');
            df5=df5(i1); % this is nonzero unique third derivatives: vec(fvvvv*N4*U4);
            [colM5,rowM5]=find(N5);
            [rowW5,colW5]=find(W5);
            W5M5T=sparse(size(N5,1),size(W5,1));
            tempeye=speye(size(W5,1));
            W5M5T(colM5,:)=tempeye(rowW5,:);
        else
            df5=sym(0);
            W5M5T=sparse(n_v^5,1);
        end
    end
end



