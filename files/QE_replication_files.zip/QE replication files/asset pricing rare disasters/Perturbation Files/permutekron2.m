function [ R ] = permutekron2(derivs,order,perms1,perms2,n_v,n_x,n_f,Matrix,varargin )
%permutekron: This function calculates expressions such as
%(fvvv*kron(Vx0,Vx1,Vx1))*E(kron(hx,zeta,zeta)), or 
%(fvvv*kron(Vx0,Vx1,Vx1))*E(kron(I,zeta,zeta))*(kron(hx,I,I)), which is
%equivalent. The function also calculates permutations of these
%expressions. The permutations are in perms1 and perms2. The output is the sum
%of all permutations.
%(c) Oren Levintal, August 14, 2014.
    
if isempty(Matrix) % no stochastic matrix
    Matrix=1;
end

if nnz(Matrix)==0
    R=sparse(n_f,n_x^order);
else
    % 1. Calculate the nonstochastic part: For example:
    % fvvv*kron(Vx0,Vx1,Vx1).

    fmat=varargin{1};

    temp=reshape(fmat,numel(fmat)/n_v,n_v);

    for j=1:length(derivs)-2
        temp=Treshape(bigprod(temp,sparse(varargin{j+1})),numel(temp)/n_v^2*n_x^derivs(j+1),n_v);
    end

    j=length(derivs)-1;
    nonstoch=[reshape([temp*sparse(varargin{j+1})]',numel(temp)/n_v*n_x^derivs(j+1)/n_f,n_f)]';

    % 2. The second term is the stochastic matrix

    R=Matrix;
    stochR=R;
    % 3. Prepare an index for the permutations.

    if order>1 && isempty(perms1)==0
        ind1=reshape([1:n_x^order],repmat(n_x,1,order));
        ind2=reshape([1:n_x^order],[n_x.^derivs(end:-1:2),1]);
        sparseM=speye(n_x^order);
    end
    
    % 4. Calculate permutations and sum.

    for i=1:size(perms1,1)
        % a. Permute
        
        permute_ind1=permute(ind1,perms1(i,:));
        if length(perms2(i,:))>1
            permute_ind2=permute(ind2,perms2(i,:));
        else
            permute_ind2=ind2;
        end
        permute_stochR=sparseM(:,permute_ind2)*sparseM(:,permute_ind1)'*stochR(:,permute_ind1);

        % b. Sum
        R=R+permute_stochR;
    end
    R=nonstoch*R;
end

