W4BU4=reshape([reshape(reshape([reshape(W4, unique*n_x^3,n_x)*hx]',n_x*unique*n_x^2,n_x)*hx,n_x,unique*n_x^3)]',unique,n_x^4)...
    *reshape([reshape(hx*reshape([hx*reshape(U4, n_x,n_x^3*unique)]',n_x,n_x^2*unique*n_x),n_x^3*unique,n_x)]',n_x^4,unique);

Matrix=hx2_Ezeta2;
perms1=[1,3,2,4;1,3,4,2;3,1,2,4;3,1,4,2;3,4,1,2];
tempresult = permutekronB2(4,perms1,n_x,Matrix,W4);

Matrix=hx_Ezeta3;
perms1=[1,2,4,3;1,4,2,3;4,1,2,3];
tempresult = tempresult+permutekronB2(4,perms1,n_x,Matrix,W4 );

tempresult=tempresult+W4*Ezeta4;

W4BU4=W4BU4+tempresult*U4;
