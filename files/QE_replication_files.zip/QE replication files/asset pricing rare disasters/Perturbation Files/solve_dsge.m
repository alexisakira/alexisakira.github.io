function [derivs]=solve_dsge(model,params,M,eta,nxss,nyss,approx,algo,varargin)
%solve_dsge(model,params,M,eta,nxss,nyss,approx,algo,gx,hx)
%This function solves the dsge model with perturbation up to a fifth
%order.
%Input variables:
%model: a structure that is generated automatically by the function
%differentiate_dsge.m
%params: a vector of all parameter values ordered in the same order of symparams.
%M: a structure that contains all the cross moments of the shocks. The fields of
%this structure should be M2,M3,M4,M5.
%eta: The matrix eta as defined in Schmitt-Grohe and Uribe (2004).
%nxss,nyss: steady state values of x and y
%algo: algorithm type. 'dlyap' for dlyap or 'vectorize' for vectorization.
%gx,hx: first order solutions. These arguments are optional. If not supplied, the first order solution is calculated
%by the function gx_hx.m written by Schmitt-Grohe and Uribe (2004).
%
%This code can be used freely for non commercial purposes, provided that it 
%is not altered. Please cite: Levintal, Oren, "Fifth Order Perturbation Solution to DSGE Models".
%(c) Oren Levintal, September 1, 2014.

n_f=model.n_f;
n_x=model.n_x;
n_y=model.n_y;
n_x2=model.n_x2;
n_x1=model.n_x1;
n_v=model.n_v;
n_u=model.n_u;

f_ind=model.f_ind;
UW=model.UW;
OMEGA_v=model.OMEGA_v;
OMEGA_x=model.OMEGA_x;
clear model

if isempty(OMEGA_x)
    create_OMEGA_x;
end


n_e=size(eta,2);
eta=[eta;zeros(1,n_e)];

nxss=[nxss(:);0]; % add steady state value of the perturbation variable.
nyss=nyss(:);
nuss=eval_u([nyss;nyss;nxss;nxss],params);

if approx==1
    clear UW
    [nPhi,nPhix]=sym2script_nPhi(params,nxss,nyss,[],[],[],[]);
elseif approx==2
    W2=UW.W2; U2=UW.U2; 
    clear UW
    [nPhi,nPhix,nPhixx]=sym2script_nPhi(params,nxss,nyss,W2,[],[],[]);
elseif approx==3
    W2=UW.W2; U2=UW.U2;
    W3=UW.W3; U3=UW.U3;
    clear UW
    [nPhi,nPhix,nPhixx,nPhixxx]=sym2script_nPhi(params,nxss,nyss,W2,W3,[],[]);
elseif approx==4
    W2=UW.W2; U2=UW.U2;
    W3=UW.W3; U3=UW.U3;
    W4=UW.W4; U4=UW.U4;
    clear UW
    [nPhi,nPhix,nPhixx,nPhixxx,nPhixxxx]=sym2script_nPhi(params,nxss,nyss,W2,W3,W4,[]);
elseif approx==5
    W2=UW.W2; U2=UW.U2;
    W3=UW.W3; U3=UW.U3;
    W4=UW.W4; U4=UW.U4;
    W5=UW.W5; U5=UW.U5;
    clear UW
    [nPhi,nPhix,nPhixx,nPhixxx,nPhixxxx,nPhixxxxx]=sym2script_nPhi(params,nxss,nyss,W2,W3,W4,W5);
end

numu_derivs=evalu_derivs(params,nxss,nyss,approx);
call_evalf_derivs;

sym2script_fv;

fyp=fv(:,1:n_y); fy=fv(:,n_y+1:2*n_y); fxp=fv(:,2*n_y+1:2*n_y+n_x); fx=fv(:,2*n_y+n_x+1:end);

% First Order

% If first order solution not provided, use the function gx_hx of Schmitt-Grohe and Uribe (2004)
if isempty(varargin)
    tic
    [gx,hx,exitflag]=gx_hx(full([fy;zeros(n_x2,n_y)]),full([fx(:,1:end-1);nPhix(:,1:end-1)]),full([fyp;zeros(n_x2,n_y)]),full([fxp(:,1:end-1);[zeros(n_x2,n_x1),-eye(n_x2)]]));

    gx=[gx,zeros(n_y,1)];
    hx=[hx;zeros(1,n_x-1)];
    hx=[hx,zeros(n_x,1)];
    hx(end,end)=1;

    disp(['1st order completed in ' num2str(toc,'%15.2f') ' seconds'])
else
    gx=zeros(n_y,n_x);
    gx(1:size(varargin{1},1),1:size(varargin{1},2))=varargin{1};
    hx=zeros(n_x,n_x);
    hx(end,end)=1;
    hx(1:size(varargin{2},1),1:size(varargin{2},2))=varargin{2};
end
    
hx=sparse(hx);
gx=sparse(gx);

% Second Order
if approx>=2
    tic
    M2=M.M2;
    eta2_M2=reshape([eta*reshape(M2,n_e,n_e)]',n_e,n_x);
    eta2_M2=reshape([eta*eta2_M2]',n_x^2,1);

    sym2script_fvv;

    unique=nchoosek(n_x+2-1,2);
    unique=unique-nchoosek(n_x-1+1-1,1);

    Vx0=[gx*hx;gx;hx;speye(n_x)];
    Vx1=[gx;sparse(n_y,n_x);speye(n_x,n_x);sparse(n_x,n_x)];

    Ezeta2=[ sparse(n_x^2,n_x^2-1) , eta2_M2 ];

    A=innerkron(n_f,n_v,fvv,Vx0,Vx0)+innerkron(n_f,n_v,fvv,Vx1,Vx1)*Ezeta2;

    fy_fxp_fypgx=[fv(:,n_y+1:2*n_y) fv(:,2*n_y+1:2*n_y+n_x)+fv(:,1:n_y)*gx];

    G=fy_fxp_fypgx(:,1:n_f);
    H=fy_fxp_fypgx(:,n_f+1:n_f+n_x2);

    D=sparse(n_f,n_f);
    D(:,1:n_y)=fv(:,1:n_y);

    if n_x2==0
        CU2=A*U2;
    else % do not solve exogenous state variables (see appendix A.6 in the paper). H is the last block of G.
        CU2=A*U2+H*(nPhixx*U2);
    end

    W2BU2=(innerkron(unique,n_x,W2,hx,hx)+W2*Ezeta2)*U2;
    
    if strcmp(algo,'vectorize')
        X=reshape(-(kron(W2BU2',D)+kron(speye(unique),G))\CU2(:),n_f,unique)*W2;
    elseif strcmp(algo,'dlyap')
        X=dlyap(-G\D,W2BU2,-G\CU2)*W2;
    end

    gxx=X(1:n_y,:);
    hxx=[X(n_y+1:end,:);nPhixx;zeros(1,n_x^2)];
    disp(['2nd order completed in ' num2str(toc,'%15.2f') ' seconds'])
end


% Third Order
if approx>=3
    tic
  
    Vxx0=[chain2(gx,gxx,hx,hxx);gxx;hxx;sparse(n_x,n_x^2)];
    Vxx1=[gxx;sparse(n_y+2*n_x,n_x^2)];
    
    M3=M.M3(:);

    eta3_M3=reshape([eta*reshape(M3,n_e,n_e^2)]',n_e,n_e*n_x);
    eta3_M3=reshape([eta*eta3_M3]',n_e,n_x^2);
    eta3_M3=reshape([eta*eta3_M3]',n_x^3,1);

    Ezeta3=[ sparse(n_x^3,n_x^3-1) , eta3_M3 ];
    Ix=speye(n_x);
    Ix_Ezeta2=kron(Ix,Ezeta2);
    
    
    sym2script_fvvv;

    unique=nchoosek(n_x+3-1,3);
    unique=unique-nchoosek(n_x-1+2-1,2);

    A_third_order; % create matrix A of a third order solution
    if n_x2==0
        CU3=A*U3;
    else
        CU3=A*U3+H*(nPhixxx*U3);
    end
    WBU_third_order; % create the matrix W3BU3

    if strcmp(algo,'vectorize')
        X=reshape(-(kron(W3BU3',D)+kron(speye(unique),G))\CU3(:),n_f,unique)*W3;
    elseif strcmp(algo,'dlyap')
        X=dlyap(-G\D,W3BU3,-G\CU3)*W3;
    end

    gxxx=X(1:n_y,:);
    hxxx=[X(n_y+1:end,:);nPhixxx;zeros(1,n_x^3)];
    disp(['3rd order completed in ' num2str(toc,'%15.2f') ' seconds'])
end

% Fourth Order
if approx>=4
    tic

    Vxxx0=[chain3(gx,gxx,gxxx,hx,hxx,hxxx,OMEGA_x.OMEGA1);gxxx;hxxx;sparse(n_x,n_x^3)];
    Vxxx1=[gxxx;sparse(n_y+2*n_x,n_x^3)];
    
    M4=M.M4(:);

    eta4_M4=reshape([eta*reshape(M4,n_e,n_e^3)]',n_e,n_e^2*n_x);
    eta4_M4=reshape([eta*eta4_M4]',n_e,n_e*n_x^2);
    eta4_M4=reshape([eta*eta4_M4]',n_e,n_x^3);
    eta4_M4=reshape([eta*eta4_M4]',n_x^4,1);

    Ezeta4=[ sparse(n_x^4,n_x^4-1) , eta4_M4 ];
    Ix_Ezeta3=kron(Ix,Ezeta3);
    Ix2=speye(n_x^2);
    Ix2_Ezeta2=kron(Ix2,Ezeta2);
    
    hx2=kron(hx,hx);
    hx_Ezeta2_hx=kron(kron(hx,Ezeta2),hx);
    hx_Ezeta3=kron(hx,Ezeta3);
    hx2_Ezeta2=kron(hx2,Ezeta2);
    
    sym2script_fvvvv;

    unique=nchoosek(n_x+4-1,4);
    unique=unique-nchoosek(n_x-1+3-1,3);

    clear result R
    A_fourth_order; % create matrix A of a fourth order solution

    if n_x2==0
        CU4=A*U4;
    else
        CU4=A*U4+H*(nPhixxxx*U4);
    end
    WBU_fourth_order; % create the matrix W4BU4

    if strcmp(algo,'vectorize')
        X=reshape(-(kron(W4BU4',D)+kron(speye(unique),G))\CU4(:),n_f,unique)*W4;
    elseif strcmp(algo,'dlyap')
        X=dlyap(-G\D,W4BU4,-G\CU4)*W4;
    end
    
    gxxxx=X(1:n_y,:);
    hxxxx=[X(n_y+1:end,:);nPhixxxx;zeros(1,n_x^4)];
    disp(['4th order completed in ' num2str(toc,'%15.2f') ' seconds'])
end

% Fifth Order
if approx>=5
    tic

    Vxxxx0=[chain4(gx,gxx,gxxx,gxxxx,hx,hxx,hxxx,hxxxx,OMEGA_x.OMEGA2,OMEGA_x.OMEGA3,OMEGA_x.OMEGA4);gxxxx;hxxxx;sparse(n_x,n_x^4)];
    Vxxxx1=[gxxxx;sparse(n_y+2*n_x,n_x^4)];

    M5=M.M5(:);
    eta5_M5=reshape([eta*reshape(M5,n_e,n_e^4)]',n_e,n_e^3*n_x);
    eta5_M5=reshape([eta*eta5_M5]',n_e,n_e^2*n_x^2);
    eta5_M5=reshape([eta*eta5_M5]',n_e,n_e^1*n_x^3);
    eta5_M5=reshape([eta*eta5_M5]',n_e,n_x^4);
    eta5_M5=reshape([eta*eta5_M5]',n_x^5,1);

    sym2script_fvvvvv;

    clearvars -except n_f n_v n_x n_y n_x2 eta5_M5 Ix* *Ezeta* OMEGA_x U5 W5 gx* hx* nPhix* Vx* fv* fyp algo D G H approx

    Ezeta5=[ sparse(n_x^5,n_x^5-1) , eta5_M5 ];
    Ix_Ezeta4=kron(Ix,Ezeta4);
    Ix2_Ezeta3=kron(Ix2,Ezeta3);
    Ix3=speye(n_x^3);
    Ix3_Ezeta2=kron(Ix3,Ezeta2);

    hx3=kron(hx2,hx);
    hx3_Ezeta2=kron(hx3,Ezeta2);
    hx2_Ezeta3=kron(hx2,Ezeta3);
    hx_Ezeta4=kron(hx,Ezeta4);

    unique=nchoosek(n_x+5-1,5);
    unique=unique-nchoosek(n_x-1+4-1,4);

    A_fifth_order; % create matrix A of a fifth order solution
    
    if n_x2==0
        CU5=A*U5;
    else
        CU5=A*U5+H*(nPhixxxxx*U5);
    end
    WBU_fifth_order; % create the matrix W5BU5

    clearvars -except G D W5BU5 CU5 W5 gx* hx hxx* algo n_y nPhixxxxx n_x n_f unique approx
    
    if strcmp(algo,'vectorize')
        X=reshape(-(kron(W5BU5',D)+kron(speye(unique),G))\CU5(:),n_f,unique);
    elseif strcmp(algo,'dlyap')
        X=dlyap(-G\D,W5BU5,-G\CU5);
    end
    X=X*W5;
    gxxxxx=X(1:n_y,:);
    hxxxxx=[X(n_y+1:end,:);nPhixxxxx;zeros(1,n_x^5)];
    disp(['5th order completed in ' num2str(toc,'%15.2f') ' seconds'])
end

clear derivs
derivs.gx=full(gx);
derivs.hx=full(hx(1:end-1,:));
if approx>=2
    derivs.gxx=full(gxx);
    derivs.hxx=full(hxx(1:end-1,:));
end
if approx>=3
    derivs.gxxx=full(gxxx);
    derivs.hxxx=full(hxxx(1:end-1,:));
end
if approx>=4
    derivs.gxxxx=full(gxxxx);
    derivs.hxxxx=full(hxxxx(1:end-1,:));
end
if approx>=5
    derivs.gxxxxx=full(gxxxxx);
    derivs.hxxxxx=full(hxxxxx(1:end-1,:));
end




