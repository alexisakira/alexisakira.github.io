% This script creates the m files sym2script_nPhi.m.
% This file calculates the first, second, etc, derivatives of Phi 
% wrt to x, evaluated at the steady state. This is done in two steps.
% First, a compressed vector of unique derivatives is calculated. Second,
% the vecotr is uncompressed into a full symmetric tensor (mapped into a
% matrix).
% (c) Oren Levintal, November 20, 2013.



delete(['sym2script_nPhi.m']);
diary(['sym2script_nPhi.m']);

load('model','approx','Phi','x','n_x','n_x2','symparams')

tempstr='nPhi';
for i=1:approx
    xxxxx='x';
    for j=2:i
        xxxxx=[xxxxx 'x'];
    end
    tempstr=[tempstr ',nPhi' xxxxx];
end

Wargs='';
for i=2:5
    Wargs=[Wargs ',W' num2str(i)];
end

disp(['function [' tempstr ']=sym2script_nPhi(params,nxss,nyss' Wargs ')' ])

% Phix=jacobian(Phi, x); % derivative of Phi wrt x

if isempty(Phi)
    disp(['nPhi=zeros(0,1); nPhix=zeros(0,' num2str(n_x) '); nPhixx=zeros(0,' num2str(n_x^2) '); nPhixxx=zeros(0,' num2str(n_x^3) '); nPhixxxx=zeros(0,' num2str(n_x^4) '); nPhixxxxx=zeros(0,' num2str(n_x^5) ');'])
else
    for i=1:length(symparams)
        disp([char(symparams(i)) '=params(' num2str(i) ');']);
    end
    for i=1:n_x
        disp([char(x(i)) '=nxss(' num2str(i) ');']);
    end

    disp(['nPhi=zeros(' num2str(n_x2) ',1);' ]);
    for i=1:numel(Phi)
        if isequal(char(Phi(i,1)),'0')==0
            disp(['nPhi(' num2str(i) ',1)=' char(Phi(i,1)) ';' ]);
        end
    end
    
    Phix=jacobian(Phi, x); % derivative of Phi wrt x
    disp(['nPhix=zeros(' num2str(n_x2) ',' num2str(n_x) ');' ]);
    for i=1:numel(Phix)
        if isequal(char(Phix(i)),'0')==0
            disp(['nPhix(' num2str(i) ')=' char(Phix(i)) ';' ]);
        end
    end

    % 2. Create Phixx
    if approx>=2
        clear Phi
        load('UW','UW'); U2=UW.U2; clear UW

        Phixx=reshape(jacobian(Phix(:), x),n_x2,n_x^2); % the second derivative of Phi wrt x
        Phixxbar=Phixx*U2; % compress Phixx
        Phixxbar=Phixxbar(:); % vectorize
        countdf=zeros(size(Phixxbar)); % this will count nonzero derivatives.
        % print compressed derivatives to file
        disp(['if isempty(W2)==0'])
        disp(['Phixxbar=sparse(' num2str(n_x2) ',' num2str(numel(Phixxbar)/n_x2) ');' ]); % bar means compressed
        for i=1:numel(Phixxbar)
            if isequal(char(Phixxbar(i)),'0')==0
                disp_deriv( 'Phixxbar',i,Phixxbar )
                countdf(i)=1;
            end
        end
        disp(['nPhixx=Phixxbar*W2;' ])
        disp('else')
        disp('nPhixx=[];')
        disp('end')
    end
    % 3. Create Phixxx
    if approx>=3
        clear Phix U2
        load('UW','UW'); U3=UW.U3; W2=UW.W2; clear UW
        k=3;
        Phixxx=jacobian(Phixxbar(:), x); % differentiate
        % create index to compress Phixxx
        index=reshape([1:numel(Phixxx)],numel(Phixxx)/n_x,n_x);
        index=[reshape([reshape(index',n_x*n_x2,nchoosek(n_x+k-2,k-1)-nchoosek(n_x-1+k-3,k-2))*W2]',n_x^k,n_x2)]'*U3;
        index=index(:);
        Phixxxbar=Phixxx(index); % compress
        disp(['if isempty(W3)==0'])
        disp(['Phixxxbar=sparse(' num2str(n_x2) ',' num2str(numel(Phixxxbar)/n_x2) ');' ]); % bar means compressed

        tempmat=repmat(countdf,1,n_x);
        tempmat=tempmat(index); % compress
        order=[1:length(Phixxxbar)]';
        nonzero_df=order(tempmat>0); % this is an index of fourth derivatives obtained by differentiating nonzero third derivatives.
        countdf=zeros(size(Phixxxbar));
        for i=nonzero_df'
            if isequal(char(Phixxxbar(i)),'0')==0
                disp_deriv( 'Phixxxbar',i,Phixxxbar )
                countdf(i)=1;
            end
        end
        disp(['nPhixxx=Phixxxbar*W3;' ])
        disp('else')
        disp('nPhixxx=[];')
        disp('end')
   end


    % 4. Create Phixxxx

    if approx>=4
        clear Phixxbar W2 U3
        load('UW','UW'); U4=UW.U4; W3=UW.W3; clear UW
        k=4;
        Phixxxx=jacobian(Phixxxbar(:), x); % differentiate
        % create index to compress Phixxx
        index=reshape([1:numel(Phixxxx)],numel(Phixxxx)/n_x,n_x);
        index=[reshape([reshape(index',n_x*n_x2,nchoosek(n_x+k-2,k-1)-nchoosek(n_x-1+k-3,k-2))*W3]',n_x^k,n_x2)]'*U4;
        index=index(:);
        Phixxxxbar=Phixxxx(index); % compress

        disp(['if isempty(W4)==0'])
        disp(['Phixxxxbar=sparse(' num2str(n_x2) ',' num2str(numel(Phixxxxbar)/n_x2) ');' ]); % bar means compressed

        tempmat=repmat(countdf,1,n_x);
        tempmat=tempmat(index); % compress
        order=[1:length(Phixxxxbar)]';
        nonzero_df=order(tempmat>0); % this is an index of fourth derivatives obtained by differentiating nonzero third derivatives.
        countdf=zeros(size(Phixxxxbar));
        for i=nonzero_df'
            if isequal(char(Phixxxxbar(i)),'0')==0
                disp_deriv( 'Phixxxxbar',i,Phixxxxbar )
                countdf(i)=1;
            end
        end
        disp(['nPhixxxx=Phixxxxbar*W4;' ])
        disp('else')
        disp('nPhixxxx=[];')
        disp('end')
    end

    % 5. Create Phixxxxx

    if approx>=5
        clear Phixxxbar W3 U4
        load('UW','UW'); U5=UW.U5; W4=UW.W4; clear UW
        k=5;
        Phixxxxx=jacobian(Phixxxxbar(:), x); % differentiate
        % create index to compress Phixxx
        index=reshape([1:numel(Phixxxxx)],numel(Phixxxxx)/n_x,n_x);
        index=[reshape([reshape(index',n_x*n_x2,nchoosek(n_x+k-2,k-1)-nchoosek(n_x-1+k-3,k-2))*W4]',n_x^k,n_x2)]'*U5;
        index=index(:);
        Phixxxxxbar=Phixxxxx(index); % compress

        disp(['if isempty(W5)==0'])
        disp(['Phixxxxxbar=sparse(' num2str(n_x2) ',' num2str(numel(Phixxxxxbar)/n_x2) ');' ]); % bar means compressed

        tempmat=repmat(countdf,1,n_x);
        tempmat=tempmat(index); % compress
        order=[1:length(Phixxxxxbar)]';
        nonzero_df=order(tempmat>0); % this is an index of fourth derivatives obtained by differentiating nonzero third derivatives.
        countdf=zeros(size(Phixxxxxbar));
        for i=nonzero_df'
            if isequal(char(Phixxxxxbar(i)),'0')==0
                disp_deriv( 'Phixxxxxbar',i,Phixxxxxbar )
                countdf(i)=1;
            end
        end
        disp(['nPhixxxxx=Phixxxxxbar*W5;' ])
        disp('else')
        disp('nPhixxxxx=[];')
        disp('end')
    end
end
disp('end')
diary off