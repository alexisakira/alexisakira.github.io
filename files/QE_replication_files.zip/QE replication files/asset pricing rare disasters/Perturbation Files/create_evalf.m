function create_evalf(f,symparams,u,fname)

delete(['eval_' fname '.m'])
diary(['eval_' fname '.m'])
disp(['function f_function=eval_' fname '(u_variables,params_parameters)'])
for i=1:length(symparams)
    disp([char(symparams(i)) '=params_parameters(' num2str(i) ');']);
end
for i=1:length(u)
    disp([char(u(i)) '=u_variables(' num2str(i) ');']);
end
disp(['f_function=zeros(' num2str(length(f)) ',1);'])
for i=1:length(f)
    disp(['f_function(' num2str(i) ')=' char(f(i)) ';']);
end
diary 'off'