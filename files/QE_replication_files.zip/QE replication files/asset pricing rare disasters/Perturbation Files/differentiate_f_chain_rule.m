% This script differentiates f. If u is nonempty then chain rules are used
% to differentiate f(u(v)). If u is empty then f(v) is differentiated
% directly.
% The script generates various indices that are
% necessary for uncompressing matrices of derivatives.
% (c) Oren Levintal, August 14, 2014.

clear
load('model','f','v', 'ufun', 'u', 'x','xp','y','yp','symparams','n_x','n_y','n_v','n_f','n_u','approx','chainrules')

full_f=f;

for frow=1:n_f
    sfrow=num2str(frow);
    if strcmp(sfrow(end),'1')
        temps='st';
    elseif strcmp(sfrow(end),'2')
        temps='nd';
    elseif strcmp(sfrow(end),'3')
        temps='rd';
    else
        temps='th';
    end
    if frow==11 | frow==12 | frow==13
        temps='th';
    end
    disp(['Differentiating the ' sfrow temps ' row of f ...'])
  
    f=full_f(frow); 
    
    df1=jacobian(f, u); % derivative of f w.r.t u
    if n_u==1
        nnzu=1;
    else
        nnzdf1=1-logical(df1==0);
        [tempvar nnzu]=find(nnzdf1); % nnzu records the arguments of f(frow)
    end
    [df1 Mf1 df2 Mf2 df3 Mf3 df4 Mf4 df5 Mf5]=get_derivs(f,u(nnzu),approx); % differentiate f(frow) w.r.t to its arguments
    du1=jacobian(ufun(nnzu), v); 
    if n_u==1
        nnzv=1;
    else
        nnzdu1=1-logical(du1==0);
        [rowuv nnzv]=find(nnzdu1); % nnzv records the arguments of ufun(nnzu)
        nnzv=unique(nnzv);
    end
    % create indices that index the location of the nonzero derivatives of ufun(nnzu)
    % w.r.t v(nnzv) in the full matrix of derivatives of ufun(nnzu) w.r.t
    % v(:).
    n_uvars=length(nnzu);
    n_vvars=length(nnzv);
    nnzdu1=1-logical(du1==0);
    [rowuv coluv]=find(nnzdu1(:,nnzv));
    indu1=sub2ind([n_uvars,n_vvars],rowuv,coluv);
    if approx>=2
        indu2=sub2ind([n_uvars,n_vvars,n_vvars],rowuv,coluv,coluv);
    end
    if approx>=3
        indu3=sub2ind([n_uvars,n_vvars,n_vvars,n_vvars],rowuv,coluv,coluv,coluv);
    end
    if approx>=4
        indu4=sub2ind([n_uvars,n_vvars,n_vvars,n_vvars,n_vvars],rowuv,coluv,coluv,coluv,coluv);
    end
    if approx>=5
        indu5=sub2ind([n_uvars,n_vvars,n_vvars,n_vvars,n_vvars,n_vvars],rowuv,coluv,coluv,coluv,coluv,coluv);
    end
    % create indices that index the location of the derivatives of f(frow)
    % w.r.t v(nnzv) in the full matrix of derivatives of f(frow) w.r.t
    % v(:).
    indf1=nnzv;
    if approx>=2
        tempmat1=repmat(nnzv(:),1,length(nnzv));
        tempmat2=repmat(nnzv(:)',length(nnzv),1);
        indf2=sub2ind([n_v,n_v],tempmat1(:),tempmat2(:));
    end
    if approx>=3
        tempmat1=repmat(tempmat1(:),1,length(nnzv));
        tempmat2=repmat(tempmat2(:),1,length(nnzv));
        tempmat3=repmat(nnzv(:)',size(tempmat1,1),1);
        indf3=sub2ind([n_v,n_v,n_v],tempmat1(:),tempmat2(:),tempmat3(:));
    end
    if approx>=4
        tempmat1=repmat(tempmat1(:),1,length(nnzv));
        tempmat2=repmat(tempmat2(:),1,length(nnzv));
        tempmat3=repmat(tempmat3(:),1,length(nnzv));
        tempmat4=repmat(nnzv(:)',size(tempmat1,1),1);
        indf4=sub2ind([n_v,n_v,n_v,n_v],tempmat1(:),tempmat2(:),tempmat3(:),tempmat4(:));
    end
    if approx>=5
        tempmat1=repmat(tempmat1(:),1,length(nnzv));
        tempmat2=repmat(tempmat2(:),1,length(nnzv));
        tempmat3=repmat(tempmat3(:),1,length(nnzv));
        tempmat4=repmat(tempmat4(:),1,length(nnzv));
        tempmat5=repmat(nnzv(:)',size(tempmat1,1),1);
        indf5=sub2ind([n_v,n_v,n_v,n_v,n_v],tempmat1(:),tempmat2(:),tempmat3(:),tempmat4(:),tempmat5(:));
    end
    
    % Give names to derivatives of f(frow) and to indices indu1-indu5,
    % indf1-indf5, create rows and cols of Mf1-Mf5 and save.
    eval(['nnzu_' num2str(frow) '=nnzu;'])
    eval(['nnzv_' num2str(frow) '=nnzv;'])
    eval(['rowuv_' num2str(frow) '=rowuv;'])
    eval(['fu_' num2str(frow) '=df1;'])
    eval(['indu1_' num2str(frow) '=indu1;'])
    eval(['indf1_' num2str(frow) '=indf1;'])
    [row col]=find(Mf1);
    eval(['rowMf1_' num2str(frow) '=row;'])
    eval(['colMf1_' num2str(frow) '=col;'])
    if approx>=2
        eval(['fuu_' num2str(frow) '=df2;'])
        eval(['indu2_' num2str(frow) '=indu2;'])
        eval(['indf2_' num2str(frow) '=indf2;'])
        [row col]=find(Mf2);
        eval(['rowMf2_' num2str(frow) '=row;'])
        eval(['colMf2_' num2str(frow) '=col;'])
    end
    if approx>=3
        eval(['fuuu_' num2str(frow) '=df3;'])
        eval(['indu3_' num2str(frow) '=indu3;'])
        eval(['indf3_' num2str(frow) '=indf3;'])
        [row col]=find(Mf3);
        eval(['rowMf3_' num2str(frow) '=row;'])
        eval(['colMf3_' num2str(frow) '=col;'])
    end
    if approx>=4
        eval(['fuuuu_' num2str(frow) '=df4;'])
        eval(['indu4_' num2str(frow) '=indu4;'])
        eval(['indf4_' num2str(frow) '=indf4;'])
        [row col]=find(Mf4);
        eval(['rowMf4_' num2str(frow) '=row;'])
        eval(['colMf4_' num2str(frow) '=col;'])
    end
    if approx>=5
        eval(['fuuuuu_' num2str(frow) '=df5;'])
        eval(['indu5_' num2str(frow) '=indu5;'])
        eval(['indf5_' num2str(frow) '=indf5;'])
        [row col]=find(Mf5);
        eval(['rowMf5_' num2str(frow) '=row;'])
        eval(['colMf5_' num2str(frow) '=col;'])
    end
end
clear full_f
save('f_ind','nnzu_*','rowuv_*','indu*_*','indf*_*','rowMf*_*','colMf*_*');
f_ind=load('f_ind','nnzu_*','rowuv_*','indu*_*','indf*_*','rowMf*_*','colMf*_*');
save('f_ind','f_ind');
clear f_ind

if chainrules==1
    full_u=ufun;
    u_deriv=sym(zeros(n_u,approx));
    for urow=1:n_u
        surow=num2str(urow);
        if strcmp(surow(end),'1')
            temps='st';
        elseif strcmp(surow(end),'2')
            temps='nd';
        elseif strcmp(surow(end),'3')
            temps='rd';
        else
            temps='th';
        end
        if urow==11 | frow==12 | frow==13
            temps='th';
        end
        disp(['Differentiating the ' surow temps ' row of u ...'])

        ufun=full_u(urow); 

        du1=jacobian(ufun, v); % derivative of u wrt v
        if n_v==1
            nnzv=1;
        else
            nnzdu1=1-logical(du1==0);
            [tempvar nnzv]=find(nnzdu1); % nnzu=nonzero derivatives wrt u
        end
        if length(nnzv)>1
            error([' The ' num2str(urow) temps ' for of ufun is not a univariate function.'])
        end

        du1=du1(nnzv);
        u_derivs(urow,1)=du1;
        if approx>=2
            du2=jacobian(du1,v(nnzv));
            u_derivs(urow,2)=du2;
        end
        if approx>=3
            du3=jacobian(du2,v(nnzv));
            u_derivs(urow,3)=du3;
        end
        if approx>=4
            du4=jacobian(du3,v(nnzv));
            u_derivs(urow,4)=du4;
        end
        if approx>=5
            du5=jacobian(du4,v(nnzv));
            u_derivs(urow,5)=du5;
        end
    end

    % create evalu_derivs.m which evaluates the symbolic derivatives of ufun

    delete(['evalu_derivs.m']);
    diary(['evalu_derivs.m']);

    disp(['function numu_derivs=evalu_derivs(params,nxss,nyss,approx)'])
    for i=1:length(symparams)
        disp([char(symparams(i)) '=params(' num2str(i) ');']);
    end
    for i=1:n_x
        disp([char(x(i)) '=nxss(' num2str(i) ');']);
        disp([char(xp(i)) '=nxss(' num2str(i) ');']);
    end
    for i=1:n_y
        disp([char(y(i)) '=nyss(' num2str(i) ');']);
        disp([char(yp(i)) '=nyss(' num2str(i) ');']);
    end
    disp(['numu_derivs=zeros(' num2str(size(u_derivs,1)) ',approx);'])
    for n=1:approx
        disp(['if approx>=' num2str(n) ])
        disp(['    derivs=zeros(' num2str(size(u_derivs,1)) ',1);'])
        for i=1:size(u_derivs,1)
            if u_derivs(i,n)~=0
                disp_deriv( '    derivs',i,u_derivs(:,n) );
            end
        end
        disp(['    numu_derivs(:,' num2str(n) ')=derivs;'])
        disp('end')
    end
    diary 'off'
else
    delete(['evalu_derivs.m']);
    diary(['evalu_derivs.m']);
    disp(['function numu_derivs=evalu_derivs(params,nxss,nyss,approx)'])
    disp(['% this function is active only when u is not empty'])
    disp(['numu_derivs=[];'])
    diary 'off'
end


% create evalf_derivs.m which evaluates the symbolic derivatives of f w.r.t
% u, and create call_evalf_derivs.m which calls the former function.

delete(['call_evalf_derivs.m']);
diary(['call_evalf_derivs.m']);

for i=1:approx
    textu='';
    for j=1:i
        textu=[textu 'u'];
    end

    alldf=['f' textu '_1'];
    for j=2:n_f
        alldf=[alldf ',f' textu '_' num2str(j)];
    end
    if approx==1
        disp(['[' alldf ']=...'])
    elseif approx>1 && i==1
        disp(['[' alldf ',...'])
    elseif approx>1 && i>1 && i<approx
        disp([alldf ',...'])
    elseif approx>1 && i>1 && i==approx
        disp([alldf ']=...'])
    end
end

disp(['evalf_derivs(params,nuss,approx);'])
diary 'off'

delete(['evalf_derivs.m']);
diary(['evalf_derivs.m']);

for i=1:approx
    textu='';
    for j=1:i
        textu=[textu 'u'];
    end

    alldf=['f' textu '_1'];
    for j=2:n_f
        alldf=[alldf ',f' textu '_' num2str(j)];
    end
    if approx==1
        disp(['function [' alldf ']=...'])
    elseif approx>1 && i==1
        disp(['function [' alldf ',...'])
    elseif approx>1 && i>1 && i<approx
        disp([alldf ',...'])
    elseif approx>1 && i>1 && i==approx
        disp([alldf ']=...'])
    end
end

disp(['evalf_derivs(params,nuss,approx)'])
for i=1:length(symparams)
    disp([char(symparams(i)) '=params(' num2str(i) ');']);
end
for i=1:n_u
    disp([char(u(i)) '=nuss(' num2str(i) ');']);
end

for i=1:approx
    textu='';
    for j=1:i
        textu=[textu 'u'];
    end
    for j=1:n_f
        disp(['f' textu '_' num2str(j) '=[];']);
    end
end

for n=1:approx
    textu='';
    for i=1:n
        textu=[textu 'u'];
    end
    disp(['if approx>=' num2str(n) ])
    for j=1:n_f
        eval(['deriv=f' textu '_' num2str(j) ';'])
        disp(['    f' textu '_' num2str(j) '=zeros(' num2str(size(deriv,1)) ',1);'])
        for i=1:size(deriv,1)
            if deriv(i)~=0
                disp_deriv(['    f' textu '_' num2str(j)],i,deriv );
            end
        end
    end
    disp('end')
end
diary 'off'

% create sym2script_fv.m-sum2script_fvvvvv.m which calculate the
% derivatives of f w.r.t v using high order chain rules.

delete(['sym2script_fv.m']);
diary(['sym2script_fv.m']);

disp(['fv=sparse(' num2str(n_f) ',' num2str(n_v) ');' ]);
for i=1:n_f
    eval(['symderiv=fu_' num2str(i) ';'])
    eval(['rowMf1=rowMf1_' num2str(i) ';'])
    eval(['colMf1=colMf1_' num2str(i) ';'])
    eval(['nnzu=nnzu_' num2str(i) ';'])
    eval(['nnzv=nnzv_' num2str(i) ';'])
    disp(['full_fu_' num2str(i) '=sparse(f_ind.rowMf1_' num2str(i) ',ones(' num2str(length(rowMf1)) ',1),fu_' num2str(i) '(f_ind.colMf1_' num2str(i) '),' num2str(length(nnzu)) ',1)' '''' ';'])
    if chainrules==1
        disp(['full_uv_' num2str(i) '=zeros(' num2str(length(nnzu)) ',' num2str(length(nnzv)) ');'])
        disp(['full_uv_' num2str(i) '(f_ind.indu1_' num2str(i) ')=numu_derivs(f_ind.nnzu_' num2str(i) '(f_ind.rowuv_' num2str(i) '),1);'])
        disp(['fv(' num2str(i) ',f_ind.indf1_' num2str(i) ')=full_fu_' num2str(i) '*full_uv_' num2str(i) ';'])
    else
        disp(['fv(' num2str(i) ',f_ind.indf1_' num2str(i) ')=full_fu_' num2str(i) ';'])
    end
end
diary off

if approx>=2
delete(['sym2script_fvv.m']);
diary(['sym2script_fvv.m']);

disp(['fvv=sparse(' num2str(n_f*n_v^2) ',1);' ]);
    for i=1:n_f
        eval(['symderiv=fuu_' num2str(i) ';'])
        eval(['rowMf2=rowMf2_' num2str(i) ';'])
        eval(['colMf2=colMf2_' num2str(i) ';'])
        eval(['nnzu=nnzu_' num2str(i) ';'])
        eval(['nnzv=nnzv_' num2str(i) ';'])
        disp(['full_fuu_' num2str(i) '=sparse(f_ind.rowMf2_' num2str(i) ',ones(' num2str(length(rowMf2)) ',1),fuu_' num2str(i) '(f_ind.colMf2_' num2str(i) '),' num2str(length(nnzu)^2) ',1)' '''' ';'])
        if chainrules==1
            disp(['full_uvv_' num2str(i) '=zeros(' num2str(length(nnzu)) ',' num2str(length(nnzv)^2) ');'])
            disp(['full_uvv_' num2str(i) '(f_ind.indu2_' num2str(i) ')=numu_derivs(f_ind.nnzu_' num2str(i) '(f_ind.rowuv_' num2str(i) '),2);'])
            disp(['tempchain2=chain2(full_fu_' num2str(i) ',full_fuu_' num2str(i) ',full_uv_' num2str(i) ',full_uvv_' num2str(i) ');'])
            disp(['fvv((f_ind.indf2_' num2str(i) '-1)*' num2str(n_f) '+' num2str(i) ')=tempchain2(:);'])
        else
            disp(['fvv((f_ind.indf2_' num2str(i) '-1)*' num2str(n_f) '+' num2str(i) ')=full_fuu_' num2str(i) '(:);'])
        end
    end
    diary off
end

if approx>=3
delete(['sym2script_fvvv.m']);
diary(['sym2script_fvvv.m']);

disp(['fvvv=sparse(' num2str(n_f*n_v^3) ',1);' ]);
    for i=1:n_f
        eval(['symderiv=fuuu_' num2str(i) ';'])
        eval(['rowMf3=rowMf3_' num2str(i) ';'])
        eval(['colMf3=colMf3_' num2str(i) ';'])
        eval(['nnzu=nnzu_' num2str(i) ';'])
        eval(['nnzv=nnzv_' num2str(i) ';'])
        disp(['full_fuuu_' num2str(i) '=sparse(f_ind.rowMf3_' num2str(i) ',ones(' num2str(length(rowMf3)) ',1),fuuu_' num2str(i) '(f_ind.colMf3_' num2str(i) '),' num2str(length(nnzu)^3) ',1)' '''' ';'])
        if chainrules==1
            disp(['full_uvvv_' num2str(i) '=zeros(' num2str(length(nnzu)) ',' num2str(length(nnzv)^3) ');'])
            disp(['full_uvvv_' num2str(i) '(f_ind.indu3_' num2str(i) ')=numu_derivs(f_ind.nnzu_' num2str(i) '(f_ind.rowuv_' num2str(i) '),3);'])
            tempOMEGA=create_OMEGA(length(nnzv),3);
            eval(['OMEGA_v.OMEGA1.f_' num2str(i) '=tempOMEGA.OMEGA1;'])
            disp(['tempchain3=chain3(full_fu_' num2str(i) ',full_fuu_' num2str(i)  ',full_fuuu_' num2str(i)  ',full_uv_' num2str(i) ',full_uvv_' num2str(i) ',full_uvvv_' num2str(i) ',OMEGA_v.OMEGA1.f_' num2str(i) ');'])
            disp(['fvvv((f_ind.indf3_' num2str(i) '-1)*' num2str(n_f) '+' num2str(i) ')=tempchain3(:);'])
        else
            disp(['fvvv((f_ind.indf3_' num2str(i) '-1)*' num2str(n_f) '+' num2str(i) ')=full_fuuu_' num2str(i)  '(:);'])
        end
    end
    diary off
end

if approx>=4
delete(['sym2script_fvvvv.m']);
diary(['sym2script_fvvvv.m']);

disp(['fvvvv=sparse(' num2str(n_f*n_v^4) ',1);' ]);
    for i=1:n_f
        eval(['symderiv=fuuuu_' num2str(i) ';'])
        eval(['rowMf4=rowMf4_' num2str(i) ';'])
        eval(['colMf4=colMf4_' num2str(i) ';'])
        eval(['nnzu=nnzu_' num2str(i) ';'])
        eval(['nnzv=nnzv_' num2str(i) ';'])
        disp(['full_fuuuu_' num2str(i) '=sparse(f_ind.rowMf4_' num2str(i) ',ones(' num2str(length(rowMf4)) ',1),fuuuu_' num2str(i) '(f_ind.colMf4_' num2str(i) '),' num2str(length(nnzu)^4) ',1)' '''' ';'])
        if chainrules==1
            disp(['full_uvvvv_' num2str(i) '=zeros(' num2str(length(nnzu)) ',' num2str(length(nnzv)^4) ');'])
            disp(['full_uvvvv_' num2str(i) '(f_ind.indu4_' num2str(i) ')=numu_derivs(f_ind.nnzu_' num2str(i) '(f_ind.rowuv_' num2str(i) '),4);'])
            tempOMEGA=create_OMEGA(length(nnzv),4);
            eval(['OMEGA_v.OMEGA2.f_' num2str(i) '=tempOMEGA.OMEGA2;'])
            eval(['OMEGA_v.OMEGA3.f_' num2str(i) '=tempOMEGA.OMEGA3;'])
            eval(['OMEGA_v.OMEGA4.f_' num2str(i) '=tempOMEGA.OMEGA4;'])
            disp(['tempchain4=chain4(full_fu_' num2str(i) ',full_fuu_' num2str(i)  ',full_fuuu_' num2str(i) ',full_fuuuu_' num2str(i) ',full_uv_' num2str(i) ',full_uvv_' num2str(i) ',full_uvvv_' num2str(i) ',full_uvvvv_' num2str(i) ',OMEGA_v.OMEGA2.f_' num2str(i) ',OMEGA_v.OMEGA3.f_' num2str(i) ',OMEGA_v.OMEGA4.f_' num2str(i) ');'])
            disp(['fvvvv((f_ind.indf4_' num2str(i) '-1)*' num2str(n_f) '+' num2str(i) ')=tempchain4(:);'])
        else
            disp(['fvvvv((f_ind.indf4_' num2str(i) '-1)*' num2str(n_f) '+' num2str(i) ')=full_fuuuu_' num2str(i) '(:);'])
        end
    end
    diary off
end

if approx>=5
delete(['sym2script_fvvvvv.m']);
diary(['sym2script_fvvvvv.m']);

disp(['fvvvvv_row=zeros(1e6,1);' ]);
disp(['fvvvvv_col=zeros(1e6,1);' ]);
disp(['fvvvvv_cell=zeros(1e6,1);' ]);
disp(['count=1;' ]);

    for i=1:n_f
        disp(['if count-1+length(f_ind.indf5_' num2str(i) ')>1e6' ])
        disp(['    fvvvvv_row=[fvvvvv_row;zeros(1e6,1)];' ]);
        disp(['    fvvvvv_col=[fvvvvv_col;zeros(1e6,1)];' ]);
        disp(['    fvvvvv_cell=[fvvvvv_cell;zeros(1e6,1)];' ]);
        disp(['end'])
        eval(['symderiv=fuuuuu_' num2str(i) ';'])
        eval(['rowMf5=rowMf5_' num2str(i) ';'])
        eval(['colMf5=colMf5_' num2str(i) ';'])
        eval(['nnzu=nnzu_' num2str(i) ';'])
        eval(['nnzv=nnzv_' num2str(i) ';'])
        disp(['full_fuuuuu_' num2str(i) '=sparse(f_ind.rowMf5_' num2str(i) ',ones(' num2str(length(rowMf5)) ',1),fuuuuu_' num2str(i) '(f_ind.colMf5_' num2str(i) '),' num2str(length(nnzu)^5) ',1)' '''' ';'])
        if chainrules==1
            disp(['full_uvvvvv_' num2str(i) '=zeros(' num2str(length(nnzu)) ',' num2str(length(nnzv)^5) ');'])
            disp(['full_uvvvvv_' num2str(i) '(f_ind.indu5_' num2str(i) ')=numu_derivs(f_ind.nnzu_' num2str(i) '(f_ind.rowuv_' num2str(i) '),5);'])
            tempOMEGA=create_OMEGA(length(nnzv),5);
            eval(['OMEGA_v.OMEGA5.f_' num2str(i) '=tempOMEGA.OMEGA5;'])
            eval(['OMEGA_v.OMEGA6.f_' num2str(i) '=tempOMEGA.OMEGA6;'])
            eval(['OMEGA_v.OMEGA7.f_' num2str(i) '=tempOMEGA.OMEGA7;'])
            eval(['OMEGA_v.OMEGA8.f_' num2str(i) '=tempOMEGA.OMEGA8;'])
            eval(['OMEGA_v.OMEGA9.f_' num2str(i) '=tempOMEGA.OMEGA9;'])

            disp(['tempchain5=chain5(full_fu_' num2str(i) ',full_fuu_' num2str(i)  ',full_fuuu_' num2str(i) ',full_fuuuu_' num2str(i) ',full_fuuuuu_' num2str(i) ',full_uv_' num2str(i) ',full_uvv_' num2str(i) ',full_uvvv_' num2str(i) ',full_uvvvv_' num2str(i) ',full_uvvvvv_' num2str(i) ',OMEGA_v.OMEGA5.f_' num2str(i) ',OMEGA_v.OMEGA6.f_' num2str(i) ',OMEGA_v.OMEGA7.f_' num2str(i) ',OMEGA_v.OMEGA8.f_' num2str(i) ',OMEGA_v.OMEGA9.f_' num2str(i) ');'])
            disp(['fvvvvv_cell(count:count-1+length(f_ind.indf5_' num2str(i) '))=tempchain5(:);'])
        else
            disp(['fvvvvv_cell(count:count-1+length(f_ind.indf5_' num2str(i) '))=full_fuuuuu_' num2str(i) '(:);'])
        end
        disp(['fvvvvv_row(count:count-1+length(f_ind.indf5_' num2str(i) '))=' num2str(i) ';'])
        disp(['fvvvvv_col(count:count-1+length(f_ind.indf5_' num2str(i) '))=f_ind.indf5_' num2str(i) ';'])
        disp(['count=count+length(f_ind.indf5_' num2str(i) ');' ]);
    end
    disp(['fvvvvv_row=fvvvvv_row(1:count-1);'])
    disp(['fvvvvv_col=fvvvvv_col(1:count-1);'])
    disp(['fvvvvv_cell=fvvvvv_cell(1:count-1);'])
    disp(['ind=(fvvvvv_col-1)*' num2str(n_f) '+fvvvvv_row;'])
    disp(['[i1,j1]=ind2sub([' num2str(n_f*n_v^4) ',' num2str(n_v) '],ind);'])
    disp(['fvvvvv=sparse(i1,j1,fvvvvv_cell,' num2str(n_f*n_v^4) ',' num2str(n_v) ');'])
    diary off
end

if chainrules==0
    OMEGA_v=[];
end

save('OMEGA_v','OMEGA_v')