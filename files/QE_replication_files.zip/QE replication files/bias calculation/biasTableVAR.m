% VAR(1) example in GL
b = zeros(2,1);
B = [0.9809 0.0028; 0.0410 0.9648];
Psi = diag([0.0087 0.0262].^2);
K = size(B,1);

Nm = 5;

nSigma = sqrt((Nm-1));

bias = zeros(5,7);
elTime = zeros(1,7);
indUV = [1 4 3]';

warning off;

% Tauchen
tic
[P,X] = tauchenOptimized(b,B,Psi,Nm);
elTime(1) = toc;
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,1) = [biasUV(indUV);biasEig];

% Tauchen-Hussey
tic
[P,X] = tauchenHussey(b,B,Psi,Nm);
elTime(2) = toc;
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,2) = [biasUV(indUV);biasEig];


% GL0
tic
[PN, YN] = var_Markov_MM(B,Psi,Nm,0);
elTime(3) = toc;
P = PN';
X = YN';
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,3) = [biasUV(indUV);biasEig];

% GL1
tic
[PN, YN] = var_Markov_MM(B,Psi,Nm,999);
elTime(4) = toc;
P = PN';
X = YN';
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,4) = [biasUV(indUV);biasEig];

% ME-Even (2)
tic
[P,X] = discreteVAR(b,B,Psi,Nm,2,'even',nSigma);
elTime(5) = toc;
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,5) = [biasUV(indUV);biasEig];

% ME-Even (4)
%tic
%[P,X] = discreteVARTemp(b,B,Psi,Nm,4,'even');
%toc
%[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
%bias(:,6) = [biasUV(indUV);biasEig];

% ME-Quant
tic
[P,X] = discreteVAR(b,B,Psi,Nm,2,'quantile');
elTime(6) = toc;
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,6) = [biasUV(indUV);biasEig];

% ME-Quad
tic
[P,X] = discreteVAR(b,B,Psi,Nm,2,'quadrature');
elTime(7) = toc;
[biasEig,biasUV,~] = biasVAR(B,Psi,P,X);
bias(:,7) = [biasUV(indUV);biasEig];

logbias = log10(abs(bias));

input.data = logbias;
input.dataFormat = {'%-.3f'};
input.tableBorders = 0;
input.tableColLabels = {'Tauchen','TH','GL0','GL1','Even','Quant','Quad'};
%input.tableRowLabels = {};
input.makeCompleteLatexDocument = 0;

latexTable(input)

warning on;

load elTime
elTable.data = [elTime5; elTime9; elTime15; elTime21];
elTable.dataFormat = {'%-.3f'};
elTable.tableBorders = 0;
elTable.tableColLabels = {'Tauchen','TH','GL0','GL1','Even','Quant','Quad'};
%elTable.tableRowLabels = {};
elTable.makeCompleteLatexDocument = 0;
latexTable(elTable)

