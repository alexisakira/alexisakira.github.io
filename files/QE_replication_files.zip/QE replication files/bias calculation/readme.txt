biasTableVAR.m outputs the bias of VAR discretization in appendix.
Nm on line 7 sets the number of grid points in each dimension.

biasTableSV.m outputs the bias of stochastic volatility discretization in appendix.
N on line 10 sets the number of grid points in each dimension.