function [biasLambda,biasUV] = biasSV(lambda,rho,sigmaU,sigmaE,P,X)
% biasSV
% calculate the relative bias of 1-lambda and unconditional
% variance, where lambda, rho, sigmaU, sigmaE as in discreteSV.m.
% P, xyGrids: transition probability and grid points of any Markov chain

%% Compute some uncondtional moments

sigmaX = (sigmaE^2)/(1-rho^2); % unconditional variance of variance process
xBar = 2*log(sigmaU)-sigmaX/2; % unconditional mean of variance process, targeted to match a mean standard deviation of sigmaU
UV = exp(xBar+sigmaX/2)/(1-lambda^2); % uncondtional variance of technology shock

%% Compute stationary distribution
[eigvec,~] = eigs(P',1); % eigenvector of P'
pi = eigvec/sum(eigvec); % stationary distribution

%% OLS coefficient
% compute population OLS estimate of y' = beta1 + beta2*y + u', or equivalently
% y' = [beta1 beta2][1;y] + u'
[M,N] = size(X); % number of states
reg = [ones(1,N);X]; % regressor when estimating VAR(1); corresponds to x
temp = bsxfun(@times,pi,reg');
Exx = reg*temp; % matrix of population second moments, E[xx']
condMean = X*P'; % vector of conditional means, E[y|x]
Eyx = condMean*temp;
A = Eyx/Exx; % population OLS estimate
lambdaHat = A(2);

%% Unconditional variance
% compute unconditional variance of Markov chain
uncondMean = X*pi;
temp = bsxfun(@minus,X,uncondMean);
uncondVar = temp*bsxfun(@times,pi,temp');

biasLambda = (1-lambdaHat)./(1-lambda)-1;
biasUV = uncondVar./UV-1;
end

