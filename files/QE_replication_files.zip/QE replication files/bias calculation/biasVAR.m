function [biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P,X)
% biasVAR
% calculate the relative bias of "1 - eigenvalues of B" and unconditional
% variance, where b, B, Psi define the VAR as in discreteVAR.m.
% P, X: transition probability and grid points of any Markov chain that
% approximates the VAR y_(t+1) = b + B*y_(t) + Psi^(1/2)*epsilon_(t+1)

[eigvec,~] = eigs(P',1); % eigenvector of P'
pi = eigvec/sum(eigvec); % stationary distribution

%% OLS coefficient
% compute population OLS estimate of y' = b + B*y + eta', or equivalently
% y' = [b B][1;y] + eta'
% think of this as y = A*x+u
[M,N] = size(X); % number of states
reg = [ones(1,N);X]; % regressor when estimating VAR(1); corresponds to x
temp = bsxfun(@times,pi,reg');
Exx = reg*temp; % matrix of population second moments, E[xx']
condMean = X*P'; % vector of conditional means, E[y|x]
Eyx = condMean*temp;
A = Eyx/Exx; % population OLS estimate
BHat = A(:,2:end);

%% Unconditional variance
% compute unconditional variance of Markov chain
uncondMean = X*pi;
temp = bsxfun(@minus,X,uncondMean);
uncondVar = temp*bsxfun(@times,pi,temp');

% compute unconditional variance of true VAR
Sigma = reshape(((eye(M^2)-kron(B,B))\eye(M^2))*reshape(Psi,M^2,1),M,M);

biasEig = (1-eig(BHat))./(1-eig(B))-1;
biasUV = uncondVar./Sigma-1;

%% unconditional kurtosis
uncondKurt = (temp.^4)*pi; % unconditional kurtosis of Markov chain
trueKurt = 3*(diag(Sigma).^2); % unconditional kurtosis of true VAR
biasKurt = uncondKurt./trueKurt-1;
end

