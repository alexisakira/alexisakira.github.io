Lambda = [0 0.5 0.9 0.95 0.99];
%mu = -9.3332;
rho = 0.9;
sigmaE = 0.06;
sigmaU = 0.007;
%sigmaX = (sigmaE^2)/(1-rho^2); % unconditional variance of variance process
%sigmaU = exp(mu/2+sigmaX/4); % solve for sigmaU used in discreteSV
mu = 2*log(sigmaU)-sigmaE^2/(1-rho^2);

N = 21;
Nx = N;
Ny = N;

M = length(Lambda);
bias = zeros(M,8);

for m=1:M
lambda = Lambda(m);
% SV Tauchen-Rouwenhorst
[P,xyGrids] = discreteSVT(lambda,rho,sigmaU,sigmaE,Ny,Nx);
X = xyGrids(:,1)';
[biasLambda,biasUV] = biasSV(lambda,rho,sigmaU,sigmaE,P,X);
bias(m,[1 2]) = [biasLambda; biasUV];

% SV ME-Even
[P,xyGrids] = discreteSV(lambda,rho,sigmaU,sigmaE,Ny,Nx,'even');
X = xyGrids(:,1)';
[biasLambda,biasUV] = biasSV(lambda,rho,sigmaU,sigmaE,P,X);
bias(m,[3 4]) = [biasLambda; biasUV];

% SV ME-Quant
[P,xyGrids] = discreteSV(lambda,rho,sigmaU,sigmaE,Ny,Nx,'quantile');
X = xyGrids(:,1)';
[biasLambda,biasUV] = biasSV(lambda,rho,sigmaU,sigmaE,P,X);
bias(m,[5 6]) = [biasLambda; biasUV];

% SV ME-Quad
[P,xyGrids] = discreteSV(lambda,rho,sigmaU,sigmaE,Ny,Nx,'quadrature');
X = xyGrids(:,1)';
[biasLambda,biasUV] = biasSV(lambda,rho,sigmaU,sigmaE,P,X);
bias(m,[7 8]) = [biasLambda; biasUV];

end

round(log10(abs(bias)),3)