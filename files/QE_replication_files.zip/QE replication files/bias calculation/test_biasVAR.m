% AR(1)
Nm = 9;
rho = 0.9;
sigma = 1/sqrt(1-rho^2); % unconditional standard deviation
% ME-Even
disp('AR(1) ME-Even (2)')
[P1,X1] = discreteVAR(0,rho,1,Nm,'even',sqrt(Nm-1));
[biasEig,biasUV,biasKurt] = biasVAR(rho,1,P1,X1)
disp('AR(1) ME-Even (4)')
[P2,X2] = discreteVAR4(0,rho,1,Nm,'even',sqrt(Nm-1));
[biasEig,biasUV,biasKurt] = biasVAR(rho,1,P2,X2)
% Rouwenhorst
disp('AR(1) Rouwenhorst')
[P3,X3] = rouwenhorstAR(0,rho,1,Nm);
[biasEig,biasUV,biasKurt] = biasVAR(rho,1,P3,X3)
% Tauchen (optimized)
disp('AR(1) Tauchen')
[P4,X4] = tauchenOptimized(0,rho,1,Nm);
[biasEig,biasUV,biasKurt] = biasVAR(rho,1,P4,X4)

break

% VAR(1) example in GL
b = zeros(2,1);
B = [0.9809 0.0028; 0.0410 0.9648];
Psi = diag([0.0087 0.0262].^2);

% GL0
disp('VAR(1) GL0')
[PN, YN] = var_Markov_MM(B,Psi,Nm,0);
P5 = PN';
X5 = YN';
[biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P5,X5)

disp('VAR(1) GL')
[PN, YN] = var_Markov_MM(B,Psi,Nm,999);
P6 = PN';
X6 = YN';
[biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P6,X6)

disp('VAR(1) ME-E')
[P7,X7] = discreteVAR(b,B,Psi,Nm,'even');
[biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P7,X7)

disp('VAR(1) ME-Quantile')
[P9,X9] = discreteVAR(b,B,Psi,Nm,'quantile');
[biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P9,X9)

disp('VAR(1) ME-GH')
[P10,X10] = discreteVAR(b,B,Psi,Nm,'quadrature');
[biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P10,X10)

disp('VAR(1) Tauchen')
[P8,X8] = tauchenOptimized(b,B,Psi,Nm);
[biasEig,biasUV,biasKurt] = biasVAR(B,Psi,P8,X8)


