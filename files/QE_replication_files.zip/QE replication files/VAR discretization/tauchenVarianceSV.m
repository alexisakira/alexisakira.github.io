function [uVariance,P,xyGrids] = tauchenVarianceSV(sigmaSpacing,sigmaY,xBar,lambda,rho,sigmaE,Nx,Ny,Px,xGrid)

yGrid = linspace(-sigmaSpacing*sigmaY,sigmaSpacing*sigmaY,Ny);
yBounds = [-Inf, mean([yGrid(1:end-1); yGrid(2:end)]), Inf];

Nm = Nx*Ny; % total number of state variable pairs
xyGrids = flipud(combvec(xGrid,yGrid))';
P = zeros(Nm);
for ii = 1:Nm
    
    temp = normcdf(yBounds(2:end),lambda*xyGrids(ii,1),sqrt(exp((1-rho)*xBar+rho*xyGrids(ii,2)+(sigmaE^2)/2))) - normcdf(yBounds(1:end-1),lambda*xyGrids(ii,1),sqrt(exp((1-rho)*xBar+rho*xyGrids(ii,2)+(sigmaE^2)/2)));
    P(ii,:) = kron(temp,ones(1,Nx));
    P(ii,:) = P(ii,:).*repmat(Px(mod(ii-1,Nx)+1,:),1,Ny);
    
end

D = xyGrids(:,1);
stationaryTauchen = P^1000;
stationaryTauchen = stationaryTauchen(1,:)';
uVariance = stationaryTauchen'*(D.^2);

end