function [uVariance,P,X] = tauchenVAR(b,B,Psi,Nm,nSigmas)

bSize = size(B);

%% Compute standardized VAR(1) representation (zero mean and diagonal covariance matrix)

M = bSize(1);

if M == 1
    C = sqrt(Psi);
    A = B;
    mu = b/(1-B);
    Sigma = 1/(1-B^2);
else
    C = chol(Psi,'lower');
    mu = ((eye(M)-B)\eye(M))*b;
    Cinv = C\eye(M);
    A = Cinv*B*C;
    Sigma = reshape(((eye(M^2)-kron(A,A))\eye(M^2))*reshape(eye(M),M^2,1),M,M);
end

%% Construct 1-D grids

sigmas = sqrt(diag(Sigma));
y1D = zeros(M,Nm);
y1DBounds = zeros(M,Nm+1);

for ii = 1:M
    y1D(ii,:) = linspace(-sigmas(ii)*nSigmas,sigmas(ii)*nSigmas,Nm);
    y1DBounds(ii,:) = [-Inf,mean([y1D(ii,1:end-1); y1D(ii,2:end)]),Inf];
end

% Construct all possible combinations of elements of the 1-D grids
D = allcomb2(y1D)';

%% Construct finite-state Markov chain approximation

condMean = A*D; % conditional mean of the VAR process at each grid point
P = ones(Nm^M); % probability transition matrix

for ii = 1:(Nm^M)

    temp = NaN(M,Nm);
    for jj = 1:M

        temp(jj,:) = normcdf(y1DBounds(jj,2:end),condMean(jj,ii),sigmas(jj)) - normcdf(y1DBounds(jj,1:end-1),condMean(jj,ii),sigmas(jj));
    
    end
    
    P(ii,:) = prod(allcomb2(temp),2)';
    
end

X = C*D + repmat(mu,1,Nm^M); % map grids back to original space

stationaryTauchen = P^1000;
stationaryTauchen = stationaryTauchen(1,:)';
uVariance = (X.^2)*stationaryTauchen - (X*stationaryTauchen).^2;

end