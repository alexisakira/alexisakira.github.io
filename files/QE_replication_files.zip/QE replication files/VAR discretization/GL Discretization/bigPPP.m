% bigPPP
% This function is used by the main code var_Markov_MM.
function PPP = bigPPP(pmatxxx,n)
PPP=zeros(n^2,n^2);
ix2=0;
for i1=1:n
    for i2=1:n
        ix2=ix2+1;
        for i3=1:n
            for i4=1:n
                ix1=(i3-1)*n+i4;
                PPP(ix1,ix2)=pmatxxx(1,i1,i2,i3)*pmatxxx(2,i1,i2,i4);
            end
        end
    end
end
for i = 1:n*n
    PPP(:,i) = PPP(:,i) / sum(PPP(:,i));
end