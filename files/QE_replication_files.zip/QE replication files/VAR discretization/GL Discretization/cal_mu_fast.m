% cal_mu_fast
% This function calculates the conditional variance of the mixture
% distribution given the conditional mean mu and the conditional variance
% v0 of the mass distributions on the n grids given by z.
%
% For details, see Nikolay Gospodinov and Damba Lkhagvasuren, 2013
%
function [v1, p, na,nb, dummy_exceed]=cal_mu_fast(mu,v0,n,z)
r=sqrt(1-v0);
zm=z*r;
if mu>=zm(n)
    dummy_exceed=1;
    na=n;
    nb=n;
    p=0;
    v1=v0;
elseif mu<=zm(1)
    dummy_exceed=-1;
    na=1;
    nb=1;
    p=1;
    v1=v0;
else
    dummy_exceed=0;
    na=1+floor((mu-zm(1))/(zm(2)-zm(1)));
    nb=na+1;
    zax=zm(na);
    zbx=zm(nb);
    p=(zbx-mu)/(zbx-zax);
    v1=v0+p*(1-p)*(zbx-zax)^2;
end