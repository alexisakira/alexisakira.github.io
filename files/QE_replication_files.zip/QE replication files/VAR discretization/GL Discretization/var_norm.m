% var_norm
% This code is written to normalize unconditional variance of components
% of a VAR(1) process: y�=Ay+epsilon.
% INPUT: ve - covariance matrix of the error term. This is a diagonal
% matrix where the i-th diagonal element is var(epsilon_i).
% A - the coef. matrix.
% OUTPUT: vynew - cov. matrix of normalized y
% vyold - initial cov. matrix of y
% venew - cov. matrix of the new error term
% Anew - the new coef. matrix
function [Anew, vynew, vyold, venew]=var_norm(A, ve)
dif=100;
temp=size(A);
nx=temp(1,1);
V0=zeros(nx,nx);
while dif>0.00000000001
    V=A*V0*A'+ve;
    dif=max(max(V-V0));
    V0=V;
end
vyold=V0;
venew=zeros(nx,nx);
Anew=zeros(nx,nx);
for i=1:nx
    venew(i,i)=ve(i,i)/vyold(i,i);
    for j=1:nx
        Anew(i,j)=A(i,j)*sqrt(vyold(j,j))/sqrt(vyold(i,i));
    end
end
vynew=zeros(nx,nx);
for i=1:nx
    for j=1:nx
        vynew(i,j)=vyold(i,j)/(sqrt(vyold(i,i))*sqrt(vyold(j,j)) );
    end
end