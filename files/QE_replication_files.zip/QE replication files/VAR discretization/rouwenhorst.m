function P = rouwenhorst(m,p,q)

P = [p 1-p; 1-q q];
for k = 3:m
    P = p*[P zeros(k-1,1); zeros(1,k)] + (1-p)*[zeros(k-1,1) P; zeros(1,k)] + (1-q)*[zeros(1,k); P zeros(k-1,1)] + q*[zeros(1,k); zeros(k-1,1) P];
    P(2:end-1,:) = P(2:end-1,:)./2;
end
%P = P.*(P>1e-5);
%P = P./repmat(sum(P,2),1,m);
%P = sparse(P./repmat(sum(P,2),1,m));

end