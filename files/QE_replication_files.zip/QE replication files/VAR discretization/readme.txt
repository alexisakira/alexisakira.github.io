"GL Discretization" folder contains files from the online appendix of Gospodinov & Lkhagvasuren (2014).
tauchenHussey.m discretizes VAR using the Tauchen-Hussey (1991) method.
tauchenVAR.m discretizes VAR using the Tauchen (1986) method.
tauchenOptimized.m discretizes VAR using the Tauchen (1986) method, but grid spacing is optimized to match unconditional variance.
rouwenhosrt.m and rouwenhorstAR.m discretize AR(1) using the Rouwenhorst (1995) method.
discreteSVT.m and tauchenVarianceSV.m discretize the stochastic volatility model using the Tauchen-Rouwenhorst method.