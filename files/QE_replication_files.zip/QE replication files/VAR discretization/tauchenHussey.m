function [P,X] = tauchenHussey(b,B,Psi,Nm)

bSize = size(B);

% Check size restrictions on matrices
if bSize(1) ~= bSize(2)
    error('B must be a square matrix')
end

if size(b,2) ~= 1
    error('b must be a column vector')
end

if size(b,1) ~= bSize(1)
    error('b must have the same number of rows as B')
end

% Check that Psi is a valid covariance matrix
[~,posDefCheck] = chol(Psi);
if posDefCheck
    error('Psi must be a positive definite matrix')
end

% Check that Nm is a valid number of grid points
if ~isnumeric(Nm) || Nm < 3 || rem(Nm,1) ~= 0
    error('Nm must be a positive integer greater than 3')
end

%% Compute standardized VAR(1) representation (zero mean and diagonal covariance matrix)

M = bSize(1);

if M == 1
    C = sqrt(Psi);
    A = B;
    mu = b/(1-B);
    %Sigma = 1/(1-B^2);
else
    C = chol(Psi,'lower');
    mu = ((eye(M)-B)\eye(M))*b;
    Cinv = C\eye(M);
    A = Cinv*B*C;
    %Sigma = reshape(((eye(M^2)-kron(A,A))\eye(M^2))*reshape(eye(M),M^2,1),M,M);
end

%% Construct 1-D grids

y1D = zeros(M,Nm);

[nodes,weights] = GaussHermite(Nm);
for ii = 1:M
    y1D(ii,:) = sqrt(2)*nodes;
end

% Construct all possible combinations of elements of the 1-D grids
D = allcomb2(y1D)';

%% Construct finite-state Markov chain approximation

condMean = A*D; % conditional mean of the VAR process at each grid point
P = ones(Nm^M); % probability transition matrix

for ii = 1:(Nm^M)
    q = bsxfun(@times,(normpdf(y1D,repmat(condMean(:,ii),1,Nm),1)./normpdf(y1D,0,1)),...
        (weights'./sqrt(pi)));    
    P(ii,:) = prod(allcomb2(q),2)';
end

X = C*D + repmat(mu,1,Nm^M); % map grids back to original space

end