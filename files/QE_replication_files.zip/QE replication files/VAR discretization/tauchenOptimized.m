function [P,X] = tauchenOptimized(b,B,Psi,Nm)

M = size(B,1);
Sigma = repmat(((eye(M^2)-kron(B,B))\eye(M^2))*Psi(:),M,M);

nSigmasOpt = fminsearch(@(nSigmas) sum((diag(Sigma)-tauchenVAR(b,B,Psi,Nm,nSigmas)).^2),2);

[~,P,X] = tauchenVAR(b,B,Psi,Nm,nSigmasOpt);

end

