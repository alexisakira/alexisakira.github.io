function [P,X] = rouwenhorstAR(mu,rho,sigma,Nm)

P = rouwenhorst(Nm,(1+rho)/2,(1+rho)/2);
sigmaX = sigma/sqrt(1-rho^2);

X = mu + linspace(-sqrt(Nm-1)*sigmaX,sqrt(Nm-1)*sigmaX,Nm);

end

