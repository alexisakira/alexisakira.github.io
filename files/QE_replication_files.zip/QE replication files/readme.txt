"asset pricing AR1" folder contains replication files for the AR(1) asset pricing model.
"asset pricing rare disasters" folder contains replication files for the rare disasters asset pricing model.
"asset pricing VAR" folder contains replication files for the VAR(1) asset pricing model.
"bias calculation" folder contains replication files for the bias calculation in appendix.
"Cheb tools" folder contains subroutines for implementing the projection method.
"ME discretization" contains subroutines for implementing the maximum entropy discretization.
"miscellaneous" contains various Matlab files for plotting.
"VAR discretization" contains subroutines for discretizing VAR processes using existing methods.