% Solve a simple asset pricing model proposed by Burnside

close all
% Change default axes fonts
%set(0,'DefaultAxesFontName', 'Times New Roman')
set(0,'DefaultAxesFontSize', 12)

% Change default text fonts
%set(0,'DefaultTextFontname', 'Times New Roman')
set(0,'DefaultTextFontSize', 12)
set(0,'DefaultLineLineWidth',2)

%% Set parameters

% Use data on dividend growth to calibrate AR(1) process

data = xlsread('PredictorData2013.xlsx','Annual');
dGrowth = diff(log(data(:,3)));
dGrowth = dGrowth(77:end);

consumption = xlsread('consumptionA.xls');
consumption = consumption(1:end-1);
cGrowth = diff(log(consumption));

X = [dGrowth(1:end-1) cGrowth(1:end-1)];
T = size(X,1);
Y = [dGrowth(2:end) cGrowth(2:end)];
lmd = fitlm(X,Y(:,1));
lmc = fitlm(X,Y(:,2));
b = [lmd.Coefficients.Estimate(1); lmc.Coefficients.Estimate(1)];
B = [lmd.Coefficients.Estimate(2:3)'; lmc.Coefficients.Estimate(2:3)'];
resid = [lmd.Residuals.Raw lmc.Residuals.Raw];
Psi = zeros(2);
for t = 1:T-1
    Psi = Psi + resid(t,:)'*resid(t,:);
end
Psi = Psi./(T-1);
PsiTilde = ((eye(2)-B)\eye(2))*Psi*((eye(2)-B')\eye(2));

% Other model parameters

%gamma = 5; % risk aversion
gamma = 2;
alpha = [1; -gamma];
%beta = 0.96; % discount factor
beta = 0.95;
mu = ((eye(2)-B)\eye(2))*b;

%% Verify convergence criteria

r = beta*exp(alpha'*mu+0.5*alpha'*PsiTilde*alpha)

%% Construct coefficients for closed form solution

cutoff = 10000;
ind = (1:cutoff); % approximate infinite sum with large cutoff
aCoef = zeros(1,cutoff);
bCoef = zeros(2,cutoff);
Psin = zeros(2);
for ii = 1:cutoff
    Psin = Psin + (B^ii)*PsiTilde*((B')^ii);
    Cn = B*(eye(2)-B^ii)*((eye(2)-B)\eye(2));
    Omegan = ii*PsiTilde - Cn*PsiTilde - PsiTilde*Cn' + Psin;
    aCoef(ii) = ii*log(beta) + ii*alpha'*mu + 0.5*alpha'*Omegan*alpha;
    bCoef(:,ii) = (alpha'*Cn)';
end

%% Construct approximate solutions

initNx = 9;
maxNx = initNx;
chebCoefGuess = [20 zeros(1,initNx-1); zeros(initNx-1,initNx)];
%load('burnsideVAR9.mat','chebCoefHatFTT','chebCoefHatFTTAlt','chebCoefHatGL0','chebCoefHatGL')
% chebCoefGuessFTT = chebCoefHatFTT;
% chebCoefGuessFTTAlt = chebCoefHatFTTAlt;
% chebCoefGuessGL0 = chebCoefHatGL0;
% chebCoefGuessGL = chebCoefHatGL;
chebCoefGuessEven2 = chebCoefGuess;
chebCoefGuessQuant = chebCoefGuess;
chebCoefGuessQuad = chebCoefGuess;
chebCoefGuessEven4 = chebCoefGuess;
chebCoefGuessTau = chebCoefGuess;
chebCoefGuessTH = chebCoefGuess;
chebCoefGuessGL0 = chebCoefGuess;
chebCoefGuessGL = chebCoefGuess;

%options = optimoptions(@fsolve,'PlotFcns',@optimplotfval,'MaxFunEvals',100000,'TolFun',1e-10,'MaxIter',1000);
options = optimoptions(@fsolve,'PlotFcns',@optimplotfval,'TolFun',1e-10);

for Nx = initNx:maxNx
    
    Nx
    
    % Construct discrete VAR approximations
    
    % ME-Even (2)
    [PEven2,XEven2] = discreteVAR(b,B,Psi,Nx,2,'even',sqrt((Nx-1)));
    dGridEven2 = unique(XEven2(1,:));
    cGridEven2 = unique(XEven2(2,:));
    
    % ME-Quant
    [PQuant,XQuant] = discreteVAR(b,B,Psi,Nx,2,'quantile');
    dGridQuant = unique(XQuant(1,:));
    cGridQuant = unique(XQuant(2,:));
    
    % ME-Quad
    [PQuad,XQuad] = discreteVAR(b,B,Psi,Nx,2,'quadrature');
    dGridQuad = unique(XQuad(1,:));
    cGridQuad = unique(XQuad(2,:));
    
    % ME-Even (4)
    [PEven4,XEven4] = discreteVAR(b,B,Psi,Nx,4,'even',sqrt((Nx-1)));
    dGridEven4 = unique(XEven4(1,:));
    cGridEven4 = unique(XEven4(2,:));
    
    % Tauchen
    [PTau,XTau] = tauchenOptimized(b,B,Psi,Nx);
    dGridTau = unique(XTau(1,:));
    cGridTau = unique(XTau(2,:));
    
    % Tauchen-Hussey
    [PTH,XTH] = tauchenHussey(b,B,Psi,Nx);
    dGridTH = unique(XTH(1,:));
    cGridTH = unique(XTH(2,:));
    
    C = chol(Psi,'lower');
    Cinv = C\eye(2);
    A = Cinv*B*C;
    
    % GL0
    [PGL0,XGL0] = var_Markov_MM(A,eye(2),Nx,0);
    XGL0 = bsxfun(@plus,C*XGL0',mu);
    PGL0 = PGL0';
    dGridGL0 = unique(XGL0(1,:));
    cGridGL0 = unique(XGL0(2,:));
    
    % GL
    [PGL,XGL] = var_Markov_MM(A,eye(2),Nx,999);
    XGL = bsxfun(@plus,C*XGL',mu);
    PGL = PGL';
    dGridGL = unique(XGL(1,:));
    cGridGL = unique(XGL(2,:));
    
    chebCoefHatEven2 = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PEven2,XEven2),chebCoefGuessEven2,options);
    chebCoefHatQuant = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PQuant,XQuant),chebCoefGuessQuant,options);
    chebCoefHatQuad = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PQuad,XQuad),chebCoefGuessQuad,options);
    chebCoefGuessEven4 = chebCoefHatEven2;
    chebCoefHatEven4 = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PEven4,XEven4),chebCoefGuessEven4,options);
    chebCoefHatTau = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PTau,XTau),chebCoefGuessTau,options);
    chebCoefGuessTH = chebCoefHatQuad;
    chebCoefHatTH = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PTH,XTH),chebCoefGuessTH,options);
    chebCoefHatGL = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PGL,XGL),chebCoefGuessGL0,options);
    chebCoefHatGL0 = fsolve(@(chebCoef) burnsideEulerVAR(chebCoef,[alpha; beta],PGL0,XGL0),chebCoefGuessGL,options);
    chebCoefGuessEven2 = [chebCoefHatEven2 zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessQuant = [chebCoefHatQuant zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessQuad = [chebCoefHatQuad zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessEven4 = [chebCoefHatEven4 zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessTau = [chebCoefHatTau zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessTH = [chebCoefHatTH zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessGL0 = [chebCoefHatGL0 zeros(Nx,1); zeros(1,Nx+1)];
    chebCoefGuessGL = [chebCoefHatGL zeros(Nx,1); zeros(1,Nx+1)];

end

%% Plot solutions

numPoints = 201;
gridEndPoints = [max([dGridEven2(1) dGridQuant(1) dGridQuad(1) dGridTau(1) dGridGL(1)])...
    min([dGridEven2(end) dGridQuant(end) dGridQuad(end) dGridTau(end) dGridGL(end)])...
    max([cGridEven2(1) cGridQuant(1) cGridQuad(1) cGridTau(1) cGridGL(1)])...
    min([cGridEven2(end) cGridQuant(end) cGridQuad(end) cGridTau(end) cGridGL(end)])];
[D,C] = meshgrid(linspace(gridEndPoints(1),gridEndPoints(2),numPoints),linspace(gridEndPoints(3),gridEndPoints(4),numPoints));
evaluationGrid = [D(:) C(:)];
vActual = zeros(size(evaluationGrid,1),1);
vEven2 = vActual;
vQuant = vActual;
vQuad = vActual;
vEven4 = vActual;
vTau = vActual;
vTH = vActual;
vGL0 = vActual;
vGL = vActual;
for ii = 1:size(evaluationGrid,1)
    vActual(ii) = sum(exp(aCoef + (evaluationGrid(ii,:)-mu')*bCoef));
    vEven2(ii) = Fsim2(chebCoefHatEven2,Tx(evaluationGrid(ii,1),min(dGridEven2),max(dGridEven2)),Tx(evaluationGrid(ii,2),min(cGridEven2),max(cGridEven2)),Nx,Nx);
    vQuant(ii) = Fsim2(chebCoefHatQuant,Tx(evaluationGrid(ii,1),min(dGridQuant),max(dGridQuant)),Tx(evaluationGrid(ii,2),min(cGridQuant),max(cGridQuant)),Nx,Nx);
    vQuad(ii) = Fsim2(chebCoefHatQuad,Tx(evaluationGrid(ii,1),min(dGridQuad),max(dGridQuad)),Tx(evaluationGrid(ii,2),min(cGridQuad),max(cGridQuad)),Nx,Nx);
    vEven4(ii) = Fsim2(chebCoefHatEven4,Tx(evaluationGrid(ii,1),min(dGridEven4),max(dGridEven4)),Tx(evaluationGrid(ii,2),min(cGridEven4),max(cGridEven4)),Nx,Nx);
    vTau(ii) = Fsim2(chebCoefHatTau,Tx(evaluationGrid(ii,1),min(dGridTau),max(dGridTau)),Tx(evaluationGrid(ii,2),min(cGridTau),max(cGridTau)),Nx,Nx);
    vTH(ii) = Fsim2(chebCoefHatTH,Tx(evaluationGrid(ii,1),min(dGridTH),max(dGridTH)),Tx(evaluationGrid(ii,2),min(cGridTH),max(cGridTH)),Nx,Nx);
    vGL0(ii) = Fsim2(chebCoefHatGL0,Tx(evaluationGrid(ii,1),min(dGridGL0),max(dGridGL0)),Tx(evaluationGrid(ii,2),min(cGridGL0),max(cGridGL0)),Nx,Nx); 
    vGL(ii) = Fsim2(chebCoefHatGL,Tx(evaluationGrid(ii,1),min(dGridGL),max(dGridGL)),Tx(evaluationGrid(ii,2),min(cGridGL),max(cGridGL)),Nx,Nx); 
end

vActual = reshape(vActual,size(D));
vEven2 = reshape(vEven2,size(D));
vQuant = reshape(vQuant,size(D));
vQuad = reshape(vQuad,size(D));
vEven4 = reshape(vEven4,size(D));
vTau = reshape(vTau,size(D));
vTH = reshape(vTH,size(D));
vGL0 = reshape(vGL0,size(D));
vGL = reshape(vGL,size(D));

%figure
%surf(D,C,vActual)

%figure
%surf(D,C,vEven2)

policyErrorsEven2 = log10(abs(vEven2./vActual-1));
policyErrorsQuant = log10(abs(vQuant./vActual-1));
policyErrorsQuad = log10(abs(vQuad./vActual-1));
policyErrorsEven4 = log10(abs(vEven4./vActual-1));
policyErrorsTau = log10(abs(vTau./vActual-1));
policyErrorsTH = log10(abs(vTH./vActual-1));
policyErrorsGL0 = log10(abs(vGL0./vActual-1));
policyErrorsGL = log10(abs(vGL./vActual-1));

maxPolicyErrors = [max(max(policyErrorsEven2)) max(max(policyErrorsQuant)) max(max(policyErrorsQuad)) max(max(policyErrorsEven4)) max(max(policyErrorsTau)) max(max(policyErrorsTH)) max(max(policyErrorsGL0)) max(max(policyErrorsGL))]
meanPolicyErrors = [mean(mean(policyErrorsEven2)) mean(mean(policyErrorsQuant)) mean(mean(policyErrorsQuad)) mean(mean(policyErrorsEven4)) mean(mean(policyErrorsTau)) mean(mean(policyErrorsTH)) mean(mean(policyErrorsGL0)) mean(mean(policyErrorsGL))]

input.data = [meanPolicyErrors; maxPolicyErrors];
input.dataFormat = {'%-.3f'};
input.tableBorders = 0;
input.tableColLabels = {'Even (2)','Quant','Quad','Even (4)','Tauchen','TH','GL0','GL'};
input.tableRowLabels = {'Mean','Max'};
input.makeCompleteLatexDocument = 0;

latexTable(input)

ub = ceil(max(maxPolicyErrors));
lb = floor(min(meanPolicyErrors));

temp = get(gca,'ColorOrder');
c1 = temp(1,:);
c2 = temp(2,:);
c3 = temp(3,:);
c4 = temp(4,:);
c5 = temp(5,:);

plotInd = round(numPoints/2);
figure
%subplot(2,1,1)
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsEven2(plotInd,:),9,'--d','Mks',8,'Color',c1); hold on
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsQuant(plotInd,:),9,':d','Mks',8,'Color',c1);
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsQuad(plotInd,:),9,'-.d','Mks',8,'Color',c1);
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsEven4(plotInd,:),9,'-d','Mks',8,'Color',c1);
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsTau(plotInd,:),9,'-x','Mks',8,'Color',c2);
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsTH(plotInd,:),9,'-o','Mks',8,'Color',c3);
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsGL0(plotInd,:),9,'--s','Mks',8,'Color',c4);
line_fewer_markers(D(plotInd,:)-mu(1),policyErrorsGL(plotInd,:),9,'-s','Mks',8,'Color',c4); hold off
%line([0 0],[-10 10],'Color','k','LineStyle','--','LineWidth',1)
%axis([D(plotInd,1)-mu(1) D(plotInd,end)-mu(1) -10 0])
line([0 0],[lb,ub],'Color','k','LineStyle','--','LineWidth',1)
axis tight
%legend({'ME-Even','ME-Quantile','ME-GH','TH','GL0','GL'},'Location','best')
xlabel('Dividend Growth')
ylabel('log_{10} Relative Errors')
title('Consumption growth fixed at unconditional mean')
columnlegend(2,{'ME-Even (2)','ME-Quant','ME-Quad','ME-Even (4)','Tauchen','Tauchen-Hussey','GL0','GL'});

figure
%subplot(2,1,2)
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsEven2(:,plotInd),9,'--d','Mks',8,'Color',c1); hold on
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsQuant(:,plotInd),9,':d','Mks',8,'Color',c1);
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsQuad(:,plotInd),9,'-.d','Mks',8,'Color',c1);
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsEven4(:,plotInd),9,'-d','Mks',8,'Color',c1);
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsTau(:,plotInd),9,'-x','Mks',8,'Color',c2);
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsTH(:,plotInd),9,'-o','Mks',8,'Color',c3);
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsGL0(:,plotInd),9,'--s','Mks',8,'Color',c4);
line_fewer_markers(C(:,plotInd)-mu(2),policyErrorsGL(:,plotInd),9,'-s','Mks',8,'Color',c4); hold off
%line([0 0],[-10 10],'Color','k','LineStyle','--','LineWidth',1)
%axis([C(1,plotInd)-mu(2) C(end,plotInd)-mu(2) -10 0])
line([0 0],[lb,ub],'Color','k','LineStyle','--','LineWidth',1)
axis tight
xlabel('Consumption Growth')
ylabel('log_{10} Relative Errors')
title('Dividend growth fixed at unconditional mean')
columnlegend(2,{'ME-Even (2)','ME-Quant','ME-Quad','ME-Even (4)','Tauchen','Tauchen-Hussey','GL0','GL'});

%save('burnsideVAR9.mat')