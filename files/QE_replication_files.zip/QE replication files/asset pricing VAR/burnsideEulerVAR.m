function resid = burnsideEulerVAR(chebCoef,theta,P,xGrid)

% Unpack parameter vector

alpha = theta(1:2);
beta = theta(3);

% Evaluate policy function at grid points

Nx = size(xGrid,2);
vCur = zeros(Nx,1);
x1T = Tx(xGrid(1,:),min(xGrid(1,:)),max(xGrid(1,:)));
x2T = Tx(xGrid(2,:),min(xGrid(2,:)),max(xGrid(2,:)));
for ii = 1:Nx
    vCur(ii) = Fsim2(chebCoef,x1T(ii),x2T(ii),sqrt(Nx),sqrt(Nx));
end

% Compute residual

resid = zeros(Nx,1);

for ii = 1:Nx
    
    resid(ii) = beta*P(ii,:)*((exp(alpha'*xGrid).*(vCur'+1))') - vCur(ii);
    
end

end