running burnsideModelVAR2.m will generate the results on asset pricing models with Gaussian VAR(1) shocks.
Setting initNx = 5, 7, 9 on line 70 will replicate the figures in paper.