%% Set parameters

close all
% Change default axes fonts
%set(0,'DefaultAxesFontName', 'Times New Roman')
%set(0,'DefaultAxesFontSize', 14)

% Change default text fonts
%set(0,'DefaultTextFontname', 'Times New Roman')
%set(0,'DefaultTextFontSize', 14)
set(0,'DefaultLineLineWidth',2)

colors = get(gca,'ColorOrder');
c1 = colors(1,:);
c2 = colors(2,:);
c3 = colors(3,:);
c4 = colors(4,:);

% Preference parameters
gamma = 2;
beta = 0.95;

%% MLE estimation data

data = xlsread('PredictorData2013.xlsx','Annual');
dGrowth = diff(log(data(:,3)));
dGrowth = dGrowth(76:end);
T = numel(dGrowth);

dX = [ones(T-1,1) dGrowth(1:end-1)];
dY = dGrowth(2:end);

% OLS model
betaHat2 = dX\dY;
rhoHatN = betaHat2(2);
%rhoHatN = 0.8; % turn up persistence
muHatN = betaHat2(1)/(1-betaHat2(2));

regResid2 = dY - dX*betaHat2;
sigmaHatN = sqrt(mean(regResid2.^2));

% Compute unconditional standard deviations

sigmaXN = sigmaHatN/sqrt(1-rhoHatN^2);

%% Compute exact price-dividend ratio

VN = @(x) exactPD(x,beta,gamma,muHatN,rhoHatN,sigmaHatN);

%% Construct discrete Markov chain approximations

Nm = 5; % number of points for discretization
NapproxInit = Nm; % starting degree of approximation
maxNapprox = Nm; % maximum degree of approximation

chebCoefGuesses = [4*ones(1,7); zeros(NapproxInit-1,7)]; % start with degree NapproxInit approximation

options = optimoptions(@fsolve,'TolFun',1e-12,'TolX',1e-10,'Display','off','FinDiffType','central');
options2 = optimset('TolFun',1e-12,'TolX',1e-10,'Display','off');

warning off

for Napprox = NapproxInit:2:maxNapprox
    
    Napprox
    
    sigmaSpacing = sqrt((Nm-1)); % spacing for even-spaced grid
    
    %% Compute discrete approximations
    
    % Maximum Entropy discretizations
   
    [PEven2,XEven2] = discreteVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,2,'even',sigmaSpacing);
    [PQuant,XQuant] = discreteVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,2,'quantile');
    [PQuad,XQuad] = discreteVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,2,'quadrature');
    [PEven4,XEven4] = discreteVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,4,'even',sigmaSpacing);
    
    % Rouwenhorst discretization

    [PR,XR] = rouwenhorstAR(muHatN,rhoHatN,sigmaHatN,Nm);
    
    % Tauchen discretization
    
    [PTau,XTau] = tauchenOptimized(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm); % optimimzed Tauchen (exact unconditional variance)
    %[~,PTau,XTau] = tauchenVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,sigmaSpacing);
    %[~,PTau,XTau] = tauchenVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,1.2*log(Nm)); % Floden (2008)'s specification
    
    % Tauchen-Hussey discretization
    
    [PTH,XTH] = tauchenHussey(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm);
    
    % Compute discretized stationary distributions
    
    stationaryDistributions = ones(Nm,7);
    % Comment this section out to use even-weighting, otherwise default is
    % ergodic distribution weighting
    temp = PEven2^1000;
    stationaryDistributions(:,1) = temp(1,:)';
    temp = PQuant^1000;
    stationaryDistributions(:,2) = temp(1,:)';
    temp = PQuad^1000;
    stationaryDistributions(:,3) = temp(1,:)';
    temp = PEven4^1000;
    stationaryDistributions(:,4) = temp(1,:)';
    temp = PR^1000;
    stationaryDistributions(:,5) = temp(1,:)';
    temp = PTau^1000;
    stationaryDistributions(:,6) = temp(1,:)';
    temp = PTH^1000;
    stationaryDistributions(:,7) = temp(1,:)';
    
    %% Compute approximate solutions
    
    chebNodes = coloc(Nm,1);
    
    % Set bounds
    
    boundsN = [muHatN-sigmaSpacing*sigmaXN,muHatN+sigmaSpacing*sigmaXN];
    
    if Nm == Napprox
        
        % Maximum Entropy approximations
        
        tic
        chebCoefHatCollocEven2 = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PEven2,XEven2),chebCoefGuesses(:,1),options);
        chebCoefHatCollocQuant = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PQuant,XQuant),chebCoefGuesses(:,2),options);
        chebCoefHatCollocQuad = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PQuad,XQuad),chebCoefGuesses(:,3),options);
        chebCoefHatCollocEven4 = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PEven4,XEven4),chebCoefGuesses(:,4),options);
        toc
        
        % Rouwenhorst approximation
        
        tic
        chebCoefHatCollocR = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PR,XR),chebCoefGuesses(:,5),options);
        toc
        
        % Tauchen approximation
        
        tic
        chebCoefHatCollocTau = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PTau,XTau),chebCoefGuesses(:,6),options);
        toc
        
        % Tauchen-Hussey approximation
        
        tic
        chebCoefHatCollocTH = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PTH,XTH),chebCoefGuesses(:,7),options);
        toc
        
    else
        
        % Maximum Entropy approximations
        
        tic
        chebCoefHatCollocEven2 = fminunc(@(chebCoef) sum(stationaryDistributions(:,1).*(burnsideEuler(chebCoef,[(1-gamma),beta],PEven2,XEven2).^2)),chebCoefGuesses(:,1),options2);
        chebCoefHatCollocQuant = fminunc(@(chebCoef) sum(stationaryDistributions(:,2).*(burnsideEuler(chebCoef,[(1-gamma),beta],PQuant,XQuant).^2)),chebCoefGuesses(:,2),options2);
        chebCoefHatCollocQuad = fminunc(@(chebCoef) sum(stationaryDistributions(:,3).*(burnsideEuler(chebCoef,[(1-gamma),beta],PQuad,XQuad).^2)),chebCoefGuesses(:,3),options2);
        chebCoefHatCollocEven4 = fminunc(@(chebCoef) sum(stationaryDistributions(:,4).*burnsideEuler(chebCoef,[(1-gamma),beta],PEven4,XEven4).^2),chebCoefGuesses(:,4),options2);
        toc
        
        % Rouwenhorst approximation
        
        tic
        chebCoefHatCollocR = fminunc(@(chebCoef) sum(stationaryDistributions(:,5).*(burnsideEuler(chebCoef,[(1-gamma),beta],PR,XR).^2)),chebCoefGuesses(:,5),options2);
        toc
                
        % Tauchen approximation
        
        tic
        chebCoefHatCollocTau = fminunc(@(chebCoef) sum(stationaryDistributions(:,6).*(burnsideEuler(chebCoef,[(1-gamma),beta],PTau,XTau).^2)),chebCoefGuesses(:,6),options2);
        toc
        
        % Rouwenhorst approximation
        
        tic
        chebCoefHatCollocTH = fminunc(@(chebCoef) sum(stationaryDistributions(:,7).*(burnsideEuler(chebCoef,[(1-gamma),beta],PTH,XTH).^2)),chebCoefGuesses(:,7),options2);
        toc
        
    end
    
    %% Update coefficient guesses
    
    chebCoefGuesses = [chebCoefHatCollocEven2, chebCoefHatCollocQuant,...
        chebCoefHatCollocQuad, chebCoefHatCollocEven4, chebCoefHatCollocR,...
        chebCoefHatCollocTau, chebCoefHatCollocTH; zeros(2,7)];
    
end

warning on

%% Evaluate approximate solutions

numEval = 1501;
%numEval = 101;
evalEndsN = [max([XEven2(1) XQuant(1) XQuad(1) XEven4(1) boundsN(1) XR(1) XTau(1) XTH(1)]),...
    min([XEven2(end) XQuant(end) XQuad(end) XEven4(end) boundsN(end) XR(end) XTau(end) XTH(end)])];
evalGridN = linspace(evalEndsN(1),evalEndsN(2),numEval)';

vHatN = VN(evalGridN)';

vHatCollocEven2 = Fsim(chebCoefHatCollocEven2,Tx(evalGridN',XEven2(1),XEven2(end)),Napprox);
vHatCollocQuant = Fsim(chebCoefHatCollocQuant,Tx(evalGridN',XQuant(1),XQuant(end)),Napprox);
vHatCollocQuad = Fsim(chebCoefHatCollocQuad,Tx(evalGridN',XQuad(1),XQuad(end)),Napprox);
vHatCollocEven4 = Fsim(chebCoefHatCollocEven4,Tx(evalGridN',XEven4(1),XEven4(end)),Napprox);
vHatCollocR = Fsim(chebCoefHatCollocR,Tx(evalGridN',XR(1),XR(end)),Napprox);
vHatCollocTau = Fsim(chebCoefHatCollocTau,Tx(evalGridN',XTau(1),XTau(end)),Napprox);
vHatCollocTH = Fsim(chebCoefHatCollocTH,Tx(evalGridN',XTH(1),XTH(end)),Napprox);

relativeErrorsN = bsxfun(@rdivide,vHatN,[vHatCollocEven2; vHatCollocQuant; vHatCollocQuad; vHatCollocEven4; vHatCollocR; vHatCollocTau; vHatCollocTH]) - 1;

% Plots

figure(1)
%plot(evalGridN,log10(abs(relativeErrorsN)))
plot(evalGridN,log10(abs(relativeErrorsN(1,:))),'--','Color',c1); hold on
plot(evalGridN,log10(abs(relativeErrorsN(2,:))),':','Color',c1);
plot(evalGridN,log10(abs(relativeErrorsN(3,:))),'-.','Color',c1);
plot(evalGridN,log10(abs(relativeErrorsN(4,:))),'-','Color',c1);
plot(evalGridN,log10(abs(relativeErrorsN(5,:))),'-','Color',c2);
plot(evalGridN,log10(abs(relativeErrorsN(6,:))),'-','Color',c3);
plot(evalGridN,log10(abs(relativeErrorsN(7,:))),'-','Color',c4); hold off
axis tight
%ylim([-15 0]);
%line([muHatN,muHatN],[-15,10],'Color','k','LineStyle','--')
xlabel('Dividend Growth')
ylabel('log_{10} Relative Errors')
%legend({'ME-Even (2)','ME-Quant','ME-Quad','ME-Even (4)','Rouwenhorst','Tauchen','Tauchen-Hussey'})
columnlegend(2,{'ME-Even (2)','ME-Quant','ME-Quad','ME-Even (4)','Rouwenhorst','Tauchen','Tauchen-Hussey'});
%title('Relative errors for Normal model')

% Tables

meanError = mean(log10(abs(relativeErrorsN')));
maxError = max(log10(abs(relativeErrorsN')));
disp('Normal Model Errors (mean and max)')
[meanError;maxError]

disp('Dollar Mistake with 1 Million')
dollarMistake = 10.^(6+meanError)

