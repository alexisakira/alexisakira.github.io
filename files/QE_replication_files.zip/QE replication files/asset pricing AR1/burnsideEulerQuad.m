function resid = burnsideEulerQuad(chebCoef,theta,xGrid,xBounds)

% Unpack parameter vector

alpha = theta(1);
beta = theta(2);
mu = theta(3);
rho = theta(4);
sigma = theta(5);

% Evaluate policy function at grid points

Nx = numel(xGrid);
Napprox = numel(chebCoef);
evalGrid = linspace(-1,1,1000);
vEval = Fsim(chebCoef,evalGrid,Napprox);
interpolant = griddedInterpolant(evalGrid,vEval,'pchip');
[nodes,weights] = GaussHermite(20);
Tinterpolant = griddedInterpolant(linspace(xBounds(1),xBounds(2),1000),Tx(linspace(xBounds(1),xBounds(2),1000),xBounds(1),xBounds(2)));

% Compute residual

resid = zeros(Nx,1);

for ii = 1:Nx
    
    nextNodes = mu*(1-rho) + rho*xGrid(ii) + nodes.*sigma*sqrt(2);
    resid(ii) = sum((beta*exp(alpha*nextNodes).*(interpolant(Tinterpolant(nextNodes))+1)).*weights./sqrt(pi)) - Fsim(chebCoef,Tx(xGrid(ii),xBounds(1),xBounds(2)),Napprox);
    
end

end