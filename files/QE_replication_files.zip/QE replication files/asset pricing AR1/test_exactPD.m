% run AR1estim.m before to get parameters

gamma = 3;
beta = 0.9873;
%gamma = 5;
%beta = 0.95;
N = 10000;
Nq = 1000;

evalGrid = x + mu1;

% evaluate accuracy for Gaussian model with rho = 0
r = beta*exp((1-gamma)*mu1+(sigma1^2/2)*(1-gamma)^2);
V0 = r/(1-r);
V10 = exactPD(evalGrid,beta,gamma,mu1,0,sigma1,10,'gauss');
V100 = exactPD(evalGrid,beta,gamma,mu1,0,sigma1,100,'gauss');
V1000 = exactPD(evalGrid,beta,gamma,mu1,0,sigma1,1000,'gauss');
E10 = log10(abs(V10/V0-1));
E100 = log10(abs(V100/V0-1));
E1000 = log10(abs(V1000/V0-1));

figure
plot(evalGrid,E10,evalGrid,E100,evalGrid,E1000);

% evaluate accuracy of truncation for gauss
[VG,orderG] = exactPD(evalGrid,beta,gamma,mu1,rho1,sigma1,N,'gauss');
V10 = exactPD(evalGrid,beta,gamma,mu1,rho1,sigma1,10,'gauss');
V100 = exactPD(evalGrid,beta,gamma,mu1,rho1,sigma1,100,'gauss');
V1000 = exactPD(evalGrid,beta,gamma,mu1,rho1,sigma1,1000,'gauss');
E10 = log10(abs(V10./VG-1));
E100 = log10(abs(V100./VG-1));
E1000 = log10(abs(V1000./VG-1));

figure
plot(evalGrid,E10,evalGrid,E100,evalGrid,E1000);
xlabel('dividend growth')
ylabel('log10 error (relative to N = 10000)')
legend('N = 10','N = 100','N = 1000')
title('Gaussian model with various truncation')

% evaluate accuracy of truncation for laplace
[VL,orderL] = exactPD(evalGrid,beta,gamma,mu2,rho2,[alpha1 alpha2],N,'laplace');
V10 = exactPD(evalGrid,beta,gamma,mu2,rho2,[alpha1 alpha2],10,'laplace');
V100 = exactPD(evalGrid,beta,gamma,mu2,rho2,[alpha1 alpha2],100,'laplace');
V1000 = exactPD(evalGrid,beta,gamma,mu2,rho2,[alpha1 alpha2],1000,'laplace');
E10 = log10(abs(V10./VL-1));
E100 = log10(abs(V100./VL-1));
E1000 = log10(abs(V1000./VL-1));

figure
plot(evalGrid,E10,evalGrid,E100,evalGrid,E1000);
xlabel('dividend growth')
ylabel('log10 error (relative to N = 10000)')
legend('N = 10','N = 100','N = 1000')
title('Laplace model with various truncation')

% evaluate accuracy of truncation for nonparametric
[VNP,orderNP] = exactPD(evalGrid,beta,gamma,mu3,rho3,res3,N,'nonparametric',Nq);
V10 = exactPD(evalGrid,beta,gamma,mu3,rho3,res3,10,'nonparametric',Nq);
V100 = exactPD(evalGrid,beta,gamma,mu3,rho3,res3,100,'nonparametric',Nq);
V1000 = exactPD(evalGrid,beta,gamma,mu3,rho3,res3,1000,'nonparametric',Nq);
E10 = log10(abs(V10./VNP-1));
E100 = log10(abs(V100./VNP-1));
E1000 = log10(abs(V1000./VNP-1));

figure
plot(evalGrid,E10,evalGrid,E100,evalGrid,E1000);
xlabel('dividend growth')
ylabel('log10 error (relative to N = 10000)')
legend('N = 10','N = 100','N = 1000')
title('Nonparametric model with various truncation')

%break;

% compute PD ratio for each model using actual data
figure
plot(evalGrid,VG,evalGrid,VL,evalGrid,VNP)
xlabel('dividend growth')
ylabel('price-dividend ratio')
legend('Gauss','Laplace','Nonparametric')
title('Actual data')

% generate artificial data (Gauss)
data1 = normrnd(0,sigma1,[100000,1]);
alpha = sqrt(2)/sigma1;
npPDF = ksdensity(data1,evalGrid,'kernel','normal');
VL1 = exactPD(evalGrid,beta,gamma,mu1,rho1,alpha,N,'laplace');
VNP1 = exactPD(evalGrid,beta,gamma,mu1,rho1,data1,N,'nonparametric',Nq);

figure
plot(evalGrid,normpdf(evalGrid,0,sigma1),evalGrid,lapPDF(evalGrid,[0 alpha]),...
    evalGrid,npPDF);

figure
plot(evalGrid,VG,evalGrid,VL1,evalGrid,VNP1)
xlabel('dividend growth')
ylabel('price-dividend ratio')
legend('Gauss','Laplace','Nonparametric')
title('True data is Gaussian')

% generate artificial data (Laplace)
data2 = NLrnd([-1/alpha1+1/alpha2,0,alpha1,alpha2],[100000,1]);
npPDF = ksdensity(data2,evalGrid,'kernel','normal');
VG2 = exactPD(evalGrid,beta,gamma,mu2,rho2,sigma2,N,'gauss');
VNP2 = exactPD(evalGrid,beta,gamma,mu2,rho2,data2,N,'nonparametric',Nq);

figure
plot(evalGrid,normpdf(evalGrid,0,sigma2),evalGrid,lapPDF(evalGrid,...
    [-1/alpha1+1/alpha2,alpha1,alpha2]),evalGrid,npPDF);

figure
plot(evalGrid,VG2,evalGrid,VL,evalGrid,VNP2)
xlabel('dividend growth')
ylabel('price-dividend ratio')
legend('Gauss','Laplace','Nonparametric')
title('True data is Laplace')