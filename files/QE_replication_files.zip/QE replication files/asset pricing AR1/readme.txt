burnsideNormal.m generates the results on asset pricing models with Gaussian AR(1) shocks in the online appendix.
rhoHatN on line 36 sets the persistence of the AR(1) process.
Nm on line 52 sets the number of grid points.

burnsideGMdiscrete.m generates the results on asset pricing models with nonoparametric AR(1) shocks in Section 4.
Nm on line 23 sets the number of grid points.

burnsideChebyshev.m generates the results on Gaussian AR(1) model with discretization and projection (appendix).
rhoHatN on line 37 sets the persistence of the AR(1) process.

Other files are all subroutines.