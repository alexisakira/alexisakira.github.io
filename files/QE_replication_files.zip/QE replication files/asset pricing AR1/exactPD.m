function [V,errorOrder] = exactPD(evalGrid,beta,gamma,mu,rho,param,N,model,Nq)
% compute the exact price-dividend ratio as in Tsionas (2003)
% evalGrid: grid to compute the PD ratio
% beta: discount factor
% gamma: relative risk aversion
% mu: unconditional mean of AR(1) process
% rho: persistence of AR(1) process
% param: parameter of model; sigma if Gauss, [alpha1 alpha2] if Laplace,
% and residual if nonparametric
% N: truncation point for the infinite sum (default 1000)
% model: string that specifies gauss, laplace, or nonparametric (default
% gauss)
% Nq: number of quadrature nodes in the nonparametric case (default 100)
% errorOrder: order of approximation error, log10((r*rho)^N)

%% some error checking

if abs(rho) >= 1
    error('rho must have absolute value less than one')
end

% set default if N or model is unspecified
if nargin < 7
    N = 1000;
    model = 'gauss';
elseif nargin < 8
    model = 'gauss';
end

if ~strcmp(model,'gauss') && ~strcmp(model,'laplace') && ~strcmp(model,'nonparametric') && ~strcmp(model,'gm')
    error('Model must be one of gauss, laplace, nonparametric, or gm')
end

% set default for quadrature nodes if unspecified
if (nargin < 9) && strcmp(model,'nonparametric')
    Nq = 100;
end

if size(evalGrid,1) < size(evalGrid,2)
    x = evalGrid; % define x to be row vector of evalGrid
else x = evalGrid';
end

%% compute coefficients
ind = [1:N]';
theta = (1-gamma)/(1-rho); % limit of argument of moment generating function
s = theta*(1-rho.^ind); % argument of moment generating function
b = rho*s; % vector of b_n

%% compute log of moment generating function
switch model % shock distribution is Gauss
    case 'gauss'
    sigma = param(1);
    logMGF = (sigma^2/2)*(s.^2); % vector of log of MGF
    logMGFInf = (sigma^2/2)*theta^2; % limit
    case 'laplace' % shock distribution is Laplace
    alpha1 = param(1);
    if numel(param)>1
        alpha2 = param(2);
    else alpha2 = alpha1;
    end
    if (theta >= alpha1) || (theta <= -alpha2)
        error('moment generating function is infinite for Laplace')
    end
    m = -1/alpha1 + 1/alpha2; % mode of Laplace to make it mean zero
    logMGF = log(lapMGF(s,[m alpha1 alpha2])); % vector of log of MGF
    logMGFInf = log(lapMGF(theta,[m alpha1 alpha2])); % limit
    case 'nonparametric' % shock distribution is nonparametric
    K = 1.1*max(abs(param)); % range to define nonparametric PDF
    [xq,wq] = legpts(Nq,[-K K]); % Gauss-Legendre quadrature nodes and weights
    [f,~] = ksdensity(param,xq,'kernel','normal'); % evaluate kernel density at nodes
    temp = bsxfun(@times,exp(s*(xq')),f');
    logMGF = log(temp*(wq')); % vector of log of MGF
    logMGFInf = log(wq*(exp(theta*xq).*f)); % limit
    otherwise % gm (gaussian mixture)
        muC = param.mu; % mean of each component
        varC = squeeze(param.Sigma); % variance of each component
        pC = param.ComponentProportion; % proportion of each component
        MGF = exp(s*(muC')+s.^2*(varC')/2);
        MGFInf = exp(theta*(muC')+theta^2*(varC')/2); % limit
        logMGF = log(MGF*(pC'));
        logMGFInf = log(MGFInf*(pC'));
end

%% get terms from 1 to N
sumLogMGF = cumsum(logMGF); % cumulative sum of MGF
a = ((1-gamma)*mu+log(beta))*ind + sumLogMGF; % vector of an
temp = bsxfun(@plus,a,b*(x-mu)); % argument of exponential function in asset pricing formula
VN = sum(exp(temp)); % PD ratio, the sum up to N

%% adjust from N+1 to Inf
r = exp((1-gamma)*mu+log(beta)+logMGFInf);
if r >= 1
    fprintf('r = %d \n',r)
    error('series is not convergent')
end
bInf = theta*rho; % limit of b_n
Vrem = (r^(N+1)/(1-r))*exp(sumLogMGF(end)-N*logMGFInf+bInf*(x-mu)); % remainder term

V = VN + Vrem; % row vector of PD ratio

if size(evalGrid,1) > size(evalGrid,2)
    V = V'; % if evalGrid is a column vector, transpose V
end

errorOrder = N*log10(r*rho); % order of approximation error

end

