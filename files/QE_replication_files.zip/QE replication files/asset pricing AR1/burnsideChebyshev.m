%% Set parameters

close all
% Change default axes fonts
%set(0,'DefaultAxesFontName', 'Times New Roman')
set(0,'DefaultAxesFontSize', 12)

% Change default text fonts
%set(0,'DefaultTextFontname', 'Times New Roman')
set(0,'DefaultTextFontSize', 12)
set(0,'DefaultLineLineWidth',2)

colors = get(gca,'ColorOrder');
c1 = colors(1,:);
c2 = colors(2,:);
c3 = colors(3,:);
c4 = colors(4,:);

% Preference parameters
gamma = 1.3;
%beta = 0.95;
beta = 0.2;

%% MLE estimation data

data = xlsread('PredictorData2013.xlsx','Annual');
dGrowth = diff(log(data(:,3)));
dGrowth = dGrowth(76:end);
T = numel(dGrowth);

dX = [ones(T-1,1) dGrowth(1:end-1)];
dY = dGrowth(2:end);

% OLS model
betaHat2 = dX\dY;
%rhoHatN = betaHat2(2);
rhoHatN = 0.8; % turn up persistence
muHatN = betaHat2(1)/(1-betaHat2(2));

regResid2 = dY - dX*betaHat2;
sigmaHatN = sqrt(mean(regResid2.^2));

% Compute unconditional standard deviations

sigmaXN = sigmaHatN/sqrt(1-rhoHatN^2);

%% Compute exact price-dividend ratio

VN = @(x) exactPD(x,beta,gamma,muHatN,rhoHatN,sigmaHatN);
VN(0) % compute this first to check convergence

%% Construct discrete Markov chain approximations

Nm = 9; % number of points for discretization
NapproxInit = Nm; % starting degree of approximation
maxNapprox = Nm; % maximum degree of approximation

chebCoefGuesses = [4*ones(1,4); zeros(NapproxInit-1,4)]; % start with degree NapproxInit approximation

options = optimoptions(@fsolve,'TolFun',1e-12,'TolX',1e-10,'Display','off','FinDiffType','central');
options2 = optimset('TolFun',1e-12,'TolX',1e-10,'Display','off');

warning off

for Napprox = NapproxInit:2:maxNapprox
    
    Napprox
    
    sigmaSpacing = sqrt((Nm-1)); % spacing for even-spaced grid
    
    %% Compute discrete approximations
    
    % Maximum Entropy discretizations
   
    [PEven2,XEven2] = discreteVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,2,'even',sigmaSpacing);
    [PQuad,XQuad] = discreteVAR(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm,2,'quadrature');
    
    % Rouwenhorst discretization

    [PR,XR] = rouwenhorstAR(muHatN,rhoHatN,sigmaHatN,Nm);
    
    % Compute discretized stationary distributions
    
    stationaryDistributions = ones(Nm,3);
    % Comment this section out to use even-weighting, otherwise default is
    % ergodic distribution weighting
    temp = PEven2^1000;
    stationaryDistributions(:,1) = temp(1,:)';
    temp = PQuad^1000;
    stationaryDistributions(:,2) = temp(1,:)';
    temp = PR^1000;
    stationaryDistributions(:,3) = temp(1,:)';
    
    %% Compute approximate solutions
    
    chebNodes = coloc(Nm,1);
    
    % Set bounds
    
    boundsN = [muHatN-sigmaSpacing*sigmaXN,muHatN+sigmaSpacing*sigmaXN];
    
    if Nm == Napprox
        
        % Maximum Entropy approximations
        
        tic
        chebCoefHatCollocEven2 = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PEven2,XEven2),chebCoefGuesses(:,1),options);
        chebCoefHatCollocQuad = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PQuad,XQuad),chebCoefGuesses(:,2),options);
        toc
        
        % Rouwenhorst approximation
        
        tic
        chebCoefHatCollocR = fsolve(@(chebCoef) burnsideEuler(chebCoef,[(1-gamma),beta],PR,XR),chebCoefGuesses(:,3),options);
        toc
        
        tic
        disp('Starting Gauss-Hermite approximations')
        chebCoefHatCollocGHN = fsolve(@(chebCoef) burnsideEulerQuad(chebCoef,[(1-gamma),beta,muHatN,rhoHatN,sigmaHatN],ITx(chebNodes,boundsN(1),boundsN(2)),boundsN),chebCoefGuesses(:,4),options);
        disp('Finished Gauss-Hermite approximations!')
        toc
        
    else
        
        % Maximum Entropy approximations
        
        tic
        chebCoefHatCollocEven2 = fminunc(@(chebCoef) sum(stationaryDistributions(:,1).*(burnsideEuler(chebCoef,[(1-gamma),beta],PEven2,XEven2).^2)),chebCoefGuesses(:,1),options2);
        chebCoefHatCollocQuad = fminunc(@(chebCoef) sum(stationaryDistributions(:,2).*(burnsideEuler(chebCoef,[(1-gamma),beta],PQuad,XQuad).^2)),chebCoefGuesses(:,2),options2);
        toc
        
        % Rouwenhorst approximation
        
        tic
        chebCoefHatCollocR = fminunc(@(chebCoef) sum(stationaryDistributions(:,3).*(burnsideEuler(chebCoef,[(1-gamma),beta],PR,XR).^2)),chebCoefGuesses(:,3),options2);
        toc
        
        tic
        disp('Starting Gauss-Hermite approximations')
        chebCoefHatCollocGHN = fminunc(@(chebCoef) sum(burnsideEulerQuad(chebCoef,[(1-gamma),beta,muHatN,rhoHatN,sigmaHatN],ITx(chebNodes,boundsN(1),boundsN(2)),boundsN).^2),chebCoefGuesses(:,4),options2);
        disp('Finished Gauss-Hermite approximations!')
        toc
        
    end
    
    %% Update coefficient guesses
    
    chebCoefGuesses = [chebCoefHatCollocEven2,chebCoefHatCollocQuad,...
        chebCoefHatCollocR,chebCoefHatCollocGHN; zeros(2,4)];
    
end

warning on

%% Evaluate approximate solutions

numEval = 1501;
%numEval = 101;
evalEndsN = [max([XEven2(1) XQuad(1) boundsN(1) XR(1)]),...
    min([XEven2(end) XQuad(end) boundsN(end) XR(end)])];
evalGridN = linspace(evalEndsN(1),evalEndsN(2),numEval)';

vHatN = VN(evalGridN)';

vHatCollocEven2 = Fsim(chebCoefHatCollocEven2,Tx(evalGridN',XEven2(1),XEven2(end)),Napprox);
vHatCollocQuad = Fsim(chebCoefHatCollocQuad,Tx(evalGridN',XQuad(1),XQuad(end)),Napprox);
vHatCollocR = Fsim(chebCoefHatCollocR,Tx(evalGridN',XR(1),XR(end)),Napprox);
vHatCollocGHN = Fsim(chebCoefHatCollocGHN,Tx(evalGridN',boundsN(1),boundsN(end)),Napprox);

relativeErrorsN = bsxfun(@rdivide,vHatN,[vHatCollocEven2; vHatCollocQuad; vHatCollocR; vHatCollocGHN]) - 1;

% Plots

figure(1)
%plot(evalGridN,log10(abs(relativeErrorsN)))
plot(evalGridN,log10(abs(relativeErrorsN(1,:))),'-','Color',c1); hold on
plot(evalGridN,log10(abs(relativeErrorsN(2,:))),'-.','Color',c1);
plot(evalGridN,log10(abs(relativeErrorsN(3,:))),'-','Color',c2);
plot(evalGridN,log10(abs(relativeErrorsN(4,:))),'-','Color',c3); hold off
axis tight
%ylim([-15 0]);
%line([muHatN,muHatN],[-15,10],'Color','k','LineStyle','--')
xlabel('Dividend Growth')
ylabel('log_{10} Relative Errors')
columnlegend(2,{'ME-Even (2)','ME-Quad','Rouwenhorst','Chebyshev-GH'});
%title('Relative errors for Normal model')

% Tables

meanError = mean(log10(abs(relativeErrorsN')));
maxError = max(log10(abs(relativeErrorsN')));
disp('Normal Model Errors (mean and max)')
[meanError;maxError]

disp('Dollar Mistake with 1 Million')
dollarMistake = 10.^(6+meanError)

