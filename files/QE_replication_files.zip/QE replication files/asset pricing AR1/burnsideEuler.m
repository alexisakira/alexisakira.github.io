function resid = burnsideEuler(chebCoef,theta,P,xGrid)

% Unpack parameter vector

alpha = theta(1);
beta = theta(2);

% Evaluate policy function at grid points

Nx = numel(xGrid);
Napprox = numel(chebCoef);
vCur = Fsim(chebCoef,Tx(xGrid,xGrid(1),xGrid(end)),Napprox);

% Compute residual

resid = zeros(Nx,1);

for ii = 1:Nx
    
    resid(ii) = beta*P(ii,:)*(exp(alpha*xGrid').*(vCur'+1)) - vCur(ii);
    
end

end