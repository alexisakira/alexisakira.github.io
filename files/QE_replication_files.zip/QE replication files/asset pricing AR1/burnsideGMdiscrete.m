%% Set parameters

close all
% Change default axes fonts
%set(0,'DefaultAxesFontName', 'Times New Roman')
set(0,'DefaultAxesFontSize', 12)

% Change default text fonts
%set(0,'DefaultTextFontname', 'Times New Roman')
set(0,'DefaultTextFontSize', 12)
set(0,'DefaultLineLineWidth',2)

colors = get(gca,'ColorOrder');
c1 = colors(1,:);
c2 = colors(2,:);
c3 = colors(3,:);
c4 = colors(4,:);
c5 = colors(5,:);

% Preference parameters
gamma = 5;
beta = 0.95;
Nm = 15; % number of points for discretization

%% MLE estimation data

data = xlsread('PredictorData2013.xlsx','Annual');
dGrowth = diff(log(data(:,3))); % log dividend growth
dGrowth = dGrowth(76:end); % post war data
T = numel(dGrowth);

dX = [ones(T-1,1) dGrowth(1:end-1)];
dY = dGrowth(2:end);

% OLS model
betaHat2 = dX\dY;
rhoHatN = betaHat2(2);
%rhoHatN = 0.8; % turn up persistence
muHatN = betaHat2(1)/(1-betaHat2(2));

regResid2 = dY - dX*betaHat2;

% Compute conditional and unconditional standard deviations
sigmaHatN = sqrt(mean(regResid2.^2));
sigmaXN = sigmaHatN/sqrt(1-rhoHatN^2);

% Fit Gaussian mixtures
load gmObjDiv % load fitted data (can uncomment the following two lines but results may depend on Matlab version)
%nComp = 3; % number of components
%gmObj = fitgmdist(regResid2,nComp);

% plot densities
gmpdf = gmdistribution(gmObj.mu,gmObj.Sigma,gmObj.ComponentProportion);
residPdf = @(x) ksdensity(regResid2,x,'kernel','normal');

K = 1.1*max(abs(regResid2));
x = linspace(-K,K,1000)';

figure(1)
plot(x,normpdf(x,0,sigmaHatN),'--'); hold on
plot(x,pdf(gmpdf,x),'-');
plot(x,residPdf(x),'-.'); hold off
xlim([min(x) max(x)])
xlabel('Dividend Growth Shock')
ylabel('Probability Density Function')
legend('Normal','Gaussian Mixture','Nonparametric')

%% Compute exact price-dividend ratio

VN = @(x) exactPD(x,beta,gamma,muHatN,rhoHatN,sigmaHatN);
VGM = @(x) exactPD(x,beta,gamma,muHatN,rhoHatN,gmObj,1000,'gm');

% plot exact PD ratios for the normal and gaussian mixture models

figure(2)
plot(x,VN(x),x,VGM(x));
xlim([min(x),max(x)])
xlabel('Dividend Growth')
ylabel('Price-Dividend Ratio')
legend('Normal','Gaussian Mixture')

%% Construct discrete Markov chain approximations
 
%% Compute discrete approximations
    
% Maximum Entropy discretizations
 
disp('maximum entropy discretization (even-space)')
tic
[PEven2,XEven2] = discreteARGM(muHatN,rhoHatN,gmObj,Nm,2,'even');
[PEven4,XEven4] = discreteARGM(muHatN,rhoHatN,gmObj,Nm,4,'even');
toc

disp('maximum entropy discretization (gauss-hermite)')
tic
[PGH2,XGH2] = discreteARGM(muHatN,rhoHatN,gmObj,Nm,2,'gauss-hermite');
[PGH4,XGH4] = discreteARGM(muHatN,rhoHatN,gmObj,Nm,4,'gauss-hermite');
toc
    
% Rouwenhorst discretization

[PR,XR] = rouwenhorstAR(muHatN,rhoHatN,sigmaHatN,Nm);
    
% Tauchen-Hussey discretization
    
[PTH,XTH] = tauchenHussey(muHatN*(1-rhoHatN),rhoHatN,sigmaHatN^2,Nm);

discretePD = @(P,X)((eye(Nm)-beta*P*diag(exp((1-gamma)*X)))\(beta*P*exp((1-gamma)*X)));

VEven2 = discretePD(PEven2,XEven2');
VEven4 = discretePD(PEven4,XEven4');
VGH2 = discretePD(PGH2,XGH2');
VGH4 = discretePD(PGH4,XGH4');
VR = discretePD(PR,XR');
VTH = discretePD(PTH,XTH');

%% Evaluate approximate solutions

numEval = 1001;
evalEnds = [max([min(XEven2) XGH2(1)  XR(1)]),...
    min([max(XEven2) XGH2(end) XR(end)])];
evalGrid = linspace(evalEnds(1),evalEnds(2),numEval)';

vHatGM = VGM(evalGrid);

% spline interpolation from discrete solutions
vHatEven2 = spline(XEven2',VEven2,evalGrid);
vHatEven4 = spline(XEven4',VEven4,evalGrid);
vHatGH2 = spline(XGH2',VGH2,evalGrid);
vHatGH4 = spline(XGH4',VGH4,evalGrid);
vHatR = spline(XR',VR,evalGrid);
vHatTH = spline(XTH',VTH,evalGrid);

relativeErrors = bsxfun(@rdivide,vHatGM,[vHatEven2, vHatEven4, vHatGH2, vHatGH4, vHatR, vHatTH]) - 1;

% Plots

figure(3)
line_fewer_markers(evalGrid,log10(abs(relativeErrors(:,1))),9,'--s','Mks',8,'Color',c1); hold on
line_fewer_markers(evalGrid,log10(abs(relativeErrors(:,2))),9,'-s','Mks',8,'Color',c1);
line_fewer_markers(evalGrid,log10(abs(relativeErrors(:,3))),9,'--d','Mks',8,'Color',c5);
line_fewer_markers(evalGrid,log10(abs(relativeErrors(:,4))),9,'-d','Mks',8,'Color',c5);
line_fewer_markers(evalGrid,log10(abs(relativeErrors(:,5))),9,'-x','Mks',8,'Color',c2);
line_fewer_markers(evalGrid,log10(abs(relativeErrors(:,6))),9,'-o','Mks',8,'Color',c4); hold off
axis tight
%ylim([-15 0]);
%line([muHatN,muHatN],[-15,10],'Color','k','LineStyle','--')
xlabel('Dividend Growth')
ylabel('log_{10} Relative Errors')
%legend('ME-Even (2)','ME-Even (4)','ME-GH (2)','ME-GH (4)','Rouwenhorst','Tauchen-Hussey');
columnlegend(2,{'ME-Even (2)','ME-Even (4)','ME-GH (2)','ME-GH (4)','Rouwenhorst','Tauchen-Hussey'});
%title('Relative errors for Normal model')

% Tables

meanError = mean(log10(abs(relativeErrors)));
maxError = max(log10(abs(relativeErrors)));
disp('Nonparametric Model Errors (mean and max)')
[meanError;maxError]

disp('Dollar Mistake with 1 Million')
dollarMistake = 10.^(6+meanError)

