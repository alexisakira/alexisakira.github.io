clear
close all
clc;

%% figure formatting

set(0,'DefaultTextInterpreter','latex')
set(0,'DefaultAxesTickLabelInterpreter','latex');
set(0,'DefaultLegendInterpreter', 'latex')

set(0,'DefaultTextFontSize', 14)
set(0,'DefaultAxesFontSize', 14)
set(0,'DefaultLineLineWidth',1)

temp = get(gca,'ColorOrder');
c1 = temp(1,:);
c2 = temp(2,:);
c3 = temp(3,:);

close all

c = 0.1; % cost
N = 1000; % number of applicants

tic
pi = get_pi(c,N);
toc

pi_mat = zeros(N,2);
for n = 1:N
    pi_mat(n,1) = get_pi(0,n);
    pi_mat(n,2) = get_pi(c,n);
end

figure
hold on
plot(pi_mat(:,1),'--','Color',c1);
plot(pi_mat(:,2),'-','Color',c1);
yline(exp(-1),'k:');
ylim([0 1])
xlabel('Number of applicants')
ylabel('Success probability')
legend('$c=0$',['$c=$ ' num2str(c)],'$\exp(-1)$')

exportgraphics(gcf,'fig_prob.pdf',...
    'Resolution',300,'ContentType','vector')

Nvec = [1:100 10.^[3:6]];
K = length(Nvec);
pi_vec = zeros(K,1);

for k = 1:K
    pi_vec(k) = get_pi(c,Nvec(k));
end

temp = exp(c-1)/gamma(2-c)*Nvec.^(-c); % asymptotic approximation

figure
loglog(Nvec,pi_vec,'-','Color',c1); hold on
loglog(Nvec,temp,'--','Color',c1);
xlabel('Number of applicants')
ylabel('Success probability')
legend('Exact','Asymptotic approximation')

exportgraphics(gcf,'fig_prob_loglog.pdf',...
    'Resolution',300,'ContentType','vector')