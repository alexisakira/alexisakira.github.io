function pi = get_pi(c,N)
% compute success probability in secretary problem with cost c

if (c < 0)||(c >= 1)
    error('c must be between 0 and 1')
end

v0 = 0;
v1 = 1/N;

for n = N-1:-1:1
    v0 = (1/n)*v1 + v0;
    v1 = max(c/N + (1-c)*v0,1/N);
end

pi = v1;