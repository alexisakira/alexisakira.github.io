%% figure formatting

clear % clear the workspace
clc % clear the command window

% Use LaTeX font because it's nicer
set(0,'DefaultTextInterpreter','latex')
set(0,'DefaultAxesTickLabelInterpreter','latex');
set(0,'DefaultLegendInterpreter', 'latex')

set(0,'DefaultTextFontSize', 14)
set(0,'DefaultAxesFontSize', 14)
set(0,'DefaultLineLineWidth',1)

temp = get(gca,'ColorOrder');
c1 = temp(1,:);
c2 = temp(2,:);
c3 = temp(3,:);

close all

%% define parameters
beta = 0.5;     % discount factor
alpha = 0.8;    % CES parameter
sigma = 1.25;   % elasticity of substitution
rho = 1/sigma;
F = @(A)(alpha*A.^(1-rho)+1-alpha).^(1/(1-rho)); % production function

G = [1.1 0.95]'; % vector of growth rates
p = 1/3;
Pi = [1-p p; p 1-p]; % transition probability matrix
G_mat = [G G]; % matrix of growth rates
K = Pi.*G_mat.^(rho-1);
sp = eigs(K,1); % spectral radius

if sp < 1
    disp('overvaluation')
else
    disp('fundamental')
end

%% simulation

rng(0);
mc = dtmc(Pi);              % define Markov chain
T = 200;                    % number of periods
Nt = simulate(mc,T);        % state
Gt = G(Nt);                 % growth rate
At = exp(cumsum(log(Gt)));  % relative productivity
Ft = F(At);                 % output
wt = alpha*Ft.^rho.*At.^(1-rho); % wage
rt = (1-alpha)*Ft.^rho;     % rent
Pt = beta*wt;               % price
time = [0:T];

f1 = figure;
plot(time,Pt,'-','Color',c1); hold on
plot(time,rt,'--','Color',c1);
plot(time,Pt./rt,'Color',c2)
xlabel('Time')
legend('Price','Rent','Price-rent ratio','Location','NW')
%title('Original scale')

exportgraphics(f1,'fig_sim.pdf');

f2 = figure;
semilogy(time,Pt,'-','Color',c1); hold on
semilogy(time,rt,'--','Color',c1);
semilogy(time,Pt./rt,'Color',c2)
xlabel('Time')
legend('Price','Rent','Price-rent ratio','Location','NW')
%title('Semilog scale')

exportgraphics(f2,'fig_sim_semilog.pdf');