% load data before 1929
temp = readmatrix("labor_force_employment.xlsx","Range",'A6:J18');
temp = flipud(temp); % sort by year
temp = temp'; % put year in columns

year = temp(1,:);
total = sum(temp(3:10,:),1); % total
agri = sum(temp(3:4,:),1); % agriculture
mine = temp(5,:); % mining
cons = temp(6,:); % construction

% add data for 1929-1947

temp_y = readmatrix("NIPA_Tab6.5A.xlsx","Range",'C6:U6');
temp_t = readmatrix("NIPA_Tab6.5A.xlsx","Range",'C8:U8');
temp_a = readmatrix("NIPA_Tab6.5A.xlsx","Range",'C11:U11');
temp_m = readmatrix("NIPA_Tab6.5A.xlsx","Range",'C14:U14');
temp_c = readmatrix("NIPA_Tab6.5A.xlsx","Range",'C20:U20');

year = [year temp_y];
total = [total temp_t];
agri = [agri temp_a];
mine = [mine temp_m];
cons = [cons temp_c];

% add data for 1948-1986

temp_y = readmatrix("NIPA_Tab6.5B.xlsx","Range",'C6:AO6');
temp_t = readmatrix("NIPA_Tab6.5B.xlsx","Range",'C8:AO8');
temp_a = readmatrix("NIPA_Tab6.5B.xlsx","Range",'C11:AO11');
temp_m = readmatrix("NIPA_Tab6.5B.xlsx","Range",'C14:AO14');
temp_c = readmatrix("NIPA_Tab6.5B.xlsx","Range",'C19:AO19');

year = [year temp_y];
total = [total temp_t];
agri = [agri temp_a];
mine = [mine temp_m];
cons = [cons temp_c];

% add data for 1987-1999

temp_y = readmatrix("NIPA_Tab6.5C.xlsx","Range",'C6:M6');
temp_t = readmatrix("NIPA_Tab6.5C.xlsx","Range",'C8:M8');
temp_a = readmatrix("NIPA_Tab6.5C.xlsx","Range",'C11:M11');
temp_m = readmatrix("NIPA_Tab6.5C.xlsx","Range",'C14:M14');
temp_c = readmatrix("NIPA_Tab6.5C.xlsx","Range",'C19:M19');

year = [year temp_y];
total = [total temp_t];
agri = [agri temp_a];
mine = [mine temp_m];
cons = [cons temp_c];

% add data for 2000-2022

temp_y = readmatrix("NIPA_Tab6.5D.xlsx","Range",'C6:AA6');
temp_t = readmatrix("NIPA_Tab6.5D.xlsx","Range",'C8:AA8');
temp_a = readmatrix("NIPA_Tab6.5D.xlsx","Range",'C11:AA11');
temp_m = readmatrix("NIPA_Tab6.5D.xlsx","Range",'C14:AA14');
temp_c = readmatrix("NIPA_Tab6.5D.xlsx","Range",'C19:AA19');

year = [year temp_y];
total = [total temp_t];
agri = [agri temp_a];
mine = [mine temp_m];
cons = [cons temp_c];

temp = [year; total; agri; mine; cons]';

% per capita GDP

%GDP = readmatrix("A229RX0A048NBEA.xls","Range",'B12:B105');

year = year'; % convert to column vector
N = length(year); % number of years

% year
temp1 = readmatrix("mpd2023_web.xlsx","Sheet",'GDPpc',"Range",'A558:A780');
% GDP
temp2 = readmatrix("mpd2023_web.xlsx","Sheet",'GDPpc',"Range",'FF558:FF780');
GDP = 0*year;
for n = 1:N
    ind = find(temp1 == year(n));
    GDP(n) = temp2(ind);
end

CPI2011 = readmatrix("CPIAUCSL.xls","Range",'B791:B791');
CPI2023 = readmatrix("CPIAUCSL.xls","Range",'B935:B935');

GDP = GDP*(CPI2023/CPI2011); % convert to 2023 dollars

C = {'Year','Total','Agriculture','Mining','Construction','GDP per capita'};
filename = 'US_employment.xlsx';
writecell(C,filename,'Range','A1:F1');
writematrix(temp,filename,'Range','A2:E200');
writematrix(GDP,filename,'Range','F2:F200');