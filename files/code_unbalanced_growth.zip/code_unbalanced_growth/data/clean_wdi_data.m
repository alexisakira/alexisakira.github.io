% load population data

% name of country
country = readcell("2.1_Population_dynamics.xls","Range",'A5:A218');
% population in 2023
population = readmatrix("2.1_Population_dynamics.xls","Range",'C5:C218');

% load employment data

temp = readmatrix("2.3_Employment_by_sector.xls","Range",'B5:M218');

% employment share of agriculture take average of male and female in 2019
employment_share_agri = (temp(:,2) + temp(:,4))/2;

% load GDP data

temp = readmatrix("4.2_Structure_of_value_added.xls","Range",'B5:K218');

GDP = temp(:,2); % GDP in 2023 or most recent year
GDP_share_agri = temp(:,4); % GDP share of agriculture

temp = [population employment_share_agri GDP GDP_share_agri];

C = {'country','population','employment_share_agri','GDP','GDP_share_agri'};

filename = 'wdi.xlsx';
writecell(C,filename,'Range','A1:E1');
writecell(country,filename,'Range','A2:A300');
writematrix(temp,filename,'Range','B2:E300')