%% figure formatting

clear % clear the workspace
clc % clear the command window

% Use LaTeX font because it's nicer
set(0,'DefaultTextInterpreter','latex')
set(0,'DefaultAxesTickLabelInterpreter','latex');
set(0,'DefaultLegendInterpreter', 'latex')

set(0,'DefaultTextFontSize', 14)
set(0,'DefaultAxesFontSize', 14)
set(0,'DefaultLineLineWidth',1)

temp = get(gca,'ColorOrder');
c1 = temp(1,:);
c2 = temp(2,:);
c3 = temp(3,:);
c4 = temp(4,:);
c5 = temp(5,:);

close all

%% US employment data

temp = readmatrix("US_employment.xlsx");

year = temp(:,1);
total = temp(:,2);
agri = temp(:,3);
mine = temp(:,4);
cons = temp(:,5);
GDPUS = temp(:,6);

land = agri + mine + cons;

share = 100*agri./total;

figure
plot(year,share,'-','Color',c1); hold on
plot(year,100*(agri+mine+cons)./total,'--','Color',c1);
xlabel('Year')
ylabel('Employment share (\%)')
xlim([year(1) year(end)])
legend('Agriculture','Land-intensive')

exportgraphics(gcf,'fig_US_year_share.pdf',...
    'Resolution',300,'ContentType','vector')

j = sum(isnan(GDPUS));

figure
semilogx(GDPUS,share,'-','Color',c1); hold on
text(GDPUS(j+1),share(j+1),num2str(year(j+1)),...,
    'HorizontalAlignment','left','VerticalAlignment','bottom');
text(GDPUS(end),share(end),num2str(year(end)),...
    'HorizontalAlignment','right','VerticalAlignment','bottom');
xlim([1e3,1e5])
xlabel('Per capita GDP (\$)')
ylabel('Employment share of agriculture (\%)')

exportgraphics(gcf,'fig_US_GDPPC_share.pdf',...
    'Resolution',300,'ContentType','vector')

%% WDI data

temp = readmatrix("wdi.xlsx","Range",'B2:E215');
temp(any(isnan(temp), 2), :) = []; % delete countries with NaN

population = temp(:,1);
employment_share_agri = temp(:,2);
GDP = temp(:,3);
GDP_share_agri = temp(:,4);
GDPPC = GDP./population; % GDP per capita, in thousands dollars

figure
semilogx(1000*GDPPC,GDP_share_agri,'o','Color',c1); hold on
ylim([0 100])
xlabel('Per capita GDP (\$)')
ylabel('GDP share of agriculture (\%)')

exportgraphics(gcf,'fig_country_GDP_share.pdf',...
    'Resolution',300,'ContentType','vector')

figure
semilogx(1000*GDPPC,employment_share_agri,'o','Color',c1)
ylim([0 100])
xlabel('Per capita GDP (\$)')
ylabel('Employment share of agriculture (\%)')

exportgraphics(gcf,'fig_country_employment_share.pdf',...
    'Resolution',300,'ContentType','vector')

figure
semilogx(GDPUS,share,'-','Color',c1); hold on
text(GDPUS(j+1),share(j+1),num2str(year(j+1)),...,
    'HorizontalAlignment','right','VerticalAlignment','bottom');
%text(GDPUS(end),share(end),num2str(year(end)),...
%    'HorizontalAlignment','right','VerticalAlignment','bottom');
semilogx(1000*GDPPC,employment_share_agri,'ok')
ylim([0 100])
xlabel('Per capita GDP (\$)')
ylabel('Employment share of agriculture (\%)')
legend('US, 1800-','Countries in 2023')
