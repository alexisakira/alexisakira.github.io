% load OECD data

N = 30;
countries = readcell("z6oj0i.xlsx","Range",'B28:B207');
countries = reshape(countries,6,N)';
countries = countries(:,1);

shares = readmatrix("z6oj0i.xlsx","Range",'E28:E207'); % wealth shares
shares = reshape(shares,6,N)';

countries(1) = []; % delete OECD average
shares(1,:) = [];

asset = 100*shares(:,1);    % financial asset
housing = 100*shares(:,2);  % owener-occupied housing
second = 100*shares(:,3);   % secondary real estate
other = 100 - asset - housing - second;

temp = [housing second asset other];
[~,I] = sort(housing+second,'descend'); % sort housing in descending order

countries = countries(I);
temp = temp(I,:);

% create bar chart
figure
bar(countries,temp,'stacked')
ylim([0 100])
ylabel('Household wealth (\%)')
legend('Primary residence','Secondary real estate','Financial asset','Other',...
    'Location','southwest')

exportgraphics(gcf,'fig_OECD.pdf',...
    'Resolution',300,'ContentType','vector')