Replication files for "Unbalanced Growth and Land Overvaluation" by Tomohiro Hirano and Alexis Akira Toda
Proceedings of the National Academy of Science, 2025.
https://doi.org/10.1073/pnas.2423295122

1. Data source

- Labor force and employment
Historical Statistics of the United States, Colonial Times to 1970
https://www.census.gov/library/publications/1975/compendia/hist_stats_colonial-1970.html
Series D 167-181

- To get employment by industry, go to BEA NIPA tables
https://apps.bea.gov/iTable/?reqid=19&step=2&isuri=1&categories=survey
and go to Section 6 Income and Employment by Industry. Table 6.5A-6.5D is what we want

- To get historical data on real per capita GDP, go to Maddison Project Database
https://www.rug.nl/ggdc/historicaldevelopment/maddison/releases/maddison-project-database-2023

To get population, GDP by industry, employment by industry, etc. by country, go to
World Bank World Development Indicators
https://wdi.worldbank.org/table/

2. Matlab files

- clean_employment_data.m and clean_wdi_data.m clean various data sets
- land_share.m creates Figures 1, 2
- OECD.m creates Figure 3
